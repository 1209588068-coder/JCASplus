"""Synthetic read-only collection tests; no AV2 assets or optimization."""
from contextlib import ExitStack
from copy import deepcopy
import csv
import hashlib
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np
import torch

from experiments.spear_distribution_audit_v1 import collection as c
from experiments.spear_domain_training_v1.module import DomainConstrainedGenerator
from experiments.spear_semantic_support_v1.module import SupportMaskedGenerator
from tests.test_spear_domain_training_module import setup
from tests.test_spear_pair_role_generator import fixture


def scene(scene_id='scene-a', role='audit', *, moving=False, eligible=True, nodes=1):
    row = dict(scenario_id=scene_id, split_group_id='group-' + scene_id, role=role, split='train',
               graph_path=f'graphs/{scene_id}.npz', graph_sha256='sha-' + scene_id)
    if nodes == 1:
        pairs = np.array([[0, 1]], dtype=np.int64)
        edges = np.empty((2, 0), dtype=np.int64)
        x = np.zeros((1, 784), dtype=np.float32)
    else:
        pairs_t, context, features = fixture(784)
        pairs, edges, x = pairs_t.numpy(), context.edge_index.numpy(), features.numpy() / 200
    part = dict(scenario_id=scene_id, split='train', metadata={}, x=x, edge_index=edges,
        canonical_pairs=pairs, canonical_pair_track_ids=np.array([[str(a), str(b)] for a, b in pairs]),
        y=np.zeros(len(x), dtype=np.int64), eligible=np.full(len(x), eligible, dtype=bool),
        motion_regime=np.full(len(x), moving, dtype=bool))
    return row, part


def generators():
    anchor, support, *_ = setup()
    result = {}
    for index, arm in enumerate(c.ARMS):
        model = DomainConstrainedGenerator(anchor, support, output_mode='domain_projection')
        with torch.no_grad():
            model.residual.head.bias.add_(index * .15)
            model.residual.head.bias[torch.nonzero(support).flatten()[0]] = 20.
        result[arm] = model.eval().requires_grad_(False)
    return result, support


class CollectionTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)

    def test_hash_target_rule_excludes_positive_and_ineligible_without_motion_filter(self):
        row, part = scene(nodes=6)
        part['eligible'][0] = False
        part['y'][1] = 1
        part['motion_regime'][:] = [False, True, False, True, False, True]
        before = c.baseline.field.part_digest(part)
        seed = 20260621
        expected = min((2, 3, 4, 5), key=lambda i: hashlib.sha256(
            f"{seed}:spear-audit-target:{row['scenario_id']}:{':'.join(part['canonical_pair_track_ids'][i])}".encode()
        ).hexdigest())
        rng = torch.random.get_rng_state().clone()
        _, _, target, identity = c.select_target(part, row, seed)
        self.assertEqual(target, expected)
        self.assertEqual(identity['pair_index'], expected)
        self.assertEqual(identity['motion_regime'], 'moving' if part['motion_regime'][expected] else 'slow')
        self.assertEqual(before, c.baseline.field.part_digest(part))
        self.assertTrue(torch.equal(rng, torch.random.get_rng_state()))
        part['eligible'][:] = False
        self.assertIsNone(c.select_target(part, row, seed)[2])

    def test_clean_reference_is_one_per_scene_and_never_replaces_empty_scenes(self):
        models, _ = generators()
        selected = models['continuation'].selected_coordinates[models['continuation'].hard_support]
        rows, parts = zip(scene('a', role='train', moving=True, nodes=6),
                          scene('b', role='train', eligible=False), scene('c', role='train'))
        with patch.object(c, 'SceneInjector', side_effect=AssertionError('no reference trigger')):
            result = c.collect_reference(parts, rows, selected, 9)
        self.assertEqual(result['train_selected'].shape, (2, 24))
        self.assertEqual(result['train_conditions'].shape, (2, 6))
        self.assertEqual(result['train_selected'].dtype, np.float32)
        np.testing.assert_array_equal(result['train_moving'], [True, False])
        self.assertEqual([r['scenario_id'] for r in result['reference_rows']], ['a', 'c'])
        self.assertEqual(result['reference_scenes_without_target'], ['b'])
        with patch.object(c, '_component', side_effect=AssertionError('must gate role first')):
            with self.assertRaisesRegex(ValueError, 'training-role'):
                c.collect_reference([parts[0]], [dict(rows[0], role='dev')], selected, 9)

    def test_three_frozen_replays_preserve_scope_conditions_topology_rng_and_native_clamp(self):
        models, support = generators()
        selected = models['continuation'].selected_coordinates[support]
        row, part = scene(nodes=6)
        features, _, target, identity = c.select_target(part, row, 12)
        hashes = {arm: c.state_sha256(model) for arm, model in models.items()}
        rng = torch.random.get_rng_state().clone()
        with patch.object(torch.optim.Adam, 'step', side_effect=AssertionError('no optimization')):
            outputs, budgets = c.replay_target(part, row, target, identity, models, selected, 12, 37)
        self.assertTrue(torch.equal(rng, torch.random.get_rng_state()))
        self.assertEqual(hashes, {arm: c.state_sha256(model) for arm, model in models.items()})
        for arm in c.ARMS:
            self.assertEqual(outputs[arm].shape, (24,))
            self.assertTrue(np.isfinite(outputs[arm]).all())
            self.assertLessEqual(float(np.abs(outputs[arm]).max()), 10.)
            self.assertEqual(budgets[arm]['non_target_changed_rows'], 0)
            self.assertEqual(budgets[arm]['support_capacity'], 24)
            self.assertEqual(budgets[arm]['coordinates_outside_domain'], 0)
            expected_l1 = np.abs(outputs[arm].astype(np.float64) - features[target, selected].numpy().astype(np.float64)).sum()
            self.assertEqual(budgets[arm]['normalized_l1_per_target'], [expected_l1])
        self.assertFalse(np.array_equal(outputs['continuation'], outputs['conditional']))

    def test_replay_rejects_target_identity_mismatch_and_out_of_scope_changes(self):
        models, support = generators()
        selected = models['continuation'].selected_coordinates[support]
        row, part = scene(nodes=6)
        _, _, target, identity = c.select_target(part, row, 12)
        with self.assertRaisesRegex(ValueError, 'identity'):
            c.replay_target(part, row, target, dict(identity, motion_regime='wrong'), models, selected, 12, 37)
        original = c.SceneInjector

        class BadInjector(original):
            def inject_trigger(self, indices, x, edges, weights, device):
                output, out_edges, out_weights = super().inject_trigger(indices, x, edges, weights, device)
                output[(int(indices[0]) + 1) % len(output), 0] += 1.
                return output, out_edges, out_weights

        with patch.object(c, 'SceneInjector', BadInjector), self.assertRaisesRegex(ValueError, 'nontarget'):
            c.replay_target(part, row, target, identity, models, selected, 12, 37)

    def test_restores_sage_then_projected_then_three_arm_weights_and_both_hash_algorithms(self):
        anchor, support, *_ = setup()
        sage = SupportMaskedGenerator(anchor, hard_support=support).eval().requires_grad_(False)
        projected = DomainConstrainedGenerator(sage.anchor, support, output_mode='domain_projection')
        with torch.no_grad(): projected.residual.head.bias.add_(.45)
        projected.eval().requires_grad_(False)
        reports, training, final_hashes, completed = {}, {}, {}, {}
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)

            def checkpoint(name, model):
                path = root / name
                torch.save(model.state_dict(), path)
                return c.assets.asset(path)

            source = dict(parent=dict(references=dict(role_plan={})), hard_support=support.tolist(), references=dict(
                sage_generator=checkpoint('sage.pt', sage), generator=checkpoint('projected.pt', projected)))
            for index, arm in enumerate(c.ARMS):
                completed[arm] = deepcopy(projected)
                with torch.no_grad(): completed[arm].residual.head.bias.add_(index + 1.)
                training[arm] = dict(generator=checkpoint(arm + '.pt', completed[arm]))
                reports[arm] = dict(unchanged_model_hashes=dict(generator=c.state_sha256(completed[arm])))
                final_hashes[arm] = dict(generator=c._state_hash(completed[arm]))
            barrier = dict(final_model_hashes=final_hashes)
            rng = torch.random.get_rng_state().clone()
            with ExitStack() as stack:
                stack.enter_context(patch.object(c.assets, 'ROOT', root))
                stack.enter_context(patch.object(c.previous, 'checked_json', return_value={}))
                restore = stack.enter_context(patch.object(c.baseline.prior, 'restore',
                    return_value=(None, None, SimpleNamespace(), {}, anchor.selected_coordinates, {'mean': np.zeros(784)})))
                stack.enter_context(patch.object(c.baseline.prior, 'new_generator', return_value=anchor))
                stack.enter_context(patch.object(c.baseline.accepted, 'new_model', return_value=anchor))
                load = stack.enter_context(patch.object(torch, 'load', wraps=torch.load))
                actual, _, _, _ = c.restore_generators(source, reports, training, barrier)
                restore.assert_called_once_with({}, evaluation_models=False)
                self.assertEqual([Path(call.args[0]).name for call in load.call_args_list],
                                 ['sage.pt', 'projected.pt', *(arm + '.pt' for arm in c.ARMS)])
                for arm in c.ARMS:
                    self.assertEqual(c.state_sha256(actual[arm]), c.state_sha256(completed[arm]))
                    self.assertTrue(all(not p.requires_grad for p in actual[arm].parameters()))
                bad = deepcopy(barrier)
                bad['final_model_hashes']['conditional']['generator'] = reports['conditional']['unchanged_model_hashes']['generator']
                with self.assertRaisesRegex(ValueError, 'checkpoint hashes'):
                    c.restore_generators(source, reports, training, bad)
            self.assertTrue(torch.equal(rng, torch.random.get_rng_state()))

    def test_reference_population_guard_runs_before_assets_or_model_reads(self):
        with patch.object(c.previous, 'checked_json', side_effect=AssertionError('must not read')):
            with self.assertRaises(ValueError) as caught:
                c.collect(dict(reference_population='fixed_outer538', execution=dict(device='cpu', torch_threads=2)))
        self.assertEqual(caught.exception.graph_access_ledger, [])

    def test_normalizer_hash_includes_numeric_and_string_npz_fields(self):
        normalizer = dict(mean=np.zeros(784, dtype=np.float64), scale=np.ones(784, dtype=np.float64),
                          version=np.array('spear-v1'), fit_scope=np.array('original_TRAIN'))
        hashes = c._normalizer_hashes(normalizer)
        self.assertEqual(hashes, c._normalizer_hashes(deepcopy(normalizer)))
        changed = deepcopy(normalizer)
        changed['fit_scope'] = np.array('changed')
        self.assertNotEqual(hashes, c._normalizer_hashes(changed))
        with self.assertRaisesRegex(ValueError, 'object'):
            c._normalizer_hashes(dict(metadata=np.array([{}], dtype=object)))

    def test_target_csv_ignores_predictions_but_rejects_duplicate_or_changed_motion_count(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(c.assets, 'ROOT', Path(directory)):
            path = Path(directory) / 'targets.csv'
            rows = [dict(scenario_id=f'scene{i}', split_group_id=f'group{i}', pair_index=0,
                         src_track_id='a', dst_track_id='b', true_label=0,
                         motion_regime='moving' if i < 60 else 'slow', victim_trigger_pred=i % 2)
                    for i in range(224)]

            def write():
                with path.open('w', newline='') as stream:
                    writer = csv.DictWriter(stream, fieldnames=[*c.IDENTITY_FIELDS, 'victim_trigger_pred'])
                    writer.writeheader()
                    writer.writerows(rows)
                return dict(c.assets.asset(path), rows=224)

            first = c.read_target_rows(write())
            for row in rows: row['victim_trigger_pred'] = 99
            self.assertEqual(first, c.read_target_rows(write()))
            rows[0]['motion_regime'] = 'slow'
            with self.assertRaises(ValueError): c.read_target_rows(write())
            rows[0]['motion_regime'] = 'moving'
            rows[-1]['scenario_id'] = rows[0]['scenario_id']
            with self.assertRaises(ValueError): c.read_target_rows(write())

    def _mock_collect(self, *, corrupt_budget=False):
        models, support = generators()
        selected = models['continuation'].selected_coordinates[support]
        train_pairs = [scene(f'train{i}', 'train', moving=i < 120) for i in range(512)]
        audit_pairs = [scene(f'audit{i}', moving=i < 60, eligible=i < 224) for i in range(256)]
        roles = dict(train=[row for row, _ in train_pairs], audit=[row for row, _ in audit_pairs])
        dummy = dict(path='/synthetic/metadata-only', sha256='synthetic')
        parent = dict(roles=roles, graph_dir='/synthetic', seed=12, shuffle_seed=37,
                      references=dict(input_contract=dummy, role_plan=dummy))
        source = dict(parent=parent, hard_support=support.tolist(), references=dict(sage_generator=dummy, generator=dummy))
        expected = [c.select_target(part, row, parent['seed'])[3] for row, part in audit_pairs[:224]]
        first_row, first_part = audit_pairs[0]
        _, template = c.replay_target(first_part, first_row, 0, expected[0], models, selected, 12, 37)
        budgets = {arm: [dict(template[arm], scenario_id=identity['scenario_id'], motion_regime=identity['motion_regime'])
                         for identity in expected] for arm in c.ARMS}
        if corrupt_budget:
            budgets['conditional'][0]['normalized_l1_per_target'] = [999.]
        seen_stages = []

        def log(row, ledger):
            ledger.append(dict(scenario_id=row['scenario_id'], role=row['role'], split='train', status='READ_COMPLETE',
                path=str(Path('/synthetic') / row['graph_path']), sha256=row['graph_sha256']))

        def load_train(_source, _normalizer, ledger):
            for row, _ in train_pairs: log(row, ledger)
            return [part for _, part in train_pairs], None, {}, {}, None

        def read_audit(row, _parent, _normalizer, ledger):
            self.assertIn('clean_training_reference_complete', seen_stages)
            log(row, ledger)
            return audit_pairs[int(row['scenario_id'][5:])][1]

        def state(**record):
            seen_stages.append(record['stage'])

        with ExitStack() as stack:
            stack.enter_context(patch.object(c, '_source_evidence', return_value=(source, {}, {}, {}, expected, budgets, [])))
            normalizer = dict(mean=np.zeros(784), scale=np.ones(784), version=np.array('synthetic'), fit_scope=np.array('TRAIN'))
            stack.enter_context(patch.object(c, 'restore_generators', return_value=(models, normalizer, models['continuation'].selected_coordinates,
                dict(references={key: dummy for key in ('generator', 'shadow', 'feature_importance', 'normalizer')}))))
            stack.enter_context(patch.object(c.previous, 'load_train', side_effect=load_train))
            stack.enter_context(patch.object(c.previous, 'checked_json', return_value={}))
            stack.enter_context(patch.object(c.source_fitting, 'check_outer', return_value=torch.arange(538)))
            stack.enter_context(patch.object(c.previous, 'input_digest', return_value='unchanged-train'))
            stack.enter_context(patch.object(c.baseline.field, 'read_audit_part', side_effect=read_audit))
            stack.enter_context(patch.object(c.assets, 'checked_asset', return_value=Path('/synthetic/metadata-only')))
            step = stack.enter_context(patch.object(torch.optim.Adam, 'step', side_effect=AssertionError('no optimizer')))
            try:
                result = c.collect({}, state)
            finally:
                self.assertTrue(all(not model._forward_pre_hooks for model in models.values()))
            step.assert_not_called()
            return result

    def test_complete_synthetic_collect_reads_reference_first_and_exactly_replays_all_arms(self):
        result = self._mock_collect()
        self.assertEqual(result['train_selected'].shape, (512, 24))
        self.assertEqual(result['audit_clean'].shape, (224, 24))
        self.assertEqual(result['audit_conditions'].shape, (224, 6))
        self.assertEqual(int(result['audit_moving'].sum()), 60)
        self.assertEqual(result['audit_moving'].dtype, np.bool_)
        self.assertEqual(len(result['ledger']), 768)
        self.assertEqual(result['integrity']['generator_forwards'], 672)
        self.assertIn('forward_pre_hook', result['integrity']['call_count_method'])
        self.assertEqual(result['integrity']['training_forwards'], 0)
        self.assertEqual(result['integrity']['victim_forwards'], 0)
        self.assertTrue(result['integrity']['source_budget_replay_exact'])
        self.assertFalse(result['integrity']['internal_dev_arrays_loaded'])
        self.assertFalse(result['train_selected'].flags.writeable)
        for values in result['triggered_by_arm'].values():
            self.assertEqual(values.shape, (224, 24))
            self.assertFalse(values.flags.writeable)

    def test_budget_mismatch_stops_and_preserves_partial_graph_ledger(self):
        with self.assertRaisesRegex(ValueError, 'exactly replay') as caught:
            self._mock_collect(corrupt_budget=True)
        ledger = caught.exception.graph_access_ledger
        self.assertEqual(len(ledger), 513)
        self.assertEqual([row['role'] for row in ledger], ['train'] * 512 + ['audit'])


if __name__ == '__main__':
    unittest.main()
