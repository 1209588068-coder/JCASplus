"""Metadata-only and synthetic workflow checks; no real graph loads or fitting."""
from contextlib import ExitStack
from copy import deepcopy
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import numpy as np
import torch

from experiments.spear_amplitude_control_v1 import workflow as w
from experiments.spear_content_attention_v1.context import AttentionContext
from experiments.spear_domain_training_v1.module import DomainConstrainedGenerator
from tests.test_spear_domain_training_module import setup


def calibration_fixture():
    anchor, support, x, _, _ = setup()
    continuation = DomainConstrainedGenerator(anchor, support, output_mode='domain_projection')
    continuation.eval().requires_grad_(False)
    generators = dict(continuation=continuation,
        unconditional=w.FrozenAmplitudeGenerator(continuation, .4))
    x = x.repeat(5, 1)
    edges = torch.stack((torch.arange(30), torch.arange(30).roll(1)))
    context = AttentionContext(edges, torch.zeros(30, dtype=torch.long),
        torch.zeros(30, dtype=torch.long), 30, torch.arange(30))
    targets = torch.arange(26)
    train = dict(x=x, edge_index=edges, y=torch.zeros(30, dtype=torch.long))
    records, metadata = {}, {}
    for arm, generator in generators.items():
        changed = generator.inject(x, context, targets, detach=True)
        records[arm] = dict(generator_record=arm)
        metadata[arm] = dict(training_budget=w.modification_statistics(x, changed.features, targets, support))
    return generators, train, context, dict(idx_attach=targets), records, metadata


def train_dev_fixture():
    roles = {role: [dict(scenario_id=f'{role}_{index}', split='train', role=role,
        graph_sha256=f'{offset + index:064x}') for index in range(count)]
        for role, count, offset in (('train', 512, 0), ('dev', 128, 512))}
    ledger = [dict(scenario_id=row['scenario_id'], role=role, split='train',
        sha256=row['graph_sha256'], status='READ_COMPLETE')
        for role in ('train', 'dev') for row in roles[role]]
    return dict(roles=roles), ledger


def barrier_fixture():
    parent, ledger = train_dev_fixture()
    plan = dict(source_template=dict(parent=parent))
    records = {str(seed): dict(trace=dict(training_forwards=200, eval_forwards=200),
        victim_seed=seed, victim='victim', generator='generator', calibration='calibration') for seed in w.SEEDS}
    barrier = dict(plan_sha256=w.source_fit.canonical_hash(plan), seeds=list(w.SEEDS),
        victim_epochs_total=600, generator_updates=0, audit_arrays_loaded=False, train_dev_ledger='ledger',
        training={str(seed): str(seed) for seed in w.SEEDS},
        final_model_hashes={str(seed): dict(generator=f'g{seed}', victim=f'v{seed}') for seed in w.SEEDS})
    fitted = dict(barrier_ref='barrier', trained={seed: (f'g{seed}', f'v{seed}') for seed in w.SEEDS})
    return plan, fitted, {'barrier': barrier, 'ledger': ledger, **records}


class AmplitudeWorkflowTests(unittest.TestCase):
    def test_real_source_metadata_never_loads_arrays_or_models(self):
        with patch.object(np, 'load', side_effect=AssertionError('array access')) as arrays, \
                patch.object(torch, 'load', side_effect=AssertionError('model access')) as models:
            plan = w.fields()
        arrays.assert_not_called(); models.assert_not_called()
        self.assertEqual(plan['seeds'], list(w.SEEDS))
        self.assertEqual(set(plan['sources']), {str(seed) for seed in w.SEEDS})
        self.assertEqual(plan['source_template']['parent']['seed'], 20260621)
        for source in plan['sources'].values():
            self.assertEqual(set(source['reports']), set(w.SOURCE_ARMS))
            self.assertEqual(set(source['training']), set(w.SOURCE_ARMS))
        contract = plan['contract']
        self.assertEqual(contract['added_training']['total_victim_epochs'], 600)
        self.assertEqual(contract['acceptance']['moving_incremental_asr_min'], .8)
        for key in ('original_val_arrays_loaded', 'original_test_arrays_loaded',
                    'physical_validity_claim', 'independent_confirmation', 'automatic_promotion'):
            self.assertFalse(contract[key])

    def test_only_new_namespace_children_allowed(self):
        base = w.ROOT / 'record/reproduction' / w.VERSION
        for path in (w.ROOT, base, w.SOURCE, w.ROOT / 'record/v6',
                     w.ROOT / 'record/reproduction/spear_distribution_training_v1/new', base / '../escape'):
            with self.subTest(path=path), self.assertRaises(ValueError):
                w.output_path(path)
        self.assertEqual(w.output_path(base / 'new'), base / 'new')

    def test_existing_output_rejected_before_metadata_reads(self):
        with TemporaryDirectory() as tmp, patch.object(w, 'output_path', return_value=Path(tmp)), \
                patch.object(w, 'fields', side_effect=AssertionError('overwrite')) as fields:
            with self.assertRaises(FileExistsError): w.prepare(tmp)
            fields.assert_not_called()

    def test_each_restart_marker_prevents_launch(self):
        for name in ('started.json', 'launcher.json', 'launch_claim.json', 'failure.json',
                     'summary.json', 'console.log', 'training'):
            with self.subTest(marker=name), TemporaryDirectory() as tmp, ExitStack() as stack:
                path = Path(tmp) / 'plan.json'
                (path.parent / name).mkdir()
                stack.enter_context(patch.object(w, 'load_plan', return_value=(path, {})))
                spawn = stack.enter_context(patch.object(w.subprocess, 'Popen', side_effect=AssertionError('restart')))
                with self.assertRaisesRegex(ValueError, 'cannot be restarted'): w.launch(path)
                spawn.assert_not_called()

    def test_actual26_calibration_matches_mean_l1_and_preserves_scope(self):
        generators, train, context, idx, records, metadata = calibration_fixture()
        before = {key: value.clone() for key, value in train.items()}
        states = {arm: w.state_sha256(model) for arm, model in generators.items()}
        rng = torch.random.get_rng_state().clone()
        with patch.object(w, 'checked_json', side_effect=lambda ref: deepcopy(metadata[ref])), \
                patch.object(np, 'load', side_effect=AssertionError('array access')), \
                patch.object(torch, 'load', side_effect=AssertionError('model access')):
            control, poison, record = w.calibration_record(generators, train, context, idx, records)
        self.assertEqual(record['target_count'], 26)
        self.assertAlmostEqual(record['scale'], .4, places=6)
        self.assertAlmostEqual(record['actual_attachment_mean_l1'], record['target_attachment_mean_l1'], places=5)
        self.assertIn('TRAIN idx_attach only', record['population'])
        w.source_fit.assert_output_scope(train['x'], poison.features, idx['idx_attach'], control)
        self.assertTrue(torch.equal(poison.features[26:], train['x'][26:]))
        self.assertTrue(torch.equal(poison.edge_index, train['edge_index']))
        self.assertTrue(bool((poison.edge_weight == 1).all()))
        for key, value in train.items(): self.assertTrue(torch.equal(value, before[key]), key)
        self.assertEqual({arm: w.state_sha256(model) for arm, model in generators.items()}, states)
        self.assertTrue(torch.equal(torch.random.get_rng_state(), rng))

    def test_wrong_attachment_count_and_historical_budget_rejected(self):
        generators, train, context, idx, records, metadata = calibration_fixture()
        with self.assertRaisesRegex(ValueError, 'original26'):
            w.calibration_record(generators, train, context, dict(idx_attach=idx['idx_attach'][:25]), records)
        for arm in w.SOURCE_ARMS:
            wrong = deepcopy(metadata)
            wrong[arm]['training_budget']['normalized_l1_per_target'][0] += .01
            with self.subTest(arm=arm), patch.object(w, 'checked_json', side_effect=lambda ref: wrong[ref]), \
                    self.assertRaisesRegex(ValueError, 'source modification record'):
                w.calibration_record(generators, train, context, idx, records)

    def test_every_seed_barrier_checked_before_any_audit_or_model_load(self):
        for mutation in ('epochs', 'seed_count', 'generator_update', 'audit_access', 'last_seed_fit', 'model_hash'):
            plan, fitted, metadata = barrier_fixture()
            barrier = metadata['barrier']
            if mutation == 'epochs': barrier['victim_epochs_total'] = 599
            elif mutation == 'seed_count': barrier['seeds'].pop()
            elif mutation == 'generator_update': barrier['generator_updates'] = 1
            elif mutation == 'audit_access': barrier['audit_arrays_loaded'] = True
            elif mutation == 'last_seed_fit': metadata[str(w.SEEDS[-1])]['trace']['eval_forwards'] = 199
            else: barrier['final_model_hashes'][str(w.SEEDS[-1])]['victim'] = 'changed'
            with self.subTest(mutation=mutation), ExitStack() as stack:
                stack.enter_context(patch.object(w, 'checked_json', side_effect=lambda ref: metadata[ref]))
                stack.enter_context(patch.object(w.assets, 'checked_asset', return_value=Path('/synthetic')))
                stack.enter_context(patch.object(w, 'state_sha256', side_effect=lambda model: model))
                load = stack.enter_context(patch.object(torch, 'load', side_effect=AssertionError('early model')))
                audit = stack.enter_context(patch.object(w.baseline, 'evaluate', side_effect=AssertionError('early audit')))
                with self.assertRaises(ValueError):
                    w.evaluate_seed(Path('/synthetic'), plan, fitted, w.SEEDS[0], Mock())
                load.assert_not_called(); audit.assert_not_called()
        plan, fitted, metadata = barrier_fixture()
        with patch.object(w, 'checked_json', side_effect=lambda ref: metadata[ref]), \
                patch.object(w.assets, 'checked_asset'), patch.object(w, 'state_sha256', side_effect=lambda model: model):
            self.assertEqual(w.check_barrier(Path('/synthetic'), plan, fitted), metadata['barrier'])

    def test_exact_train512_dev128_ledger_is_valid_without_mutation(self):
        parent, ledger = train_dev_fixture()
        before = deepcopy((parent, ledger))
        self.assertEqual(len(parent['roles']['train']), 512)
        self.assertEqual(len(parent['roles']['dev']), 128)
        self.assertEqual([row['role'] for row in ledger], ['train'] * 512 + ['dev'] * 128)
        self.assertTrue(all(row['split'] == 'train' and row['status'] == 'READ_COMPLETE' for row in ledger))
        w.validate_train_dev_ledger(ledger, parent)
        self.assertEqual((parent, ledger), before)

    def test_corrupt_bound_ledger_blocks_evaluation_before_checkpoint_or_graph_access(self):
        for mutation in ('count', 'order', 'role', 'split', 'hash', 'status', 'duplicate', 'parent_count'):
            plan, fitted, metadata = barrier_fixture()
            ledger, parent = metadata['ledger'], plan['source_template']['parent']
            if mutation == 'count': ledger.pop()
            elif mutation == 'order': ledger[0], ledger[1] = ledger[1], ledger[0]
            elif mutation == 'role': ledger[512]['role'] = 'train'
            elif mutation == 'split': ledger[512]['split'] = 'val'
            elif mutation == 'hash': ledger[-1]['sha256'] = 'f' * 64
            elif mutation == 'status': ledger[-1]['status'] = 'OPENING'
            elif mutation == 'duplicate': ledger[-1] = deepcopy(ledger[-2])
            else:
                parent['roles']['dev'].pop()
                metadata['barrier']['plan_sha256'] = w.source_fit.canonical_hash(plan)
            with self.subTest(mutation=mutation), self.assertRaisesRegex(ValueError, '640-scene'):
                w.validate_train_dev_ledger(ledger, parent)
            with self.subTest(barrier_mutation=mutation), ExitStack() as stack:
                read = stack.enter_context(patch.object(w, 'checked_json', side_effect=lambda ref: metadata[ref]))
                asset = stack.enter_context(patch.object(w.assets, 'checked_asset', side_effect=AssertionError('early checkpoint')))
                model = stack.enter_context(patch.object(torch, 'load', side_effect=AssertionError('early model')))
                arrays = stack.enter_context(patch.object(np, 'load', side_effect=AssertionError('early graph')))
                audit = stack.enter_context(patch.object(w.baseline, 'evaluate', side_effect=AssertionError('early audit')))
                with self.assertRaisesRegex(ValueError, '640-scene'):
                    w.evaluate_seed(Path('/synthetic'), plan, fitted, w.SEEDS[0], Mock())
                self.assertEqual([call.args[0] for call in read.call_args_list], ['barrier', 'ledger'])
                asset.assert_not_called(); model.assert_not_called()
                arrays.assert_not_called(); audit.assert_not_called()

    def test_source_initialization_and_rng_mismatch_stop_before_victim_fit(self):
        for mismatch in ('initialization_digest', 'fit_rng_digest'):
            with self.subTest(mismatch=mismatch), TemporaryDirectory() as tmp, ExitStack() as stack:
                train = dict(x=torch.zeros((30, 784)), y=torch.zeros(30, dtype=torch.long))
                poison = SimpleNamespace(features=train['x'], edge_index=torch.empty((2, 0), dtype=torch.long),
                                         edge_weight=torch.empty(0))
                model = SimpleNamespace(selected_coordinates=torch.arange(30), hard_support=torch.arange(30) < 24,
                                        inject=Mock(return_value=poison))
                sources = {seed: {arm: model for arm in w.SOURCE_ARMS} for seed in w.SEEDS}
                expected = dict(initialization_digest='same-init', fit_rng_digest='same-rng')
                records = {seed: {arm: deepcopy(expected) for arm in w.SOURCE_ARMS} for seed in w.SEEDS}
                records[w.SEEDS[0]]['unconditional'][mismatch] = 'wrong'
                parent, ledger_rows = train_dev_fixture()
                parent.update(seed=20260621, references=dict(input_contract={}))
                plan = dict(source_template=dict(parent=parent), source_reference={})
                def load_train(source, normalizer, ledger):
                    ledger.extend(deepcopy(ledger_rows[:512]))
                    return [], None, train, dict(idx_attach=torch.arange(26)), None
                def read_dev(row, parent, *, allowed_role, ledger):
                    self.assertEqual(allowed_role, 'dev')
                    ledger.append(dict(scenario_id=row['scenario_id'], role='dev', split='train',
                        sha256=row['graph_sha256'], status='READ_COMPLETE'))
                    return dict(x=train['x'])
                stack.enter_context(patch.object(w, 'restore', return_value=({}, None, torch.arange(30), None, sources, records)))
                stack.enter_context(patch.object(w.previous, 'load_train', side_effect=load_train))
                stack.enter_context(patch.object(w, 'read_role_part', side_effect=read_dev))
                stack.enter_context(patch.object(w, 'transform_features', side_effect=lambda x, normalizer: x))
                stack.enter_context(patch.object(w.previous, 'input_digest', return_value='unchanged'))
                stack.enter_context(patch.object(w.source_fit, 'check_outer', return_value=torch.arange(30)))
                stack.enter_context(patch.object(w.source_fit, 'assert_output_scope'))
                stack.enter_context(patch.object(w, 'checked_json', return_value={}))
                stack.enter_context(patch.object(w, 'collect_reference', return_value=dict(
                    train_selected=None, train_conditions=None, train_moving=None)))
                stack.enter_context(patch.object(w.statistics, 'fit_reference', return_value=SimpleNamespace(to_metadata=lambda: {})))
                stack.enter_context(patch.object(w, 'calibration_record', return_value=(model, poison, {})))
                stack.enter_context(patch.object(w, 'modification_statistics', return_value={}))
                stack.enter_context(patch.object(w.assets, 'write_json'))
                stack.enter_context(patch.object(w.assets, 'asset', return_value={}))
                stack.enter_context(patch.object(w.baseline.checkpoint, 'combine', return_value={}))
                stack.enter_context(patch.object(w, 'victim_initialization_contract', return_value=expected))
                fit = stack.enter_context(patch.object(w, 'fit_victim', side_effect=AssertionError('mismatched training')))
                with self.assertRaisesRegex(ValueError, 'within-seed initialization/RNG'):
                    w.fit_controls(Path(tmp), plan, Mock())
                fit.assert_not_called()

    def test_training_failure_never_evaluates_or_aggregates(self):
        with TemporaryDirectory() as tmp, ExitStack() as stack:
            path = Path(tmp) / 'plan.json'
            stack.enter_context(patch.object(w, 'load_plan', return_value=(path, {})))
            stack.enter_context(patch.object(w.assets, 'asset', return_value={}))
            writes = stack.enter_context(patch.object(w.assets, 'write_json'))
            stack.enter_context(patch.object(w.replication.source, 'state_writer', return_value=Mock()))
            stack.enter_context(patch.object(torch, 'set_num_threads'))
            stack.enter_context(patch.object(w, 'fit_controls', side_effect=ValueError('fit failed')))
            evaluate = stack.enter_context(patch.object(w, 'evaluate_seed'))
            aggregate = stack.enter_context(patch.object(w.reporting, 'aggregate'))
            with self.assertRaisesRegex(ValueError, 'fit failed'): w.run(path)
            evaluate.assert_not_called(); aggregate.assert_not_called()
            names = [call.args[0].name for call in writes.call_args_list]
            self.assertIn('failure.json', names); self.assertNotIn('summary.json', names)

    def test_all3_fit_barrier_precedes_every_evaluation_and_failed_gates_are_retained(self):
        with TemporaryDirectory() as tmp, ExitStack() as stack:
            path, events = Path(tmp) / 'plan.json', []
            stack.enter_context(patch.object(w, 'load_plan', return_value=(path, {})))
            stack.enter_context(patch.object(w.assets, 'asset', return_value={}))
            stack.enter_context(patch.object(w.assets, 'write_json'))
            stack.enter_context(patch.object(w.replication.source, 'state_writer', return_value=Mock()))
            stack.enter_context(patch.object(torch, 'set_num_threads'))
            def fit(*args):
                events.append('all3_fitted'); return dict(barrier_ref={})
            def evaluate(output, plan, fitted, seed, progress):
                events.append(seed)
                return dict(seed=seed, review=dict(passed=False), distribution={})
            stack.enter_context(patch.object(w, 'fit_controls', side_effect=fit))
            stack.enter_context(patch.object(w, 'check_barrier', side_effect=lambda *args: events.append('barrier')))
            stack.enter_context(patch.object(w, 'evaluate_seed', side_effect=evaluate))
            aggregate = stack.enter_context(patch.object(w.reporting, 'aggregate', return_value={}))
            result = w.run(path)
            self.assertEqual(events, ['all3_fitted', 'barrier', *w.SEEDS])
            self.assertEqual([item['seed'] for item in aggregate.call_args.args[0]], list(w.SEEDS))
            self.assertTrue(all(item['review']['passed'] is False for item in aggregate.call_args.args[0]))
            self.assertEqual(result['status'], 'AMPLITUDE_CONTROL_COMPLETE_REVIEW_REQUIRED')


if __name__ == '__main__':
    unittest.main()
