"""Train three matched distribution-regularization arms on registered TRAIN roles.

Offline AV2/self-owned GNN research; no formal VAL/TEST or frozen-result edits.
A DPGBA-inspired loss adaptation, not a complete DPGBA reproduction.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
from types import SimpleNamespace

import torch

from experiments.spear_domain_audit_v1 import workflow as audit_source
from experiments.spear_domain_training_v1 import workflow as source
from experiments.spear_pair_role_generator_v1.training import ResidualTrainingConfig
from experiments.spear_content_attention_v1.workflow import SceneInjector
from experiments.spear_semantic_support_v1.module import modification_statistics
from experiments.spear_semantic_support_v1.training import state_sha256
from experiments.spear_sage_pilot_v1.fitting import enrich_train_provenance
from experiments.spear_semantic_support_review_v1 import read_tables
from experiments.spear_seed_stability_v1.workflow import verify_target_identity
from experiments.spear_dual_clean_proxy_v1.workflow import verify_normal_clean
from . import fitting
from .reporting import review_evaluations


ROOT, assets, baseline = audit_source.ROOT, audit_source.assets, audit_source.baseline
VERSION = 'spear_distribution_training_v1'
ARMS = ('continuation', 'unconditional', 'conditional')
SOURCE_PLAN = ROOT / 'record/reproduction/spear_domain_training_v1/pilot_20261027_seed20260621_v1/plan.json'
SOURCE_PLAN_SHA = '09cd97069b53cc4723cfad5b31703c36d3fa155220a00b014cd894ba38b56306'
SOURCE_REVIEW_SHA = '047ab72743cc25c0b8850eef146569d8d95c372095e4f1c351952b311ed38c57'
SOURCE_COMPLETION_SHA = 'a319fa82fc924d9d0099ce5b7dc7bc61d44e9865dc04bfe92dc85241930f4f31'


def fields():
    """Only source bytes, metadata and hashes; no model/graph deserialization."""
    source_ref = dict(path=str(SOURCE_PLAN), sha256=SOURCE_PLAN_SHA)
    assets.checked_asset(source_ref)
    _, old = source.load_plan(SOURCE_PLAN)
    review_ref = dict(path=str(SOURCE_PLAN.parent / 'review.json'), sha256=SOURCE_REVIEW_SHA)
    review = audit_source.previous.checked_json(review_ref)
    completion_ref = dict(path=str(SOURCE_PLAN.parent / 'summary.json'), sha256=SOURCE_COMPLETION_SHA)
    complete = audit_source.previous.checked_json(completion_ref)
    if (complete['status'] != 'DOMAIN_TRAINING_COMPLETE_REVIEW_REQUIRED'
            or complete['plan'] != source_ref or complete['review'] != review_ref
            or review['status'] != 'DOMAIN_TRAINING_REVIEW_COMPLETE'):
        raise ValueError('Require completed source experiment and bound review')
    report_ref = complete['reports']['domain_projection']
    anchor = audit_source.previous.checked_json(report_ref)
    training_ref = anchor['training']
    training = audit_source.previous.checked_json(training_ref)
    refs = dict(old['references'], sage_generator=old['references']['generator'],
                generator=training['generator'], surrogate=training['surrogate'])
    for ref in refs.values():
        assets.checked_asset(ref)
    data_contract = dict(old['data_contract'], version=VERSION,
                         kind='registered_training_role_reader_for_distribution_continuation')
    sources = set(Path(__file__).parent.glob('*.py'))
    sources.update((ROOT / 'tests').glob('test_spear_distribution_training*.py'))
    return dict(
        version=VERSION, source_plan=source_ref, source_completion=completion_ref,
        source_review=review_ref, source_training=training_ref, source_report=report_ref,
        parent=old['parent'], data_contract=data_contract, references=refs,
        hard_support=old['hard_support'], original_report=old['original_report'],
        original_csvs=old['original_csvs'], expected_counts=old['expected_counts'],
        historical_expected_model_hashes=old['expected_model_hashes'], arms=list(ARMS),
        training_config=old['training_config'], training_seed=old['training_seed'],
        distribution_config=dict(lr=.0002, weight_decay=.0005, weight=.1, seed=20261621,
            condition_coordinates=[149, 199, 507, 557, 718, 721], hidden_dim=64),
        source_catalog={str(p.relative_to(ROOT)): assets.sha256(p) for p in sorted(sources)},
        execution=dict(device='cpu', torch_threads=2, automatic_retries=False),
        contract=dict(
            initialization='all arms restore the same completed domain_projection generator and surrogate',
            support='same fixed SAGE24 of original30; native output clamp[-10,10] in all arms',
            trainable='original residual, separate surrogate; distribution discriminator only in two arms',
            frozen='base generator, shadow, both clean proxies, inputs, topology, support and conditions',
            losses='old targetNLL + cosine0.1 + dual-cleanKL1; optional nonsaturating BCE distribution0.1',
            discriminator='same30-64-64-1 LeakyReLU network and private seed;24 editable values plus6 conditions',
            conditions='clean standardized observed A/B vx,vy,current distance,closing speed; zero in unconditional',
            real_distribution='clean editable24 on the same fixed538 training outer rows; no new sampling',
            discriminator_objective='balanced real/fake BCE; one step before each generator step; no label conditioning',
            per_arm=dict(residual_steps=200, surrogate_steps=200, victim_epochs=200),
            discriminator_steps=dict(continuation=0, unconditional=200, conditional=200),
            extra_compute='distribution arms add D updates; equal main steps do not mean equal total compute',
            victim='fresh identical GraphSAGE seed/init; same1902 supervision; no old-victim fine-tuning',
            checkpoint='generator final epoch199; victim best clean internal-dev AUC earliest tie',
            data_roles='original TRAIN: train512 dev128; reused audit256 only after all3 arms finish',
            primary_comparison='conditional versus unconditional and matched continuation',
            historical_reference='old SAGE24 and projected source are descriptive, not equal-budget controls',
            performance_failure='report every arm; no retries, threshold changes or automatic followup',
            acceptance=dict(overall_incremental_asr_min=.85, moving_incremental_asr_min=.85,
                adjacent_incremental_fp_max_exclusive=.05, clean_auc_drop_max=.005,
                clean_recall_drop_max=.05, projected_outside_coordinates=0,
                quality_references='all versus SAGE24; both distribution arms also versus matched continuation'),
            distribution_measurement='D losses are training diagnostics, not proof of distribution preservation',
            literature='DPGBA KDD2024 in-distribution discriminator idea, partial derived-feature adaptation',
            original_val_arrays_loaded=False, original_test_arrays_loaded=False,
            independent_confirmation=False, physical_validity_claim=False, new_method_claim=False,
            automatic_followup=False, automatic_promotion=False))


def output_path(path):
    path = Path(path).resolve()
    namespace = ROOT / 'record/reproduction' / VERSION
    if path == namespace or not path.is_relative_to(namespace):
        raise ValueError('Require a child of the new distribution-training namespace')
    return path


def prepare(output):
    output = output_path(output)
    if output.exists():
        raise FileExistsError('Never overwrite an existing experiment')
    plan = dict(created_at_utc=baseline.now(), **fields())
    output.mkdir(parents=True, exist_ok=False)
    assets.write_json(output / 'plan.json', plan)
    with tarfile.open(output / 'source_snapshot.tar', 'x') as archive:
        for name in plan['source_catalog']:
            archive.add(ROOT / name, arcname=name, recursive=False)
    return output / 'plan.json'


def load_plan(path):
    path = Path(path).resolve()
    output_path(path.parent)
    if path.name != 'plan.json':
        raise ValueError('Require plan.json')
    plan = json.loads(path.read_text())
    if {k: v for k, v in plan.items() if k != 'created_at_utc'} != fields():
        raise ValueError('Bound source, protocol or evidence changed')
    return path, plan


def state_writer(output):
    def update(**record):
        item = dict(pid=os.getpid(), at=baseline.now(), **{'status': 'RUNNING', **record})
        temporary = output / 'state.json.tmp'
        temporary.write_text(json.dumps(item, indent=2, allow_nan=False) + '\n')
        temporary.replace(output / 'state.json')
    return update


class AuditedInjector(SceneInjector):
    """Record actual scope/domain, not only a configured coordinate budget."""
    def __init__(self, generator, seed):
        super().__init__(generator, seed)
        self.budgets = []

    def bind(self, part):
        self.part = part
        super().bind(dict(part, x=part['x'].copy()))

    def inject_trigger(self, indices, x, edges, weights, device):
        output, new_edges, new_weights = super().inject_trigger(indices, x, edges, weights, device)
        stats = modification_statistics(x, output, indices, self.generator.hard_support)
        selected = self.generator.selected_coordinates[self.generator.hard_support]
        values = output[indices[:, None], selected[None, :]]
        outside = int(((values < -10.) | (values > 10.)).sum())
        if self.generator.output_mode == 'domain_projection' and outside:
            raise ValueError('Trained projection produced an out-of-domain coordinate')
        self.budgets.append(dict(scenario_id=self.part['scenario_id'], pair_index=int(indices[0]),
            motion_regime='moving' if self.part['motion_regime'][int(indices[0])] else 'slow',
            coordinates_outside_domain=outside, **stats))
        return output, new_edges, new_weights


class BoundAuditReader:
    """Exact-role read guard and immutable shared scene cache across three arms."""
    def __init__(self, parent, normalizer, ledger, parts, hashes, injector, arm):
        if arm not in ARMS:
            raise ValueError('Unknown audit arm')
        self.parent, self.normalizer, self.ledger = parent, normalizer, ledger
        self.parts, self.hashes, self.injector, self.arm = parts, hashes, injector, arm

    def __call__(self, row):
        if (row not in self.parent['roles']['audit'] or row.get('split') != 'train'
                or row.get('role') != 'audit'):
            raise ValueError('Only the registered original TRAIN audit is allowed')
        scene = row['scenario_id']
        if scene not in self.parts:
            if self.arm != 'continuation':
                raise ValueError('Only the first audit arm may load graph arrays')
            self.parts[scene] = baseline.field.read_audit_part(row, self.parent, self.normalizer, self.ledger)
            self.hashes[scene] = baseline.field.part_digest(self.parts[scene])
        if baseline.field.part_digest(self.parts[scene]) != self.hashes[scene]:
            raise ValueError('Audit inputs changed')
        self.injector.bind(self.parts[scene])
        return self.parts[scene]


def evaluate_completed(output, plan, fitted, progress):
    """The completion barrier is checked before clean-reference/graph loading."""
    fitting.validate_barrier(output / 'training', plan, fitted)
    stub = SimpleNamespace(x=torch.empty((0, 784)), y=torch.tensor([0, 1]))
    reference = fitted['api']['model_construct'](fitted['args'], 'GraphSage', stub, torch.device('cpu'))
    reference.load_state_dict(torch.load(assets.checked_asset(plan['parent']['references']['clean_reference']),
                                         map_location='cpu', weights_only=True), strict=True)
    reference.eval().requires_grad_(False)
    reports, refs, ledger, parts, part_hashes = {}, {}, [], {}, {}
    try:
        for arm in ARMS:
            generator, victim = fitted['trained'][arm]
            for model in (generator, victim):
                model.zero_grad(set_to_none=True)
                model.eval().requires_grad_(False)
            models = dict(clean_reference=reference, victim=victim)
            all_models = dict(generator=generator, **models)
            hashes = {key: state_sha256(model) for key, model in all_models.items()}
            injector = AuditedInjector(generator, plan['parent']['shuffle_seed'])

            reader = BoundAuditReader(plan['parent'], fitted['normalizer'], ledger, parts, part_hashes, injector, arm)

            def notify(**record):
                progress(arm=arm, **record)

            with torch.no_grad():
                result = baseline.evaluate(plan['parent'], output / 'audit' / arm, models, injector, reader, notify)
            result = enrich_train_provenance(plan['parent'], ledger, result)
            if result['audit_counts'] != plan['expected_counts'] or len(injector.budgets) != 224:
                raise ValueError('Audit population or target budget changed')
            read_tables(result, plan['parent']['roles']['audit'])
            identity = verify_target_identity(output / 'audit' / arm / 'targets.csv',
                                              plan['original_csvs']['raw_targets']['path'])
            reference_replay = verify_normal_clean(output / 'audit' / arm / 'clean_pair_scores.csv',
                                                   plan['original_csvs']['raw_clean_scores']['path'])
            if hashes != {key: state_sha256(model) for key, model in all_models.items()}:
                raise ValueError('Evaluation changed model weights')
            if part_hashes != {key: baseline.field.part_digest(part) for key, part in parts.items()}:
                raise ValueError('Evaluation changed source inputs')
            directory = output / 'audit' / arm
            assets.write_json(directory / 'budgets.json', injector.budgets)
            info = dict(evaluation=result, unchanged_model_hashes=hashes,
                targets_identity_verified=identity, clean_reference_replay=reference_replay,
                budgets=assets.asset(directory / 'budgets.json'),
                training=fitted['barrier']['training'][arm])
            assets.write_json(directory / 'summary.json', info)
            reports[arm], refs[arm] = result, assets.asset(directory / 'summary.json')
        if len(parts) != 256 or len(ledger) != 256:
            raise ValueError('Audit read ledger incomplete')
        original = audit_source.previous.checked_json(plan['original_report'])['evaluation']
        historical = audit_source.previous.checked_json(plan['source_report'])['evaluation']
        decision = review_evaluations(reports, original, historical)
        assets.write_json(output / 'review.json', decision)
        return dict(reports=refs, review=assets.asset(output / 'review.json'))
    finally:
        assets.write_json(output / 'audit_graph_access_ledger.json', ledger)


def run(path):
    path, plan = load_plan(path)
    output = path.parent
    assets.write_json(output / 'started.json', dict(pid=os.getpid(), at=baseline.now(), plan=assets.asset(path)))
    state = state_writer(output)
    state(status='RUNNING', stage='training_preflight')
    try:
        fitted = fitting.fit_arms(output / 'training', plan, progress=state)
        load_plan(path)
        evidence = evaluate_completed(output, plan, fitted, state)
        load_plan(path)
        summary = dict(status='DISTRIBUTION_TRAINING_COMPLETE_REVIEW_REQUIRED', at=baseline.now(),
            plan=assets.asset(path), optimization_complete=fitted['optimization_complete'],
            train_dev_ledger=fitted['train_dev_ledger_ref'],
            audit_ledger=assets.asset(output / 'audit_graph_access_ledger.json'), **evidence,
            original_val_arrays_loaded=False, original_test_arrays_loaded=False,
            independent_confirmation=False, automatic_followup=False, automatic_promotion=False)
        assets.write_json(output / 'summary.json', summary)
        state(status=summary['status'], stage='complete')
        return summary
    except Exception as exc:
        assets.write_json(output / 'failure.json', dict(error=str(exc), at=baseline.now(), automatic_retry=False))
        state(status='STOPPED_DISTRIBUTION_TRAINING_ERROR', error=str(exc))
        raise


def launch(path):
    path, _ = load_plan(path)
    if any((path.parent / name).exists() for name in ('started.json', 'training', 'launcher.json', 'failure.json')):
        raise ValueError('An existing run cannot be restarted')
    command = [sys.executable, '-B', '-u', '-m', 'experiments.spear_distribution_training_v1.workflow',
               'run', '--plan', str(path)]
    environment = dict(os.environ, CUDA_VISIBLE_DEVICES='', PYTHONDONTWRITEBYTECODE='1',
                       OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
    with (path.parent / 'console.log').open('xb') as log:
        process = subprocess.Popen(command, cwd=ROOT, env=environment, stdout=log,
                                   stderr=subprocess.STDOUT, start_new_session=True)
    record = dict(pid=process.pid, command=command, at=baseline.now(), plan=assets.asset(path), automatic_retry=False)
    assets.write_json(path.parent / 'launcher.json', record)
    return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    child = commands.add_parser('prepare'); child.add_argument('--output-dir', required=True)
    for name in ('check', 'run', 'launch'):
        child = commands.add_parser(name); child.add_argument('--plan', required=True)
    args = parser.parse_args()
    if args.command == 'prepare':
        print(prepare(args.output_dir))
    elif args.command == 'check':
        load_plan(args.plan); print('DISTRIBUTION_TRAINING_METADATA_PASS; no arrays/models/jobs')
    elif args.command == 'launch':
        print(json.dumps(launch(args.plan), indent=2))
    else:
        result = run(args.plan)
        print(json.dumps({key: result[key] for key in ('status', 'at', 'review')}, indent=2))


if __name__ == '__main__':
    main()
