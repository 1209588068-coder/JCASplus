"""Isolated synthetic seed tests; never load or train on real graph assets."""
from contextlib import nullcontext
from copy import deepcopy
import hashlib
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np
import torch
from torch import nn

from experiments.spear_distribution_replication_v1 import seeded
from experiments.spear_distribution_training_v1.distribution import DistributionRegularizer
from experiments.spear_pair_role_generator_v1.training import _state_hash
from tests.test_spear_domain_training_module import setup


class SeededReplicationTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)
        anchor, support, self.x, _, _ = setup()
        self.selected = anchor.selected_coordinates[support]
        self.outer = torch.tensor([2, 3, 4])

    def reg(self, arm='conditional', seed=20261622, dtype=torch.float32):
        return seeded.SeededDistributionRegularizer(arm, self.x.to(dtype), self.outer,
                                                     self.selected, seed=seed)

    def test_old_seed_exact_weights_loss_gradient_and_update_parity(self):
        for dtype in (torch.float32, torch.float64):
            for arm in ('continuation', 'unconditional', 'conditional'):
                with self.subTest(dtype=dtype, arm=arm):
                    x = self.x.to(dtype)
                    old = DistributionRegularizer(arm, x, self.outer, self.selected)
                    new = self.reg(arm, 20261621, dtype)
                    self.assertEqual(_state_hash(old.discriminator), _state_hash(new.discriminator))
                    a = x.clone().requires_grad_(True)
                    b = a.detach().clone().requires_grad_(True)
                    loss_a, loss_b = old.generator_loss(a), new.generator_loss(b)
                    self.assertTrue(torch.equal(loss_a, loss_b))
                    if arm != 'continuation':
                        self.assertTrue(torch.equal(torch.autograd.grad(loss_a, a)[0], torch.autograd.grad(loss_b, b)[0]))
                        self.assertEqual(old.discriminator_step(x), new.discriminator_step(x))
                        self.assertEqual(_state_hash(old.discriminator), _state_hash(new.discriminator))
                    self.assertEqual(old.snapshot()['config'], new.snapshot()['config'])

    def test_paired_within_seed_different_across_seeds_preserves_rng_and_ownership(self):
        hashes = []
        for seed in (20261621, 20261622, 20261623):
            group = []
            for arm in ('continuation', 'unconditional', 'conditional'):
                rng = torch.random.get_rng_state().clone()
                numpy_rng = deepcopy(np.random.get_state())
                reg = self.reg(arm, seed)
                self.assertTrue(torch.equal(rng, torch.random.get_rng_state()))
                self.assertEqual(numpy_rng[0], np.random.get_state()[0])
                np.testing.assert_array_equal(numpy_rng[1], np.random.get_state()[1])
                self.assertEqual(tuple(id(p) for p in reg.discriminator.parameters()), reg._parameter_ids)
                if arm == 'continuation':
                    self.assertIsNone(reg.optimizer)
                else:
                    self.assertFalse(reg.optimizer.state)
                    self.assertEqual(tuple(id(p) for p in reg.optimizer.param_groups[0]['params']), reg._parameter_ids)
                self.assertEqual(reg.snapshot()['config']['seed'], seed)
                self.assertEqual(reg.snapshot()['initial_discriminator_sha256'], reg.discriminator_hash())
                self.assertEqual(reg.steps, 0)
                self.assertEqual(reg.generator_calls, 0)
                reg.assert_contract()
                group.append(_state_hash(reg.discriminator))
            self.assertEqual(len(set(group)), 1)
            hashes.append(group[0])
        self.assertEqual(len(set(hashes)), 3)

    def test_unregistered_seeds_and_hyperparameters_rejected(self):
        for value in (True, 20261624, 1, 20261622.0):
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.reg(seed=value)
        for value in (True, 20260621, 20260624, 20260622.0):
            with self.subTest(value=value), self.assertRaises(ValueError):
                seeded.replication_seeds(value)
        with self.assertRaises(ValueError):
            seeded.SeededDistributionRegularizer('conditional', self.x, self.outer, self.selected,
                                                  seed=20261622, weight=.2)
        self.assertEqual(seeded.replication_seeds(20260623),
                         dict(continuation=20263623, discriminator=20261623, victim=20260623))

    def test_loss_implementation_is_inherited_not_forked(self):
        for name in ('discriminator_step', 'generator_loss', 'loss_smoke', 'assert_contract', 'validate_binding'):
            self.assertIs(getattr(seeded.SeededDistributionRegularizer, name), getattr(DistributionRegularizer, name))

    @staticmethod
    def victim_inputs():
        train = dict(x=torch.zeros(1902, 3), y=torch.zeros(1902, dtype=torch.long),
                     edge_index=torch.empty(2, 0, dtype=torch.long))
        dev = dict(x=torch.zeros(3, 3), y=torch.tensor([0, 1, 0]), eligible=torch.tensor([True, True, False]),
                   edge_index=torch.empty(2, 0, dtype=torch.long))
        idx = dict(idx_train=torch.arange(1876), idx_attach=torch.arange(1876, 1902),
                   dev_indices=torch.tensor([1902, 1903]))
        result = dict(poisoned_features=train['x'].clone(), poisoned_labels=train['y'].clone())
        return train, dev, idx, result

    def test_victim_probe_paired_and_distinct_preserves_both_rngs(self):
        train, dev, _, _ = self.victim_inputs()
        api = dict(model_construct=lambda *_: nn.Linear(3, 2))
        before = torch.random.get_rng_state().clone()
        np_before = deepcopy(np.random.get_state())
        seen = []
        for seed in (20260621, 20260622, 20260623):
            signatures = [seeded.victim_initialization_contract(api, None, train, dev, seed) for _ in range(3)]
            self.assertEqual(signatures[0], signatures[1])
            self.assertEqual(signatures[0], signatures[2])
            self.assertEqual(signatures[0]['initial_torch_seed'], seed)
            seen.append(signatures[0]['initialization_digest'])
        self.assertEqual(len(set(seen)), 3)
        self.assertTrue(torch.equal(before, torch.random.get_rng_state()))
        after = np.random.get_state()
        np.testing.assert_array_equal(np_before[1], after[1])
        self.assertEqual(np_before[2:], after[2:])

    def test_victim_fit_explicit_seed_and_original_auc_lifecycle(self):
        train, dev, idx, result = self.victim_inputs()
        events = []
        expected = None

        class Victim(nn.Linear):
            def __init__(self):
                super().__init__(3, 2)

            def fit(inner, x, edges, weights, labels, fit_idx, dev_idx, train_iters, verbose):
                events.append('fit')
                self.assertEqual(train_iters, 200)
                self.assertEqual(len(fit_idx), 1902)
                self.assertEqual(torch.initial_seed(), 20260622)
                self.assertEqual(hashlib.sha256(torch.get_rng_state().numpy().tobytes()).hexdigest(), expected['fit_rng_digest'])
                with torch.no_grad():
                    inner.weight.add_(.2)

        class Trace:
            def __init__(inner, *args):
                self.assertEqual(args[2], 200)

            def observe(inner, model):
                events.append('observe')
                inner.auc_state = deepcopy(model.state_dict())
                inner.best_auc_digest = seeded.baseline.checkpoint.tensor_digest(model)
                return nullcontext()

            def finish(inner, model):
                events.append('finish_before_restore')
                self.assertNotEqual(seeded.baseline.checkpoint.tensor_digest(model), inner.best_auc_digest)
                return dict(training_forwards=200, eval_forwards=200)

        api = dict(model_construct=lambda *_: Victim())
        expected = seeded.victim_initialization_contract(api, None, train, dev, 20260622)
        with tempfile.TemporaryDirectory() as directory, patch.object(seeded.baseline.checkpoint, 'AUCTrace', Trace), \
                patch.object(seeded.baseline.prior.parent.dual, 'dev_quality', return_value={'mock': True}), \
                patch.object(seeded.assets, 'asset', side_effect=lambda path: dict(path=str(path), sha256='synthetic')):
            model, record = seeded.fit_victim(api, None, train, dev, idx, result,
                dict(seed=20260621, victim_epochs=200), Path(directory), lambda **_: None,
                victim_seed=20260622, expected=expected)
            self.assertEqual(events, ['observe', 'fit', 'finish_before_restore'])
            self.assertEqual(record['expected_initialization'], expected)
            self.assertEqual(record['initialization_digest'], expected['initialization_digest'])
            self.assertTrue(all(not p.requires_grad and p.grad is None for p in model.parameters()))
            self.assertFalse(model.training)
            bad = dict(expected, fit_rng_digest='wrong')
            with self.assertRaisesRegex(ValueError, 'independent seed probe'):
                seeded.fit_victim(api, None, train, dev, idx, result, dict(victim_epochs=200),
                    Path(directory), lambda **_: None, victim_seed=20260622, expected=bad)


if __name__ == '__main__':
    unittest.main()
