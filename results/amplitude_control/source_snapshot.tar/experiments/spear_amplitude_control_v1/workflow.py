"""TRAIN-calibrated scalar amplitude control; no source-generator optimization.

Local AV2/self-owned GNN experiment. Reuse bound C/U checkpoints, match TRAIN
attachment mean L1, refit three fresh victims, then audit the fixed development
population. No original validation/test access or writes to old experiments.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import gc
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tarfile
from types import SimpleNamespace

import numpy as np
import torch

from experiments.spear_distribution_replication_v1 import workflow as replication
from experiments.spear_distribution_replication_v1.seeded import (
    fit_victim, victim_initialization_contract,
)
from experiments.spear_distribution_training_v1 import fitting as source_fit
from experiments.spear_distribution_audit_v1 import statistics
from experiments.spear_distribution_audit_v1.collection import collect_reference
from experiments.spear_semantic_support_v1.module import modification_statistics
from experiments.spear_semantic_support_v1.training import state_sha256
from experiments.spear_pair_role_generator_v1.training import _tensor_hash
from experiments.spear_supplied_v1.data import transform_features
from experiments.spear_vehicle_consistency_v1.runner import read_part as read_role_part
from .module import FrozenAmplitudeGenerator, calibrate_scale
from . import reporting


ROOT, assets, baseline = replication.ROOT, replication.assets, replication.baseline
previous, checked_json = source_fit.previous, replication.checked_json
VERSION = 'spear_amplitude_control_v1'
SEEDS = (20260621, 20260622, 20260623)
SOURCE_ARMS = ('continuation', 'unconditional')
SOURCE = ROOT / 'record/reproduction/spear_distribution_replication_v1/run_20261027_seeds22_23_v1'
SOURCE_PLAN_SHA = '1de80324d4867aa1bbc98a8bd52140f1b733dbe8bfca591b58ef6a6785907eb9'
SOURCE_COMPLETION_SHA = '8f98f4fa64c1ca354f1942066b5f78c069d07dfd29c4899ebecbf4781730db41'


def fields():
    """Metadata/hash-only binding; never deserialize graphs or model tensors."""
    master_ref = dict(path=str(SOURCE / 'plan.json'), sha256=SOURCE_PLAN_SHA)
    completion_ref = dict(path=str(SOURCE / 'summary.json'), sha256=SOURCE_COMPLETION_SHA)
    assets.checked_asset(master_ref)
    _, master = replication.load_plan(master_ref['path'])
    completion = checked_json(completion_ref)
    if (completion['status'] != 'DISTRIBUTION_REPLICATION_COMPLETE_REVIEW_REQUIRED'
            or completion['plan'] != master_ref
            or completion['original_val_arrays_loaded'] is not False
            or completion['original_test_arrays_loaded'] is not False):
        raise ValueError('Require the completed frozen three-seed source')
    diagnostic = checked_json(master['source_diagnostic_plan'])
    sources = {}
    for seed in SEEDS:
        ref = (diagnostic['source_completion'] if seed == SEEDS[0]
               else completion['new_seed_reports'][str(seed)])
        done = checked_json(ref)
        expected_status = ('DISTRIBUTION_TRAINING_COMPLETE_REVIEW_REQUIRED' if seed == SEEDS[0]
                           else 'DISTRIBUTION_REPLICATION_SEED_COMPLETE')
        if (done['status'] != expected_status or done['original_val_arrays_loaded'] is not False
                or done['original_test_arrays_loaded'] is not False):
            raise ValueError('Wrong source seed completion or scope')
        source_plan = checked_json(done['plan'])
        if (source_plan['parent'] != master['source_template']['parent']
                or source_plan['hard_support'] != master['source_template']['hard_support']):
            raise ValueError('Source seeds differ in original data/support contract')
        barrier = checked_json(done['optimization_complete'])
        reports, training = {}, {}
        for arm in SOURCE_ARMS:
            report = checked_json(done['reports'][arm])
            record = checked_json(report['training'])
            if (barrier['training'][arm] != report['training'] or record['arm'] != arm
                    or record['trace']['training_forwards'] != 200
                    or record['trace']['eval_forwards'] != 200):
                raise ValueError('Source victim training membership/budget differs')
            for key in ('generator', 'generator_record', 'victim'):
                assets.checked_asset(record[key])
            reports[arm], training[arm] = done['reports'][arm], report['training']
        array_root = (Path(diagnostic['source_completion']['path']).parent if seed == SEEDS[0]
                      else Path(ref['path']).parent)
        # Seed21 distribution diagnostics were a separate, completed no-update replay.
        if seed == SEEDS[0]:
            diagnostic_done = checked_json(master['source_diagnostic_summary'])
            arrays_ref = diagnostic_done['arrays']
            metrics_ref = diagnostic_done['metrics']
        else:
            arrays_ref = assets.asset(array_root / 'distribution_features.npz')
            metrics_ref = done['distribution']
        assets.checked_asset(arrays_ref)
        assets.checked_asset(metrics_ref)
        sources[str(seed)] = dict(completion=ref, plan=done['plan'], reports=reports,
            training=training, barrier=done['optimization_complete'], distribution_arrays=arrays_ref,
            distribution_metrics=metrics_ref)
    paths = sorted(Path(__file__).parent.glob('*.py'))
    paths += sorted((ROOT / 'tests').glob('test_spear_amplitude_control*.py'))
    paths.append(ROOT / 'docs/SPEAR_AMPLITUDE_CONTROL_20261027.md')
    return dict(version=VERSION, seeds=list(SEEDS), source_master=master_ref,
        source_completion=completion_ref, source_template=master['source_template'], sources=sources,
        source_reference=master['source_reference'],
        source_catalog={str(p.relative_to(ROOT)): assets.sha256(p) for p in paths},
        execution=dict(device='cpu', torch_threads=2, sequential=True, automatic_retries=False),
        contract=dict(
            intervention='one fixed scalar per seed: clean+s*(completed_continuation-clean)',
            calibration='mean selected24 L1 on original26 TRAIN idx_attach only; s=U_L1/C_L1',
            scale_range='finite 0<s<=1; no clipping, search, or ASR-based choice',
            calibration_tolerance=dict(atol=1e-5, rtol=1e-5),
            support='fixed same24; non-target rows/other760 coordinates/topology/weights unchanged',
            budget_match='TRAIN attachment average L1 only; NOT per-row, outer, audit, L2 or Linf matching',
            oracle_note='uses completed U TRAIN amplitude as a reference, not a standalone D-free training claim',
            source_training='reused source C/U; no generator/surrogate/D/proxy updates',
            added_training=dict(victim_epochs_per_seed=200, total_victim_epochs=600),
            victim='fresh GraphSAGE matched source seed/init/dropout/data/checkpoint rule',
            checkpoint='normal internal-dev best AUC, earliest tie; never attack-score selection',
            data_roles='original TRAIN train512/dev128/reused audit256, fixed224 targets/60Moving',
            audit_barrier='all3 calibrations and200-epoch victim fits complete before new audit graph reads',
            acceptance=dict(overall_incremental_asr_min=.8, moving_incremental_asr_min=.8,
                adjacent_incremental_fp_max_exclusive=.05, normal_auc_drop_max=.005,
                normal_recall_drop_max=.05),
            quality_references='historical SAGE24 plus same-seed continuation',
            source_continuation_generators_byte_identical=True,
            design='posthoc development comparator, not independent data or full-pipeline replication',
            performance_failure='retain/report all seeds; no threshold/scale adaptation or automatic followup',
            error_stop='hash, identity, nonfinite, range, initialization, counter or runtime violation',
            original_val_arrays_loaded=False, original_test_arrays_loaded=False,
            physical_validity_claim=False, independent_confirmation=False, automatic_promotion=False))


def output_path(path):
    path = Path(path).resolve()
    base = ROOT / 'record/reproduction' / VERSION
    if path == base or not path.is_relative_to(base):
        raise ValueError('Require a new child of the amplitude-control namespace')
    return path


def prepare(output):
    output = output_path(output)
    if output.exists():
        raise FileExistsError('Never overwrite an existing experiment')
    plan = dict(created_at_utc=baseline.now(), **fields())
    output.mkdir(parents=True, exist_ok=False)
    assets.write_json(output / 'plan.json', plan)
    with tarfile.open(output / 'source_snapshot.tar', 'x') as archive:
        for name in plan['source_catalog']:
            archive.add(ROOT / name, arcname=name, recursive=False)
    return output / 'plan.json'


def load_plan(path):
    path = Path(path).resolve()
    output_path(path.parent)
    if path.name != 'plan.json':
        raise ValueError('Require plan.json')
    plan = json.loads(path.read_text())
    if {key: value for key, value in plan.items() if key != 'created_at_utc'} != fields():
        raise ValueError('Registered source, protocol or code changed')
    return path, plan


def restore(plan):
    source = plan['source_template']
    role = checked_json(source['parent']['references']['role_plan'])
    api, args, legacy, models, coordinates, normalizer = baseline.prior.restore(role, evaluation_models=False)
    if models:
        raise ValueError('Pre-audit restore unexpectedly loaded evaluation models')
    anchor = baseline.accepted.new_model(baseline.prior.new_generator(legacy, coordinates, 'untyped'), 'uniform')
    support = torch.tensor(source['hard_support'], dtype=torch.bool)
    projected = source_fit.restore_projected_reference(anchor, support, source['references'])
    generators, records = {}, {}
    continuation_files = set()
    for seed in SEEDS:
        generators[seed], records[seed] = {}, {}
        for arm in SOURCE_ARMS:
            report = checked_json(plan['sources'][str(seed)]['reports'][arm])
            record = checked_json(plan['sources'][str(seed)]['training'][arm])
            generator = deepcopy(projected)
            generator.load_state_dict(torch.load(assets.checked_asset(record['generator']),
                                                 map_location='cpu', weights_only=True), strict=True)
            generator.zero_grad(set_to_none=True)
            generator.eval().requires_grad_(False)
            generator.assert_contract()
            if state_sha256(generator) != report['unchanged_model_hashes']['generator']:
                raise ValueError('Source generator does not replay the completed audited checkpoint')
            generators[seed][arm], records[seed][arm] = generator, record
            if arm == 'continuation':
                continuation_files.add(record['generator']['sha256'])
    if len(continuation_files) != 1:
        raise ValueError('Registered identical-continuation source fact changed')
    return api, args, coordinates, normalizer, generators, records


def calibration_record(generators, train, context, idx, records):
    """One no-update TRAIN-only measurement; source budget reproduction required."""
    targets = idx['idx_attach']
    if targets.numel() != 26:
        raise ValueError('Require the original26 training poison rows')
    generated = {}
    for arm in SOURCE_ARMS:
        generator = generators[arm]
        before = state_sha256(generator)
        with torch.no_grad():
            injected = generator.inject(train['x'], context, targets, detach=True)
        source_fit.assert_output_scope(train['x'], injected.features, targets, generator)
        if (not torch.equal(injected.edge_index, train['edge_index'])
                or not bool((injected.edge_weight == 1).all()) or before != state_sha256(generator)):
            raise ValueError('Calibration changed source model or topology')
        budget = modification_statistics(train['x'], injected.features, targets, generator.hard_support)
        prior_budget = checked_json(records[arm]['generator_record'])['training_budget']
        if budget != prior_budget:
            raise ValueError('TRAIN26 output does not exactly reproduce its source modification record')
        selected = generator.selected_coordinates[generator.hard_support]
        generated[arm] = injected.features[targets[:, None], selected].clone()
    clean = train['x'][targets[:, None], selected]
    scale, measurement = calibrate_scale(clean, generated['continuation'], generated['unconditional'])
    control = FrozenAmplitudeGenerator(generators['continuation'], scale)
    with torch.no_grad():
        poisoned = control.inject(train['x'], context, targets, detach=True)
    source_fit.assert_output_scope(train['x'], poisoned.features, targets, control)
    actual = (poisoned.features[targets[:, None], selected].double() - clean.double()).abs().sum(1).mean().item()
    expected = (generated['unconditional'].double() - clean.double()).abs().sum(1).mean().item()
    if not math.isclose(actual, expected, rel_tol=1e-5, abs_tol=1e-5):
        raise ValueError('Injected control failed actual TRAIN attachment mean-L1 matching')
    record = dict(scale=scale, measurement=measurement, actual_attachment_mean_l1=actual,
        target_attachment_mean_l1=expected, attachment_indices_sha256=_tensor_hash(targets),
        clean_selected_sha256=_tensor_hash(clean),
        source_output_sha256={key: _tensor_hash(value) for key, value in generated.items()},
        selected_coordinates=selected.tolist(), target_count=26,
        population='original TRAIN idx_attach only; no dev/audit arrays used',
        scope='mean L1 only; U supplies calibration target, not standalone D-free optimization')
    return control, poisoned, record


def validate_train_dev_ledger(ledger, parent):
    expected = [(row['scenario_id'], role, 'train', row['graph_sha256'])
                for role in ('train', 'dev') for row in parent['roles'][role]]
    observed = [(row.get('scenario_id'), row.get('role'), row.get('split'), row.get('sha256'))
                for row in ledger]
    if (len(expected) != 640 or observed != expected
            or any(row.get('status') != 'READ_COMPLETE' for row in ledger)):
        raise ValueError('Incomplete or misaligned640-scene original TRAIN train/dev ledger')


def check_barrier(output, plan, fitted):
    """No evaluator may open audit graphs until every registered victim is complete."""
    barrier = checked_json(fitted['barrier_ref'])
    if (barrier['plan_sha256'] != source_fit.canonical_hash(plan) or barrier['seeds'] != list(SEEDS)
            or barrier['victim_epochs_total'] != 600 or barrier['generator_updates'] != 0
            or barrier['audit_arrays_loaded'] is not False):
        raise ValueError('Incomplete or mismatched three-seed fitting barrier')
    validate_train_dev_ledger(checked_json(barrier['train_dev_ledger']), plan['source_template']['parent'])
    for seed in SEEDS:
        record = checked_json(barrier['training'][str(seed)])
        if (record['trace']['training_forwards'] != 200 or record['trace']['eval_forwards'] != 200
                or record['victim_seed'] != seed):
            raise ValueError('Wrong completed victim epoch/seed counters')
        generator, victim = fitted['trained'][seed]
        assets.checked_asset(record['victim'])
        assets.checked_asset(record['generator'])
        assets.checked_asset(record['calibration'])
        if barrier['final_model_hashes'][str(seed)] != dict(generator=state_sha256(generator),
                                                          victim=state_sha256(victim)):
            raise ValueError('Completed model mutated before audit')
    return barrier


def fit_controls(output, plan, progress):
    folder = output / 'training'
    folder.mkdir(exist_ok=False)
    source, parent = plan['source_template'], plan['source_template']['parent']
    ledger, trained, records_out, hashes = [], {}, {}, {}
    try:
        progress(stage='restoring_bound_source_generators')
        api, args, coordinates, normalizer, sources, records = restore(plan)
        progress(stage='loading_train_only_for_calibration')
        parts, _, train, idx, context = previous.load_train(source, normalizer, ledger)
        outer = source_fit.check_outer(train, idx, checked_json(parent['references']['input_contract']),
                                       coordinates, parent['seed'])
        before = previous.input_digest(parts, train, context, outer)
        selected = sources[SEEDS[0]]['continuation'].selected_coordinates[
            sources[SEEDS[0]]['continuation'].hard_support].tolist()
        reference = collect_reference(parts, parent['roles']['train'], selected, parent['seed'])
        frozen_reference = statistics.fit_reference(reference['train_selected'], reference['train_conditions'],
                                                   reference['train_moving'])
        if frozen_reference.to_metadata() != checked_json(plan['source_reference']):
            raise ValueError('Training diagnostic reference differs from the existing comparison')
        controls, poisons, calibrations = {}, {}, {}
        for seed in SEEDS:
            directory = folder / f'seed{seed}'
            directory.mkdir(exist_ok=False)
            progress(stage='calibrating_train_attachment_amplitude', seed=seed)
            control, poison, record = calibration_record(sources[seed], train, context, idx, records[seed])
            with torch.no_grad():
                outer_stats = {}
                for arm, model in {**sources[seed], 'amplitude_scaled': control}.items():
                    changed = model.inject(train['x'], context, outer, detach=True)
                    source_fit.assert_output_scope(train['x'], changed.features, outer, model)
                    outer_stats[arm] = modification_statistics(train['x'], changed.features, outer, model.hard_support)
            record.update(seed=seed, diagnostic_outer538=outer_stats, outer_budget_matched=False)
            assets.write_json(directory / 'calibration.json', record)
            controls[seed], poisons[seed], calibrations[str(seed)] = control, poison, assets.asset(directory / 'calibration.json')
        if len(ledger) != 512 or any(row.get('role') != 'train' for row in ledger):
            raise ValueError('Calibration accessed outside its registered TRAIN training role')
        assets.write_json(folder / 'calibration_complete.json', dict(status='ALL3_TRAIN_CALIBRATIONS_COMPLETE',
            calibrations=calibrations, train_input_sha256=before, internal_dev_arrays_loaded=False,
            internal_audit_arrays_loaded=False, generator_updates=0))
        progress(stage='loading_registered_internal_dev')
        dev_parts = []
        for row in parent['roles']['dev']:
            part = read_role_part(row, parent, allowed_role='dev', ledger=ledger)
            part['x'] = transform_features(part['x'], normalizer)
            dev_parts.append(part)
        dev = baseline.checkpoint.combine(dev_parts)
        dev_hashes = {key: _tensor_hash(value) for key, value in dev.items() if isinstance(value, torch.Tensor)}
        for seed in SEEDS:
            directory, control, poison = folder / f'seed{seed}', controls[seed], poisons[seed]
            expected = victim_initialization_contract(api, args, train, dev, seed)
            for arm in SOURCE_ARMS:
                if any(expected[key] != records[seed][arm][key]
                       for key in ('initialization_digest', 'fit_rng_digest')):
                    raise ValueError('Control fresh victim does not match the old within-seed initialization/RNG')
            labels = train['y'].clone()
            labels[idx['idx_attach']] = 1
            result = dict(poisoned_features=poison.features, poisoned_labels=labels)
            baseline.validate_poisoned_inputs(train, idx, coordinates.numpy(), poison.features,
                                             poison.edge_index, poison.edge_weight, labels)
            progress(stage='fitting_amplitude_control_victim', seed=seed, epochs=200)
            print(f'[amplitude-control] seed{seed}: fitting fresh victim 200 epochs', flush=True)
            def callback(**record):
                progress(seed=seed, **record)
            victim, record = fit_victim(api, args, train, dev, idx, result, parent, directory,
                                       callback, victim_seed=seed, expected=expected)
            if record['trace']['training_forwards'] != 200 or record['trace']['eval_forwards'] != 200:
                raise ValueError('Fresh victim failed its fixed200-epoch budget')
            torch.save(control.state_dict(), directory / 'generator.pt')
            record.update(arm='amplitude_scaled', generator=assets.asset(directory / 'generator.pt'),
                calibration=calibrations[str(seed)], generator_updates=0,
                source_training=plan['sources'][str(seed)]['training'],
                training_budget=modification_statistics(train['x'], poison.features, idx['idx_attach'], control.hard_support))
            assets.write_json(directory / 'training.json', record)
            records_out[str(seed)] = assets.asset(directory / 'training.json')
            trained[seed] = (control, victim)
            hashes[str(seed)] = dict(generator=state_sha256(control), victim=state_sha256(victim))
            if (before != previous.input_digest(parts, train, context, outer)
                    or dev_hashes != {key: _tensor_hash(value) for key, value in dev.items() if isinstance(value, torch.Tensor)}):
                raise ValueError('Victim fitting mutated original inputs/context')
        validate_train_dev_ledger(ledger, parent)
        assets.write_json(folder / 'train_dev_graph_access_ledger.json', ledger)
        ledger_ref = assets.asset(folder / 'train_dev_graph_access_ledger.json')
        barrier = dict(status='ALL3_AMPLITUDE_VICTIMS_COMPLETE', plan_sha256=source_fit.canonical_hash(plan),
            seeds=list(SEEDS), victim_epochs_total=600, generator_updates=0, training=records_out,
            final_model_hashes=hashes, audit_arrays_loaded=False, train_dev_ledger=ledger_ref)
        assets.write_json(folder / 'optimization_complete.json', barrier)
        return dict(api=api, args=args, normalizer=normalizer, trained=trained,
            barrier_ref=assets.asset(folder / 'optimization_complete.json'), distribution_reference=reference)
    finally:
        ledger_path = folder / 'train_dev_graph_access_ledger.json'
        if not ledger_path.exists():
            assets.write_json(ledger_path, ledger)


class AuditReader:
    def __init__(self, parent, normalizer, injector, ledger):
        self.parent, self.normalizer, self.injector, self.ledger = parent, normalizer, injector, ledger
        self.parts, self.hashes = {}, {}

    def __call__(self, row):
        if row not in self.parent['roles']['audit'] or row.get('split') != 'train' or row.get('role') != 'audit':
            raise ValueError('Only exact registered original TRAIN audit scenes are allowed')
        scene = row['scenario_id']
        if scene not in self.parts:
            self.parts[scene] = baseline.field.read_audit_part(row, self.parent, self.normalizer, self.ledger)
            self.hashes[scene] = baseline.field.part_digest(self.parts[scene])
        if baseline.field.part_digest(self.parts[scene]) != self.hashes[scene]:
            raise ValueError('Clean audit input changed')
        self.injector.bind(self.parts[scene])
        return self.parts[scene]


def evaluate_seed(output, plan, fitted, seed, progress):
    barrier = check_barrier(output, plan, fitted)
    source, parent = plan['source_template'], plan['source_template']['parent']
    folder = output / f'seed{seed}'
    folder.mkdir(exist_ok=False)
    stub = SimpleNamespace(x=torch.empty((0, 784)), y=torch.tensor([0, 1]))
    reference = fitted['api']['model_construct'](fitted['args'], 'GraphSage', stub, torch.device('cpu'))
    reference.load_state_dict(torch.load(assets.checked_asset(parent['references']['clean_reference']),
                                        map_location='cpu', weights_only=True), strict=True)
    reference.eval().requires_grad_(False)
    generator, victim = fitted['trained'][seed]
    models = dict(clean_reference=reference, victim=victim)
    before = {key: state_sha256(value) for key, value in dict(generator=generator, **models).items()}
    injector = replication.CapturingInjector(generator, parent['shuffle_seed'])
    ledger = []
    reader = AuditReader(parent, fitted['normalizer'], injector, ledger)
    try:
        with torch.no_grad():
            evaluation = baseline.evaluate(parent, folder / 'audit', models, injector, reader,
                                           lambda **record: progress(seed=seed, **record))
        evaluation = replication.enrich_train_provenance(parent, ledger, evaluation)
        if evaluation['audit_counts'] != source['expected_counts'] or len(injector.budgets) != 224:
            raise ValueError('Fixed224 target population or audit counts changed')
        replication.read_tables(evaluation, parent['roles']['audit'])
        identity = replication.verify_target_identity(folder / 'audit/targets.csv', source['original_csvs']['raw_targets']['path'])
        replay = replication.verify_normal_clean(folder / 'audit/clean_pair_scores.csv', source['original_csvs']['raw_clean_scores']['path'])
        if (before != {key: state_sha256(value) for key, value in dict(generator=generator, **models).items()}
                or reader.hashes != {key: baseline.field.part_digest(value) for key, value in reader.parts.items()}
                or len(ledger) != 256):
            raise ValueError('Audit mutated inputs/models or read the wrong scene set')
        assets.write_json(folder / 'budgets.json', injector.budgets)
        assets.write_json(folder / 'audit/summary.json', dict(evaluation=evaluation,
            unchanged_model_hashes=before, targets_identity_verified=identity, clean_reference_replay=replay,
            training=barrier['training'][str(seed)], budgets=assets.asset(folder / 'budgets.json')))
        reports = {arm: checked_json(plan['sources'][str(seed)]['reports'][arm])['evaluation'] for arm in SOURCE_ARMS}
        for report in reports.values():
            replication.read_tables(report, parent['roles']['audit'])
        reports['amplitude_scaled'] = evaluation
        review = reporting.review_seed(reports, checked_json(source['original_report'])['evaluation'])
        clean, conditions = np.stack(injector.clean), np.stack(injector.conditions)
        moving = np.asarray(injector.moving, dtype=bool)
        changed = dict(amplitude_scaled=np.stack(injector.changed))
        with np.load(assets.checked_asset(plan['sources'][str(seed)]['distribution_arrays']), allow_pickle=False) as cached:
            for key, value in (('audit_clean', clean), ('audit_conditions', conditions), ('audit_moving', moving)):
                if not np.array_equal(cached[key], value):
                    raise ValueError('Cached source distribution targets do not align with new audit rows')
            for arm in SOURCE_ARMS:
                changed[arm] = cached['triggered_' + arm].copy()
        train_ref = fitted['distribution_reference']
        distribution_ref = statistics.fit_reference(train_ref['train_selected'], train_ref['train_conditions'], train_ref['train_moving'])
        if distribution_ref.to_metadata() != checked_json(plan['source_reference']):
            raise ValueError('Frozen distribution scales/bandwidth/quantiles changed')
        measured = reporting.evaluate_distribution(distribution_ref, clean, conditions, moving, changed)
        old_metrics = checked_json(plan['sources'][str(seed)]['distribution_metrics'])
        for stratum in ('all', 'slow', 'moving'):
            for arm in SOURCE_ARMS:
                if measured['strata'][stratum]['arms'][arm] != old_metrics['strata'][stratum]['arms'][arm]:
                    raise ValueError('Cached source arrays do not reproduce their completed distribution metrics')
        assets.write_json(folder / 'review.json', review)
        assets.write_json(folder / 'distribution_metrics.json', measured)
        with (folder / 'distribution_features.npz').open('xb') as stream:
            np.savez_compressed(stream, audit_clean=clean, audit_conditions=conditions, audit_moving=moving,
                                **{'triggered_' + arm: value for arm, value in changed.items()})
        result = dict(seed=seed, review=review, distribution=measured)
        assets.write_json(folder / 'summary.json', dict(status='AMPLITUDE_CONTROL_SEED_COMPLETE', seed=seed,
            review=assets.asset(folder / 'review.json'), distribution=assets.asset(folder / 'distribution_metrics.json'),
            report=assets.asset(folder / 'audit/summary.json'), original_val_arrays_loaded=False,
            original_test_arrays_loaded=False, independent_confirmation=False))
        return result
    finally:
        assets.write_json(folder / 'audit_graph_access_ledger.json', ledger)


def run(path):
    path, plan = load_plan(path)
    output = path.parent
    assets.write_json(output / 'started.json', dict(pid=os.getpid(), at=baseline.now(), plan=assets.asset(path)))
    progress = replication.source.state_writer(output)
    completed = []
    try:
        torch.set_num_threads(2)
        fitted = fit_controls(output, plan, progress)
        load_plan(path)
        check_barrier(output, plan, fitted)
        for seed in SEEDS:
            progress(stage='evaluating_completed_control', seed=seed)
            completed.append(evaluate_seed(output, plan, fitted, seed, progress))
            gc.collect()
        aggregate = reporting.aggregate(completed)
        load_plan(path)
        assets.write_json(output / 'aggregate.json', aggregate)
        result = dict(status='AMPLITUDE_CONTROL_COMPLETE_REVIEW_REQUIRED', at=baseline.now(),
            plan=assets.asset(path), aggregate=assets.asset(output / 'aggregate.json'),
            optimization_complete=fitted['barrier_ref'],
            train_dev_ledger=assets.asset(output / 'training/train_dev_graph_access_ledger.json'),
            seed_reports={str(seed): assets.asset(output / f'seed{seed}/summary.json') for seed in SEEDS},
            original_val_arrays_loaded=False, original_test_arrays_loaded=False,
            independent_confirmation=False, full_pipeline_replication=False,
            automatic_followup=False, automatic_promotion=False)
        assets.write_json(output / 'summary.json', result)
        progress(status=result['status'], stage='complete')
        return result
    except Exception as error:
        assets.write_json(output / 'failure.json', dict(error=str(error), at=baseline.now(),
            completed_seeds=[item['seed'] for item in completed], automatic_retry=False))
        progress(status='STOPPED_AMPLITUDE_CONTROL_ERROR', error=str(error))
        raise


def launch(path):
    path, _ = load_plan(path)
    if any((path.parent / name).exists() for name in ('started.json', 'launcher.json', 'launch_claim.json',
                                                     'failure.json', 'summary.json', 'console.log', 'training')):
        raise ValueError('An existing run cannot be restarted')
    assets.write_json(path.parent / 'launch_claim.json', dict(at=baseline.now(), plan=assets.asset(path)))
    command = [sys.executable, '-B', '-u', '-m', 'experiments.spear_amplitude_control_v1.workflow', 'run', '--plan', str(path)]
    environment = dict(os.environ, CUDA_VISIBLE_DEVICES='', PYTHONDONTWRITEBYTECODE='1',
                       OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
    with (path.parent / 'console.log').open('xb') as stream:
        process = subprocess.Popen(command, cwd=ROOT, env=environment, stdout=stream,
                                   stderr=subprocess.STDOUT, start_new_session=True)
    result = dict(pid=process.pid, command=command, at=baseline.now(), plan=assets.asset(path), automatic_retry=False)
    assets.write_json(path.parent / 'launcher.json', result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    p = commands.add_parser('prepare'); p.add_argument('--output-dir', required=True)
    for name in ('check', 'run', 'launch'):
        p = commands.add_parser(name); p.add_argument('--plan', required=True)
    args = parser.parse_args()
    if args.command == 'prepare':
        print(prepare(args.output_dir))
    elif args.command == 'check':
        load_plan(args.plan); print('AMPLITUDE_METADATA_PASS; no graph/model loads or training')
    elif args.command == 'launch':
        print(json.dumps(launch(args.plan), indent=2))
    else:
        print(json.dumps(run(args.plan), indent=2))


if __name__ == '__main__':
    main()
