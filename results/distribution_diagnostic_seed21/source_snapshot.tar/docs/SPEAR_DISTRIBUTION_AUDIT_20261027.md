# 已完成三臂的固定检查点分布诊断

## 范围

本地AV2、自有GNN的离线模型鲁棒性研究。只复用已完成的
`spear_distribution_training_v1/pilot_20261027_seed20260621_v1` 检查点。
不优化参数，不改源代码/检查点/旧结果，不训练判别器，不打开原validation/test或内部dev。
输出写入新的 `record/reproduction/spear_distribution_audit_v1/`，不覆盖既有目录。

本轮用来回答：在ASR已可接受时，分布约束是否在不依赖训练判别器的统计量上体现改善。
现有ASR已经看过，因此这是**事后开发诊断**，不是预注册的独立验证。
本文件和新代码在新分布数值计算前冻结，禁止按结果换带宽、目标、分组或异常阈值。

## 公平参考与采样

- 参考：原train512场景，对每场景的 `eligible & label==0` pair，使用原评估的
  `SHA256(seed:spear-audit-target:scene:srcID:dstID)` 取最小者，每合格场景仅一条。
- 不使用所有pair等权汇总，避免密集场景权重过大；也不使用含其他标签/上下文的538个outer作唯一正常参考。
- 被比较的目标：原audit256中的既有224条（Slow164、Moving60），逐条核验三臂原始CSV和更早目标身份。
- 参考及目标都按原干净motion标记分all/slow/moving，触发后不重新分组，不按成功与否筛样本。
- 只读取原TRAIN。继承冻结normalizer，不重新标准化，不用未来量作特征或条件。
  标签只用于沿用既有目标资格规则，不作为分布指标输入。

## 固定指标

仅比较相同24个可修改坐标，避免760个未修改坐标稀释差异。
条件为原干净6坐标 `[149,199,507,557,718,721]`，与可修改坐标不相交。

1. **平均边际Wasserstein-1**：对24维各计算一维经验W1，再等权平均。
   单位为既有JCAS标准化特征坐标，不是米。依据[Scipy官方定义](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.wasserstein_distance.html)。
2. **选中24维RBF MMD²**：输入 `x24/(10*sqrt(24))`。
3. **联合24+6维RBF MMD²**：拼接上述24维和 `clean_condition6/(10*sqrt(6))`，两块均衡。
   它衡量联合分布差异，不等同于证明条件分布匹配。
4. **参考分位外比例**：各运动组clean train参考的1%/99%线性经验分位，严格小于/大于边界才记异常。
   同时报异常坐标率、至少一列异常的目标率，后者没有“应该约2%”的保证。
5. **clamp边界比例**：`abs(abs(value)-10)<=1e-6`，rtol=0；记录干净基线。
6. **修改量**：生成值减同一目标原干净值的L1/L2/Linf均值和最大值，仍是标准化特征空间量。

MMD依据[Gretton等，JMLR 2012](https://www.jmlr.org/papers/v13/gretton12a.html)的核均值差异框架。
本轮使用含对角的有偏V统计量描述值，不做显著性检验、不报告p值。
RBF为 `exp(-distance_squared/(2*sigma_squared))`。selected和joint分别仅用全clean train参考的
非零两两距离中位数拟合一个sigma，所有臂和运动组共享；退化参考固定sigma=1并明确标记。
不同组的参考行与分位阈值来自相应train子组；不存在参考/目标的组明确不可用，不借用别组。

所有指标同时记录 **clean audit→clean train** 的自然差异，以及三臂触发输出→clean train差异。
另给触发输出→clean audit距离，避免把原有场景分布差异当作模块收益。

## 完整性与结论口径

恢复顺序为原SAGE→上一轮projection→各完成臂检查点；生成器全程eval/frozen/no-grad。
仅每目标每臂一次生成，共672次，不加载victim或训练D，不重新计算ASR。
逐目标与原budgets.json精确核对修改范围及L1/Linf；输入、拓扑、条件和支持均保持不变。
训练参考512场景和audit256场景留下SHA/角色读取账本。
保存采集数组、参考统计、目标身份、逐组完整指标和差值，便于不用模型独立复算。

同预算continuation是分布约束的主要对照；unconditional是条件模块的主要对照。
各指标方向分开报告，不事后加权合成一个便于宣称胜利的总分。
某个点估计改善只能支持该指标上的描述性变化，不保证多种子重复、独立数据泛化或车辆物理一致性。
即使更接近干净分布，也不能据此声称所有特征副本/代数关系已经正确。

用户已同意把后续整体和Moving ASR底线改为80%；邻接增量FP<5%、正常AUC下降≤0.005、
正类召回下降≤0.05的要求保留。新结果另附用户修订标准下的可用性视图，
旧85% gate完全保留、不追溯修改。诊断结束后不自动重新训练或晋升主方法。
