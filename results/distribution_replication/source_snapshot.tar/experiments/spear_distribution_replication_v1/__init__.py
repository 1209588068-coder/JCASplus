"""Fixed-start, matched three-arm training-seed replication on original TRAIN."""
