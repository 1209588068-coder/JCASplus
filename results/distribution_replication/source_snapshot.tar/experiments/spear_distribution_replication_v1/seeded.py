"""Explicit seed adapters; all objective and update code remains unchanged.

Only this isolated replication namespace permits the two registered new seeds.
The historical seed is accepted by the adapter solely for exact parity tests.
"""
from __future__ import annotations

from contextlib import redirect_stdout
import hashlib
import json
from numbers import Integral
from types import SimpleNamespace

import numpy as np
import torch
from torch import nn

from experiments.spear_distribution_training_v1.distribution import (
    DistributionRegularizer, DISCRIMINATOR_SEED,
)
from experiments.spear_distribution_training_v1.fitting import baseline, assets


REPLICATE_SEEDS = (20260622, 20260623)


def replication_seeds(seed):
    if isinstance(seed, bool) or not isinstance(seed, Integral) or seed not in REPLICATE_SEEDS:
        raise ValueError('Require one of the two preregistered replication seeds')
    return dict(continuation=int(seed) + 3000, discriminator=int(seed) + 1000, victim=int(seed))


class SeededDistributionRegularizer(DistributionRegularizer):
    """Reinitialize only D weights, retaining optimizer identity and all losses."""

    def __init__(self, arm, original_features, target_indices, selected_coordinates,
                 *, seed=DISCRIMINATOR_SEED, **kwargs):
        allowed = (DISCRIMINATOR_SEED, *(value + 1000 for value in REPLICATE_SEEDS))
        if isinstance(seed, bool) or not isinstance(seed, Integral) or seed not in allowed:
            raise ValueError('Unregistered discriminator replication seed')
        super().__init__(arm, original_features, target_indices, selected_coordinates,
                         seed=DISCRIMINATOR_SEED, **kwargs)
        # A CPU float32 construction followed by conversion exactly mirrors the
        # historical constructor, including when the bound inputs are float64.
        with torch.random.fork_rng(devices=[]):
            torch.random.default_generator.manual_seed(int(seed))
            fresh = nn.Sequential(nn.Linear(30, 64), nn.LeakyReLU(.2),
                                  nn.Linear(64, 64), nn.LeakyReLU(.2), nn.Linear(64, 1))
            fresh = fresh.to(device=self._device, dtype=self._dtype)
        self.discriminator.load_state_dict(fresh.state_dict(), strict=True)
        self._config['seed'] = int(seed)
        self._config_json = json.dumps(self._config, sort_keys=True)
        self._initial_discriminator_sha256 = self.discriminator_hash()
        if self.optimizer is not None and self.optimizer.state:
            raise ValueError('Seed adapter requires an empty fresh optimizer')
        self.assert_contract()


def _validate_victim_seed(seed):
    if (isinstance(seed, bool) or not isinstance(seed, Integral)
            or seed not in (20260621, *REPLICATE_SEEDS)):
        raise ValueError('Unregistered fresh-victim seed')


def _new_victim(api, args, train, dev, seed):
    _validate_victim_seed(seed)
    full_x = torch.cat([train['x'], dev['x']])
    full_y = torch.cat([train['y'], dev['y']])
    np.random.seed(int(seed))
    torch.manual_seed(int(seed))
    victim = api['model_construct'](args, 'GraphSage', SimpleNamespace(x=full_x, y=full_y), torch.device('cpu'))
    signature = dict(victim_seed=int(seed), initial_torch_seed=torch.initial_seed(),
        initialization_digest=baseline.checkpoint.tensor_digest(victim),
        fit_rng_digest=hashlib.sha256(torch.get_rng_state().numpy().tobytes()).hexdigest())
    if signature['initial_torch_seed'] != seed:
        raise ValueError('Victim construction changed the explicit initialization seed')
    return victim, signature


def victim_initialization_contract(api, args, train, dev, victim_seed):
    """Independent no-training probe; preserve caller NumPy and Torch RNG."""
    numpy_state = np.random.get_state()
    try:
        with torch.random.fork_rng(devices=[]):
            _, signature = _new_victim(api, args, train, dev, victim_seed)
        return signature
    finally:
        np.random.set_state(numpy_state)


def fit_victim(api, args, train, dev, idx, result, plan, arm_dir, state,
               *, victim_seed, expected):
    """Original fresh GraphSAGE fit/AUC policy with explicit paired seed."""
    _validate_victim_seed(victim_seed)
    if plan['victim_epochs'] != 200 or expected['victim_seed'] != victim_seed:
        raise ValueError('Victim budget or preregistered seed changed')
    dev_idx = torch.nonzero(dev['eligible'], as_tuple=False).flatten() + len(train['x'])
    if not torch.equal(dev_idx, idx['dev_indices']):
        raise ValueError('Original development supervision changed')
    edges = torch.cat([train['edge_index'], dev['edge_index'] + len(train['x'])], 1)
    weights = torch.ones(edges.shape[1])
    fit_idx = torch.cat([idx['idx_train'], idx['idx_attach']])
    if len(fit_idx) != 1902:
        raise ValueError('Original victim training membership changed')
    victim, signature = _new_victim(api, args, train, dev, victim_seed)
    if signature != expected:
        raise ValueError('Fresh victim initialization/RNG differs from its independent seed probe')
    labels = torch.cat([result['poisoned_labels'], dev['y']])
    trace = baseline.checkpoint.AUCTrace(labels, dev_idx, plan['victim_epochs'],
                                         arm_dir / 'victim_dev_trace.csv', state)
    with trace.observe(victim), redirect_stdout(baseline.Progress(state, arm_dir.name + '_victim')):
        if hashlib.sha256(torch.get_rng_state().numpy().tobytes()).hexdigest() != expected['fit_rng_digest']:
            raise ValueError('Victim dropout RNG changed between construction and fit')
        victim.fit(torch.cat([result['poisoned_features'], dev['x']]), edges, weights,
            labels, fit_idx, dev_idx, train_iters=plan['victim_epochs'], verbose=True)
    trace_result = trace.finish(victim)
    victim.load_state_dict(trace.auc_state)
    victim.eval().requires_grad_(False)
    victim.zero_grad(set_to_none=True)
    if baseline.checkpoint.tensor_digest(victim) != trace.best_auc_digest:
        raise ValueError('Victim AUC checkpoint mismatch')
    quality = baseline.prior.parent.dual.dev_quality(victim, dev, arm_dir / 'victim_dev_scores.csv')
    torch.save(victim.state_dict(), arm_dir / 'victim_auc.pt')
    return victim, dict(victim=assets.asset(arm_dir / 'victim_auc.pt'), trace=trace_result,
        quality=quality, **signature, expected_initialization=dict(expected))
