"""Synthetic continuation/preflight/barrier checks; no real fitting or AV2 reads."""
from copy import deepcopy
from dataclasses import asdict
from contextlib import ExitStack
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import torch

from experiments.spear_distribution_training_v1 import fitting
from experiments.spear_distribution_training_v1.distribution import DistributionRegularizer
from experiments.spear_domain_training_v1.module import DomainConstrainedGenerator
from experiments.spear_semantic_support_v1.module import SupportMaskedGenerator
from experiments.spear_pair_role_generator_v1.training import ResidualTrainingConfig
from tests.test_spear_domain_training_module import setup, classifier


class DistributionTrainingFittingTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)

    def smoke_inputs(self, arm='conditional'):
        anchor, mask, x, context, _ = setup()
        reference = DomainConstrainedGenerator(anchor, mask, output_mode='domain_projection')
        with torch.no_grad():
            reference.residual.head.bias.add_(.125)
            reference.residual.head.bias[torch.nonzero(mask).flatten()[:2]] = 30.
        reference.eval().requires_grad_(False)
        generator = fitting.new_generator(reference)
        surrogate = classifier().eval().requires_grad_(False)
        proxies = [classifier().eval().requires_grad_(False) for _ in range(2)]
        train = dict(x=x, y=torch.tensor([0, 1, 0, 0, 1, 0]))
        idx = dict(idx_train=torch.tensor([0, 1]), idx_attach=torch.tensor([2]))
        outer = torch.tensor([2, 3, 4])
        distribution = DistributionRegularizer(arm, x, outer, generator.selected_coordinates[mask])
        return generator, reference, surrogate, proxies, train, context, idx, outer, ResidualTrainingConfig(), distribution

    def test_three_arm_replay_and_gradient_smoke_do_not_update_weights_or_rng(self):
        initial_d, replay = None, None
        for arm in fitting.ARMS:
            values = self.smoke_inputs(arm)
            generator, reference, *_, distribution = values
            before = fitting.state_sha256(generator)
            rng = torch.random.get_rng_state().clone()
            with self.subTest(arm=arm), patch.object(torch.optim.Adam, 'step') as step:
                result = fitting.gradient_smoke(*values)
                step.assert_not_called()
                self.assertEqual(result['status'], 'NO_UPDATE_GRADIENT_SMOKE_PASS')
                self.assertEqual(result['optimizer_steps'], 0)
                self.assertEqual(result['discriminator_steps'], 0)
                self.assertTrue(result['initial_projected_outer_identity_exact'])
                self.assertTrue(result['saturated_raw_gradient_zero'])
                self.assertEqual(before, fitting.state_sha256(generator))
                self.assertEqual(before, fitting.state_sha256(reference))
                self.assertTrue(torch.equal(rng, torch.random.get_rng_state()))
                self.assertTrue(all(p.grad is None for p in generator.parameters()))
                self.assertEqual(distribution.steps, 0)
                if initial_d is None:
                    initial_d = result['initial_discriminator_sha256']
                    replay = result['projected_outer_output_sha256']
                else:
                    self.assertEqual(initial_d, result['initial_discriminator_sha256'])
                    self.assertEqual(replay, result['projected_outer_output_sha256'])
                if arm == 'continuation':
                    self.assertEqual(result['distribution_residual_gradient_l2'], 0.)
                    self.assertEqual(result['distribution']['generator_weighted_loss'], 0.)
                else:
                    self.assertGreater(result['distribution_residual_gradient_l2'], 0.)
                    self.assertGreater(result['distribution']['d_gradient_parameters'], 0)

    def test_projected_reference_restore_uses_new_residual_and_original_frozen_bases(self):
        anchor, mask, x, context, targets = setup()
        sage = SupportMaskedGenerator(anchor, hard_support=mask).eval().requires_grad_(False)
        projected = DomainConstrainedGenerator(sage.anchor, mask, output_mode='domain_projection')
        with torch.no_grad():
            projected.residual.head.bias.add_(.75)
        projected.eval().requires_grad_(False)
        fresh_anchor, *_ = setup()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            paths = dict(sage_generator=root / 'sage.pt', generator=root / 'projected.pt')
            torch.save(sage.state_dict(), paths['sage_generator'])
            torch.save(projected.state_dict(), paths['generator'])
            refs = {key: dict(path=str(path), sha256='synthetic') for key, path in paths.items()}
            with patch.object(fitting.assets, 'checked_asset', side_effect=lambda ref: Path(ref['path'])):
                restored = fitting.restore_projected_reference(fresh_anchor, mask, refs)
            self.assertEqual(fitting.state_sha256(restored), fitting.state_sha256(projected))
            self.assertTrue(torch.equal(restored(x, context, targets), projected(x, context, targets)))
            self.assertFalse(torch.equal(restored.residual.head.bias, sage.anchor.residual.head.bias))
            rng = torch.random.get_rng_state().clone()
            continued = fitting.new_generator(restored)
            self.assertTrue(torch.equal(rng, torch.random.get_rng_state()))
            self.assertEqual(fitting.state_sha256(continued), fitting.state_sha256(projected))
            self.assertTrue(all(p.requires_grad for p in continued.residual.parameters()))
            self.assertTrue(all(not p.requires_grad for p in continued.base_generator.parameters()))
            self.assertIsNot(continued.residual, restored.residual)

    def test_old_sage_checkpoint_cannot_replace_completed_projection(self):
        anchor, mask, *_ = setup()
        sage = SupportMaskedGenerator(anchor, hard_support=mask)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'sage.pt'
            torch.save(sage.state_dict(), path)
            refs = {key: dict(path=str(path), sha256='synthetic') for key in ('sage_generator', 'generator')}
            with patch.object(fitting.assets, 'checked_asset', side_effect=lambda ref: Path(ref['path'])):
                with self.assertRaises(ValueError):
                    fitting.restore_projected_reference(anchor, mask, refs)

    def test_new_distribution_uses_only_original_clean_outer_rows_and_preserves_rng(self):
        generator, _, _, _, train, _, _, outer, _, _ = self.smoke_inputs()
        plan = dict(distribution_config=deepcopy(fitting.DISTRIBUTION_CONFIG))
        rng = torch.random.get_rng_state().clone()
        distribution = fitting.new_distribution('conditional', train, outer, generator, plan)
        self.assertTrue(torch.equal(rng, torch.random.get_rng_state()))
        distribution.validate_binding(train['x'], outer, generator.selected_coordinates[generator.hard_support])
        snapshot = distribution.snapshot()
        self.assertEqual(snapshot['provenance']['split'], 'train')
        self.assertEqual(snapshot['provenance']['real_reference'], 'same_outer_target_rows')
        self.assertFalse(snapshot['provenance']['internal_dev_arrays_used'])
        self.assertEqual(snapshot['steps'], 0)
        self.assertEqual(snapshot['generator_calls'], 0)
        bad = deepcopy(plan)
        bad['distribution_config']['condition_coordinates'][0] = int(generator.selected_coordinates[generator.hard_support][0])
        with self.assertRaisesRegex(ValueError, 'overlap'):
            fitting.new_distribution('conditional', train, outer, generator, bad)

    def test_new_namespace_and_bad_config_fail_before_reading_assets(self):
        root = fitting.ROOT / 'record/reproduction/spear_distribution_training_v1'
        self.assertEqual(fitting.output_path(root / 'run/training'), root / 'run/training')
        for path in (root / 'training', root, fitting.ROOT / 'record/reproduction/spear_domain_training_v1/run/training'):
            with self.subTest(path=path), self.assertRaises(ValueError):
                fitting.output_path(path)
        plan = dict(arms=list(fitting.ARMS), training_config=asdict(ResidualTrainingConfig()),
                    distribution_config=deepcopy(fitting.DISTRIBUTION_CONFIG), execution=dict(device='cpu', torch_threads=2))
        with patch.object(fitting.baseline.prior, 'restore') as restore:
            for mutation in ('arms', 'lr', 'weight', 'seed', 'epochs'):
                bad = deepcopy(plan)
                if mutation == 'arms': bad['arms'] = ['continuation']
                elif mutation == 'epochs': bad['training_config']['epochs'] = 201
                else: bad['distribution_config'][mutation] += 1
                with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                    fitting.fit_arms(root / 'never/training', bad)
            restore.assert_not_called()

    @staticmethod
    def training_result(arm):
        return dict(residual_steps=200, surrogate_steps=200, clean_constraint_calls=200,
            selected_epoch=199, selection_policy='final_epoch', config=asdict(ResidualTrainingConfig()),
            distribution_arm=arm, discriminator_steps=0 if arm == 'continuation' else 200,
            distribution_generator_calls=200)

    def test_per_arm_runtime_contract_checks_actual_discriminator_and_generator_counts(self):
        for arm in fitting.ARMS:
            result = self.training_result(arm)
            fitting._check_training_result(result, arm, result['config'])
            for key in ('discriminator_steps', 'distribution_generator_calls', 'surrogate_steps', 'clean_constraint_calls'):
                bad = dict(result)
                bad[key] += 1
                with self.subTest(arm=arm, key=key), self.assertRaises(ValueError):
                    fitting._check_training_result(bad, arm, result['config'])

    def barrier_fixture(self, root):
        folder = root / 'record/reproduction/spear_distribution_training_v1/run/training'
        folder.mkdir(parents=True)
        generator, reference, _, _, train, _, _, outer, _, _ = self.smoke_inputs()
        mask = generator.hard_support
        roles = {role: [dict(scenario_id=f'{role}{i}', role=role, split='train', graph_path=f'graphs/{role}{i}.npz',
                            graph_sha256=f'hash{role}{i}') for i in range(n)] for role, n in (('train', 512), ('dev', 128))}
        parent = dict(roles=roles, graph_dir=str(root / 'graph_assets'),
                      victim_initialization_digest='init', victim_fit_rng_digest='rng')
        plan = dict(parent=parent, hard_support=mask.tolist(), training_config=asdict(ResidualTrainingConfig()),
                    distribution_config=deepcopy(fitting.DISTRIBUTION_CONFIG))

        def write(path, value):
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(value))
            return dict(path=str(path), sha256='synthetic')

        ledger = [dict(scenario_id=row['scenario_id'], role=row['role'], split='train',
                      path=str((Path(parent['graph_dir']) / row['graph_path']).resolve()),
                      sha256=row['graph_sha256'], status='READ_COMPLETE') for rows in roles.values() for row in rows]
        ledger_ref = write(folder / 'train_dev_graph_access_ledger.json', ledger)
        trained, discriminators, refs, hashes, smokes = {}, {}, {}, {}, {}
        g_initial = fitting.state_sha256(reference)
        d_initial = None
        for arm in fitting.ARMS:
            generator = fitting.new_generator(reference).eval().requires_grad_(False)
            victim = classifier().eval().requires_grad_(False)
            discriminator = DistributionRegularizer(arm, train['x'], outer, generator.selected_coordinates[mask]).discriminator
            d_hash = fitting.state_sha256(discriminator)
            d_initial = d_hash
            trained[arm], discriminators[arm] = (generator, victim), discriminator
            smoke = dict(status='NO_UPDATE_GRADIENT_SMOKE_PASS', optimizer_steps=0, discriminator_steps=0,
                initial_projected_outer_identity_exact=True, projected_reference_sha256=g_initial,
                initial_discriminator_sha256=d_hash, projected_outer_output_sha256='replay')
            smokes[arm] = write(folder / arm / 'smoke.json', smoke)
            record = dict(arm=arm, initialization_digest='init', fit_rng_digest='rng',
                          trace=dict(training_forwards=200, eval_forwards=200), smoke=smokes[arm])
            for key in ('generator', 'surrogate', 'victim', 'discriminator'):
                record[key] = write(folder / arm / f'{key}.json', {})
            result = dict(self.training_result(arm), distribution_initial_state_sha256=d_hash,
                          distribution_final_state_sha256=d_hash)
            record['generator_record'] = write(folder / arm / 'generator_record.json', result)
            record['distribution_record'] = write(folder / arm / 'distribution_record.json', dict(
                arm=arm, config=plan['distribution_config'], discriminator_steps=result['discriminator_steps'],
                generator_calls=200, initial_discriminator_sha256=d_hash, final_discriminator_sha256=d_hash,
                initial_checkpoint=write(folder / arm / 'distribution_initial.json', {}),
                final_checkpoint=write(folder / arm / 'distribution_final.json', {})))
            refs[arm] = write(folder / arm / 'training.json', record)
            hashes[arm] = dict(generator=fitting.state_sha256(generator), victim=fitting.state_sha256(victim),
                               discriminator=d_hash)
        preflight = dict(status='ALL_ARMS_NO_UPDATE_SMOKE_PASS', arms=list(fitting.ARMS), optimizer_steps=0,
            initial_generator_sha256=g_initial, initial_discriminator_sha256=d_initial,
            projected_outer_output_sha256='replay', smoke=smokes)
        barrier = dict(arms=list(fitting.ARMS), steps=fitting.EXPECTED_STEPS, training=refs,
            final_model_hashes=hashes, hard_support=plan['hard_support'], shared_initial_state=g_initial,
            shared_initial_discriminator=d_initial, all_arms_preflight=write(folder / 'all_arms_preflight.json', preflight),
            plan_sha256=fitting.canonical_hash(plan), parent_sha256=fitting.canonical_hash(parent),
            train_dev_ledger=ledger_ref, internal_audit_arrays_loaded=False,
            original_val_arrays_loaded=False, original_test_arrays_loaded=False)
        barrier_ref = write(folder / 'optimization_complete.json', barrier)
        bundle = dict(output_dir=str(folder), plan_sha256=fitting.canonical_hash(plan), trained=trained,
            trained_discriminators=discriminators, barrier=barrier, optimization_complete=barrier_ref,
            train_dev_ledger_ref=ledger_ref)
        return folder, plan, bundle

    def test_barrier_requires_three_completed_frozen_generators_victims_and_discriminators(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            folder, plan, bundle = self.barrier_fixture(root)
            with patch.object(fitting, 'ROOT', root), patch.object(fitting.assets, 'checked_asset',
                    side_effect=lambda ref: Path(ref['path'])):
                self.assertEqual(fitting.validate_barrier(folder, plan, bundle), bundle['barrier'])
                bundle['trained_discriminators']['conditional'][0].weight.requires_grad_(True)
                with self.assertRaisesRegex(ValueError, 'frozen/eval'):
                    fitting.validate_barrier(folder, plan, bundle)

    def test_barrier_rejects_missing_arm_tampered_distribution_count_smoke_and_ledger(self):
        for mutation in ('missing', 'd_steps', 'smoke', 'ledger', 'live_d'):
            with self.subTest(mutation=mutation), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                folder, plan, bundle = self.barrier_fixture(root)
                if mutation == 'missing':
                    del bundle['trained']['conditional']
                elif mutation == 'live_d':
                    with torch.no_grad(): bundle['trained_discriminators']['conditional'][0].weight.add_(1.)
                else:
                    path = (folder / 'train_dev_graph_access_ledger.json' if mutation == 'ledger' else
                            folder / 'conditional' / ('smoke.json' if mutation == 'smoke' else 'distribution_record.json'))
                    item = json.loads(path.read_text())
                    if mutation == 'd_steps': item['discriminator_steps'] = 199
                    elif mutation == 'smoke': item['initial_projected_outer_identity_exact'] = False
                    else: item[0]['role'] = 'audit'
                    path.write_text(json.dumps(item))
                with patch.object(fitting, 'ROOT', root), patch.object(fitting.assets, 'checked_asset',
                        side_effect=lambda ref: Path(ref['path'])), self.assertRaises(ValueError):
                    fitting.validate_barrier(folder, plan, bundle)

    def test_third_arm_smoke_failure_precedes_any_training_call(self):
        values = self.smoke_inputs()
        _, reference, surrogate, proxies, train, context, idx, outer, _, _ = values
        roles = {role: [dict(role=role, split='train', scenario_id=f'{role}{i}') for i in range(n)]
                 for role, n in (('train', 512), ('dev', 128), ('audit', 256))}
        parent = dict(roles=roles, victim_epochs=200, training_seed=123, seed=123,
                      references=dict(role_plan={}, input_contract={}, proxy1={}, proxy2={}))
        plan = dict(parent=parent, arms=list(fitting.ARMS), hard_support=reference.hard_support.tolist(),
                    training_config=asdict(ResidualTrainingConfig()), training_seed=123,
                    distribution_config=deepcopy(fitting.DISTRIBUTION_CONFIG), execution=dict(device='cpu', torch_threads=2),
                    references=dict(surrogate={}))
        seen = []

        def smoke(*args):
            arm = args[-1].arm
            seen.append(arm)
            if arm == 'conditional':
                raise ValueError('synthetic conditional gradient failure')
            return dict(projected_outer_output_sha256='replay')

        with tempfile.TemporaryDirectory() as directory, ExitStack() as stack:
            root = Path(directory)
            path = root / 'surrogate.pt'
            torch.save(surrogate.state_dict(), path)
            stack.enter_context(patch.object(fitting, 'ROOT', root))
            stack.enter_context(patch.object(fitting.assets, 'checked_asset', return_value=path))
            stack.enter_context(patch.object(fitting.baseline.prior, 'validate_roles'))
            stack.enter_context(patch.object(fitting.previous, 'checked_json', return_value={}))
            stack.enter_context(patch.object(fitting.baseline.prior, 'restore', return_value=(
                dict(model_construct=lambda *args: deepcopy(proxies[0])), None,
                SimpleNamespace(shadow_model=surrogate), None, reference.selected_coordinates, None)))
            stack.enter_context(patch.object(fitting.baseline.prior, 'new_generator', return_value=None))
            stack.enter_context(patch.object(fitting.baseline.accepted, 'new_model', return_value=None))
            stack.enter_context(patch.object(fitting, 'restore_projected_reference', return_value=reference))
            stack.enter_context(patch.object(fitting.previous, 'load_train', return_value=([], None, train, idx, context)))
            stack.enter_context(patch.object(fitting, 'check_outer', return_value=outer))
            stack.enter_context(patch.object(fitting, 'read_role_part', return_value=train))
            stack.enter_context(patch.object(fitting, 'transform_features', side_effect=lambda x, _: x))
            stack.enter_context(patch.object(fitting.baseline.checkpoint, 'combine', return_value=train))
            stack.enter_context(patch.object(fitting.previous, 'input_digest', return_value='inputs'))
            stack.enter_context(patch.object(fitting.baseline.prior.parent.dual, 'dev_quality',
                                            return_value=dict(gate='PASS_PROXY_QUALITY')))
            stack.enter_context(patch.object(fitting, 'gradient_smoke', side_effect=smoke))
            trainer = stack.enter_context(patch.object(fitting, 'fit_distribution_residual'))
            victim = stack.enter_context(patch.object(fitting.baseline, 'fit_victim'))
            step = stack.enter_context(patch.object(torch.optim.Adam, 'step'))
            with self.assertRaisesRegex(ValueError, 'synthetic conditional'):
                fitting.fit_arms(root / 'record/reproduction/spear_distribution_training_v1/run/training', plan)
            self.assertEqual(seen, list(fitting.ARMS))
            trainer.assert_not_called()
            victim.assert_not_called()
            step.assert_not_called()

    def test_complete_mock_fit_serializes_discriminator_snapshots_and_opens_barrier_only_last(self):
        _, reference, surrogate, proxies, train, context, idx, outer, _, _ = self.smoke_inputs()
        roles = {role: [dict(role=role, split='train', scenario_id=f'{role}{i}', graph_path=f'{role}{i}.npz',
                           graph_sha256=f'hash{role}{i}') for i in range(n)]
                 for role, n in (('train', 512), ('dev', 128), ('audit', 256))}
        parent = dict(roles=roles, victim_epochs=200, training_seed=123, seed=123,
            victim_initialization_digest='victim-init', victim_fit_rng_digest='victim-rng',
            references=dict(role_plan={}, input_contract={}, proxy1={}, proxy2={}))
        plan = dict(parent=parent, arms=list(fitting.ARMS), hard_support=reference.hard_support.tolist(),
            training_config=asdict(ResidualTrainingConfig()), training_seed=123,
            distribution_config=deepcopy(fitting.DISTRIBUTION_CONFIG), execution=dict(device='cpu', torch_threads=2),
            references=dict(surrogate={}))
        fit_order = []

        with tempfile.TemporaryDirectory() as directory, ExitStack() as stack:
            root = Path(directory)
            parent['graph_dir'] = str(root / 'graphs')
            path = root / 'surrogate.pt'
            torch.save(surrogate.state_dict(), path)
            folder = root / 'record/reproduction/spear_distribution_training_v1/run/training'

            def add_ledger(row, ledger):
                ledger.append(dict(role=row['role'], split='train', scenario_id=row['scenario_id'],
                    path=str((Path(parent['graph_dir']) / row['graph_path']).resolve()),
                    sha256=row['graph_sha256'], status='READ_COMPLETE'))

            def load_train(_plan, _normalizer, ledger):
                for row in roles['train']:
                    add_ledger(row, ledger)
                return [], None, train, idx, context

            def read_dev(row, _parent, allowed_role, ledger):
                self.assertEqual(allowed_role, 'dev')
                add_ledger(row, ledger)
                return train

            def mock_train(generator, source, features, ctx, labels, train_idx, attach, fixed_outer,
                           penalty, config, distribution, progress=None):
                self.assertTrue((folder / 'all_arms_preflight.json').exists())
                self.assertFalse((folder / 'optimization_complete.json').exists())
                self.assertEqual(distribution.steps, 0)
                self.assertEqual(distribution.generator_calls, 0)
                fit_order.append(distribution.arm)
                result = self.training_result(distribution.arm)
                d_hash = fitting.state_sha256(distribution.discriminator)
                result.update(generator=generator, surrogate=deepcopy(source),
                    initial_state_sha256=dict(generator=fitting.state_sha256(generator), surrogate=fitting.state_sha256(source)),
                    distribution_initial_state_sha256=d_hash, distribution_final_state_sha256=d_hash,
                    input_sha256={'mock': 'identical'}, frozen_state_sha256={'mock': 'identical'},
                    initial_cpu_rng_sha256=fitting._tensor_hash(torch.random.get_rng_state()), history=[])
                with torch.no_grad():
                    injected = generator.inject(features, ctx, attach, detach=True)
                result.update(poisoned_features=injected.features, poisoned_labels=labels.clone(),
                    edge_index=ctx.edge_index, edge_weight=features.new_ones(ctx.edge_index.shape[1]))
                distribution._steps = result['discriminator_steps']
                distribution._generator_calls = 200
                penalty.history.extend([dict(mock=True)] * 200)
                return result

            def mock_victim(_api, _args, _train, _dev, _idx, _result, _parent, arm_dir, _state):
                model = classifier().eval().requires_grad_(False)
                torch.save(model.state_dict(), arm_dir / 'victim_auc.pt')
                return model, dict(victim=fitting.assets.asset(arm_dir / 'victim_auc.pt'),
                    trace=dict(training_forwards=200, eval_forwards=200),
                    initialization_digest='victim-init', fit_rng_digest='victim-rng')

            stack.enter_context(patch.object(fitting, 'ROOT', root))
            stack.enter_context(patch.object(fitting.assets, 'checked_asset',
                side_effect=lambda ref: Path(ref['path']) if ref else path))
            stack.enter_context(patch.object(fitting.baseline.prior, 'validate_roles'))
            stack.enter_context(patch.object(fitting.previous, 'checked_json',
                side_effect=lambda ref: json.loads(Path(ref['path']).read_text()) if ref else {}))
            stack.enter_context(patch.object(fitting.baseline.prior, 'restore', return_value=(
                dict(model_construct=lambda *args: deepcopy(proxies[0])), None,
                SimpleNamespace(shadow_model=surrogate), None, reference.selected_coordinates, None)))
            stack.enter_context(patch.object(fitting.baseline.prior, 'new_generator', return_value=None))
            stack.enter_context(patch.object(fitting.baseline.accepted, 'new_model', return_value=None))
            stack.enter_context(patch.object(fitting, 'restore_projected_reference', return_value=reference))
            stack.enter_context(patch.object(fitting.previous, 'load_train', side_effect=load_train))
            stack.enter_context(patch.object(fitting, 'check_outer', return_value=outer))
            stack.enter_context(patch.object(fitting, 'read_role_part', side_effect=read_dev))
            stack.enter_context(patch.object(fitting, 'transform_features', side_effect=lambda x, _: x))
            stack.enter_context(patch.object(fitting.baseline.checkpoint, 'combine', return_value=train))
            stack.enter_context(patch.object(fitting.previous, 'input_digest', return_value='inputs'))
            stack.enter_context(patch.object(fitting.baseline.prior.parent.dual, 'dev_quality',
                return_value=dict(gate='PASS_PROXY_QUALITY')))
            stack.enter_context(patch.object(fitting.baseline, 'validate_poisoned_inputs'))
            stack.enter_context(patch.object(fitting, 'fit_distribution_residual', side_effect=mock_train))
            stack.enter_context(patch.object(fitting.baseline, 'fit_victim', side_effect=mock_victim))
            step = stack.enter_context(patch.object(torch.optim.Adam, 'step'))
            fitted = fitting.fit_arms(folder, plan)
            self.assertEqual(fit_order, list(fitting.ARMS))
            self.assertEqual(fitting.validate_barrier(folder, plan, fitted)['steps'], fitting.EXPECTED_STEPS)
            for arm in fitting.ARMS:
                metadata = json.loads((folder / arm / 'distribution_record.json').read_text())
                final = torch.load(metadata['final_checkpoint']['path'], weights_only=True)
                self.assertEqual(final['steps'], 0 if arm == 'continuation' else 200)
                self.assertEqual(final['generator_calls'], 200)
                self.assertTrue(any(isinstance(value, torch.Tensor) for value in final['discriminator'].values()))
                self.assertNotIn('discriminator', metadata['final'])
                self.assertNotIn('optimizer', metadata['final'])
            step.assert_not_called()


if __name__ == '__main__':
    unittest.main()
