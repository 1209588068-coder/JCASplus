"""Replication orchestration contracts; no real fitting or graph deserialization."""
from contextlib import ExitStack
from copy import deepcopy
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import numpy as np
import torch

from experiments.spear_distribution_replication_v1 import workflow as w


def master():
    return dict(created_at_utc='synthetic', source_template=dict(
        parent=dict(seed=20260621,shuffle_seed=20260621,training_seed=20263621),
        training_seed=20263621,distribution_config=dict(seed=20261621),
        data_contract=dict(rows=['same_train_ids']),original_csvs=dict(raw_targets='same_targets')),
        source_catalog={},contract=dict(acceptance=dict(overall_incremental_asr_min=.8)))


class ReplicationWorkflowTests(unittest.TestCase):
    def test_output_does_not_touch_old_experiments(self):
        for path in (w.ROOT, w.ROOT/'record/v6', w.ROOT/'record/v6_4',w.AUDIT_PLAN.parent,
                     w.ROOT/'record/reproduction/spear_distribution_training_v1/new',
                     w.ROOT/'record/reproduction'/w.VERSION):
            with self.assertRaises(ValueError): w.output_path(path)
        p = w.ROOT/'record/reproduction'/w.VERSION/'new'
        self.assertEqual(w.output_path(p),p)

    def test_seed_split_preserves_entire_parent_data_selection(self):
        original = master(); before = deepcopy(original)
        for seed in w.SEEDS[1:]:
            plan = w.child_plan(original,seed,dict(path='fixed_master',sha256='fixed'))
            self.assertEqual(plan['parent'],original['source_template']['parent'])
            self.assertEqual(plan['data_contract'],original['source_template']['data_contract'])
            self.assertEqual(plan['original_csvs'],original['source_template']['original_csvs'])
            self.assertEqual(plan['training_seed'],20263621)
            self.assertEqual(plan['distribution_config']['seed'],20261621)
            self.assertEqual(plan['replication_seeds'],dict(continuation=seed+3000,discriminator=seed+1000,victim=seed))
            self.assertEqual(plan['contract'],original['contract'])
        self.assertEqual(original,before)
        for seed in (20260621,20260624,True):
            with self.assertRaises(ValueError): w.child_plan(original,seed,{})

    def test_existing_output_rejected_before_metadata_read(self):
        with TemporaryDirectory() as tmp, patch.object(w,'output_path',return_value=Path(tmp)), \
                patch.object(w,'fields',side_effect=AssertionError('overwrite')) as fields:
            with self.assertRaises(FileExistsError): w.prepare(tmp)
            fields.assert_not_called()

    def test_real_plan_is_metadata_only(self):
        with patch.object(np,'load',side_effect=AssertionError('array access')), \
                patch.object(torch,'load',side_effect=AssertionError('model access')):
            plan = w.fields()
        self.assertEqual(plan['seeds'],list(w.SEEDS))
        self.assertEqual(plan['new_seeds'],[20260622,20260623])
        self.assertEqual(plan['source_template']['parent']['seed'],20260621)
        self.assertEqual(plan['contract']['acceptance']['moving_incremental_asr_min'],.8)
        for key in ('original_val_arrays_loaded','original_test_arrays_loaded','full_pipeline_replication',
                    'independent_confirmation','automatic_promotion'):
            self.assertFalse(plan['contract'][key])

    def test_incomplete_fit_cannot_read_audit_or_reference(self):
        with patch.object(w.fitting,'validate_barrier',side_effect=ValueError('incomplete')) as guard, \
                patch.object(torch,'load',side_effect=AssertionError('early model')) as load:
            with self.assertRaisesRegex(ValueError,'incomplete'):
                w.evaluate_completed(Path('/synthetic'),{}, {},Mock(),{})
        guard.assert_called_once(); load.assert_not_called()

    def test_capture_uses_original_conditions_and_identical_single_injection(self):
        generator = SimpleNamespace(selected_coordinates=torch.arange(24),hard_support=torch.ones(24,dtype=torch.bool))
        injector = w.CapturingInjector(generator,20260621)
        injector.part = dict(motion_regime=np.array([False,True]))
        x = torch.zeros((2,784)); changed=x.clone(); changed[1,:24]=2
        e=torch.tensor([[0,1],[1,0]]); weights=torch.ones(2)
        with patch.object(w.source.AuditedInjector,'inject_trigger',return_value=(changed,e,weights)) as replay:
            injector.inject_trigger(torch.tensor([1]),x,e,weights,torch.device('cpu'))
        replay.assert_called_once()
        np.testing.assert_array_equal(injector.clean[0],np.zeros(24))
        np.testing.assert_array_equal(injector.changed[0],np.full(24,2))
        self.assertEqual(injector.moving,[True])
        changed[1,w.diagnostic.CONDITION_COORDINATES[0]]=1
        with patch.object(w.source.AuditedInjector,'inject_trigger',return_value=(changed,e,weights)), \
                self.assertRaisesRegex(ValueError,'conditions'):
            injector.inject_trigger(torch.tensor([1]),x,e,weights,torch.device('cpu'))

    def test_training_failure_no_audit_or_success_report(self):
        with TemporaryDirectory() as tmp, ExitStack() as stack:
            p=Path(tmp)/'plan.json'; plan=master()
            plan.update(source_review={'kind':'r'},source_distribution={'kind':'d'})
            w.assets.write_json(p,plan)
            stack.enter_context(patch.object(w,'load_plan',return_value=(p,plan)))
            stack.enter_context(patch.object(w,'checked_json',return_value={}))
            fit=stack.enter_context(patch.object(w,'run_seed',side_effect=ValueError('seed preflight failed')))
            aggregate=stack.enter_context(patch.object(w.reporting,'aggregate',side_effect=AssertionError('partial summary')))
            with self.assertRaisesRegex(ValueError,'seed preflight failed'): w.run(p)
            fit.assert_called_once(); aggregate.assert_not_called()
            self.assertFalse((p.parent/'summary.json').exists())
            self.assertFalse(json.loads((p.parent/'failure.json').read_text())['automatic_retry'])

    def test_all_seeds_run_even_if_first_has_bad_performance(self):
        with TemporaryDirectory() as tmp, ExitStack() as stack:
            p=Path(tmp)/'plan.json'; plan=master()
            plan.update(source_review={'kind':'r'},source_distribution={'kind':'d'})
            w.assets.write_json(p,plan)
            stack.enter_context(patch.object(w,'load_plan',return_value=(p,plan)))
            stack.enter_context(patch.object(w,'checked_json',return_value=dict(passed=False)))
            def seed_run(folder,child,progress,master_plan):
                folder.mkdir()
                w.assets.write_json(folder/'summary.json',dict(seed=child['replicate_seed'],passed=False))
                return dict(review={'kind':'r'},distribution={'kind':'d'})
            fit=stack.enter_context(patch.object(w,'run_seed',side_effect=seed_run))
            aggregate=stack.enter_context(patch.object(w.reporting,'aggregate',return_value=dict(synthetic=True)))
            result=w.run(p)
            self.assertEqual(fit.call_count,2)
            self.assertEqual([c.args[1]['replicate_seed'] for c in fit.call_args_list],list(w.SEEDS[1:]))
            self.assertEqual([r['seed'] for r in aggregate.call_args.args[0]],list(w.SEEDS))
            self.assertEqual(result['status'],'DISTRIBUTION_REPLICATION_COMPLETE_REVIEW_REQUIRED')

    def test_no_duplicate_launch(self):
        with TemporaryDirectory() as tmp, patch.object(w.subprocess,'Popen',side_effect=AssertionError('restart')) as popen:
            p=Path(tmp)/'plan.json'; w.assets.write_json(p,{})
            (p.parent/'launch_claim.json').mkdir()
            with patch.object(w,'load_plan',return_value=(p,{})):
                with self.assertRaisesRegex(ValueError,'cannot be restarted'): w.launch(p)
            popen.assert_not_called()

    def test_distribution_capture_statistics_and_arrays_round_trip(self):
        rng=np.random.default_rng(10)
        reference=dict(train_selected=rng.normal(size=(12,24)).astype(np.float32),
            train_conditions=rng.normal(size=(12,6)).astype(np.float32),
            train_moving=np.array([False,True]*6),reference_rows=[dict(id=i) for i in range(12)])
        frozen=w.statistics.fit_reference(reference['train_selected'],reference['train_conditions'],reference['train_moving'])
        clean=rng.normal(size=(224,24)).astype(np.float32)
        conditions=rng.normal(size=(224,6)).astype(np.float32)
        moving=np.array([False]*164+[True]*60)
        captured={arm:SimpleNamespace(clean=list(clean.copy()),conditions=list(conditions.copy()),
            moving=list(moving),changed=list(clean.copy()+i*.1)) for i,arm in enumerate(w.ARMS)}
        with TemporaryDirectory() as tmp, patch.object(w,'checked_json',return_value=frozen.to_metadata()):
            p=Path(tmp)
            ref=w.save_distribution(p,reference,captured,dict(source_reference={}))
            expected=w.statistics.evaluate(frozen,clean,conditions,moving,
                {a:np.stack(captured[a].changed) for a in w.ARMS})
            self.assertEqual(json.loads(Path(ref['path']).read_text()),expected)
            with np.load(p/'distribution_features.npz',allow_pickle=False) as arrays:
                np.testing.assert_array_equal(arrays['audit_clean'],clean)
            with (p/'distribution_comparison.csv').open() as stream:
                self.assertEqual(len(list(stream)),13)
        captured['conditional'].conditions[0]=conditions[0]+1
        with TemporaryDirectory() as tmp, patch.object(w,'checked_json',return_value=frozen.to_metadata()):
            with self.assertRaisesRegex(ValueError,'do not share'):
                w.save_distribution(Path(tmp),reference,captured,dict(source_reference={}))


if __name__=='__main__':
    unittest.main()
