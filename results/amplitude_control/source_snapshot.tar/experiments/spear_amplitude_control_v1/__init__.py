"""Frozen scalar-amplitude controls for local feature-space robustness studies."""

from .module import FrozenAmplitudeGenerator, calibrate_scale

__all__ = ['FrozenAmplitudeGenerator', 'calibrate_scale']
