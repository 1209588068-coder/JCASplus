# 固定预训练起点的三组多种子稳定性复核

## 范围与研究问题

本地AV2、研究者自有GNN的离线模型鲁棒性研究。用户同意在已经可用的ASR基础上验证模块收益。
本轮不新增算法模块，不改变原图/标签/监督/目标池，不读取原validation/test，不覆盖任何旧结果。

问题：在相同预训练起点、固定数据和相同主训练预算下，无条件/条件分布正则的修改代价改善是否
随下游训练随机性变化仍能观察到，且是否保持整体和Moving Incremental ASR≥80%？

不是从头完整复现SPEAR，不是新数据盲测，不检验原始选点或预训练生成器的种子敏感性。
20260621已经看过结果，复用作为历史第一点；20260622、20260623在本计划冻结后运行。

## 种子拆分（禁止直接覆盖旧parent.seed）

| replicate | 数据/目标/context种子 | 续训RNG | 判别器私有初始化 | fresh victim初始化/dropout |
|---|---:|---:|---:|---:|
| 20260621（复用） | 20260621 | 20263621 | 20261621 | 20260621 |
| 20260622（新增） | 20260621 | 20263622 | 20261622 | 20260622 |
| 20260623（新增） | 20260621 | 20263623 | 20261623 | 20260623 |

固定恢复同一completed domain_projection生成器和surrogate，原base generator、shadow、双clean proxy、
clean reference均不重训。G和surrogate不是随机重新初始化；续训随机性主要来自surrogate训练dropout。
判别器使用原同架构/同loss/同优化器，仅私有初始化seed不同，不做重采样。
victim仍为原GraphSAGE；每seed三个组内权重初态及fit前RNG必须完全匹配。
预先用无训练的fresh模型构造确定该seed摘要，再验证每个实际训练模型，不能沿用旧seed摘要或
把数据选择seed和模型初始化seed混在一起。

旧源文件、旧plan及旧85%gate不修改。新目录中的显式seed适配器复用旧损失计算，
基准seed必须与旧判别器输出、初态和梯度一致；新seed的构造不得污染调用方RNG。

## 每seed相同三组

- continuation：仅原损失继续训练；不加分布正则。
- unconditional：24维选中特征＋6维全零条件，原分布正则。
- conditional：24维选中特征＋6维原干净观测条件，原分布正则。

所有组：固定24个支持坐标、输出clamp[-10,10]、26个投毒pair、538个outer行、原normalizer、
train512/internal dev128/reused audit256（全部来自原TRAIN）。每组200 residual/surrogate steps和
200 victim epochs；生成器取最后epoch199，victim按相同内部dev AUC最早并列最优选点。
判别器更新分别0/200/200；主更新次数相同不代表总计算量完全相同。

两新seed合计1200 residual steps、1200 surrogate steps、1200 victim epochs、800 D steps。
CPU2线程、顺序执行，日志和结果独立写入 `record/reproduction/spear_distribution_replication_v1/`。
每seed三组训练均完成且完整性屏障通过后，才能读取该seed的固定audit目标并计算性能。
不得依据第一个seed的效果取消另一个seed或更换配置/种子。完整性、非有限值或运行异常则停止，
保留已完成数据，不自动重试。

## 冻结评价与门槛

整体和Moving Incremental ASR≥80%；Adjacent incremental FP<5%；正常AUC下降≤0.005；
正类召回下降≤0.05，并拒绝模型全部预测负类。保留原SAGE24质量参照，分布组另外对照同seed
continuation。SAGE24是固定的历史单seed，因此跨seed与其差异也包含初始化影响；
模块归因主要看同seed配对差，不把单seed历史差异全部解释为模块效应。

无论门槛通过与否，报告全部有限结果；旧85%门槛仅保存为历史视图，不当新门槛或追溯改写。
80%标准对新seed是预先约定，对已观察的20260621则明确是事后修订。

沿用上一轮分布诊断的固定口径：原train512每场景按既有负pair身份哈希抽一条，共447条参考；
24个相同可修改坐标，原clean6维条件；selected/joint全train参考固定带宽MMD²、平均边际W1、
训练1%/99%分位外比例、±10边界比例、L1/L2/L∞修改量。按all/slow/moving报告干净基线及三组。
在正常audit生成前向中直接采集，不额外拟合判别器或重新调带宽。
参考元数据必须与上一轮诊断完全一致，输出数组保存以便复算。

## 汇总与决策

按每seed均值和样本SD（ddof=1），列出两distribution相对continuation、conditional相对unconditional
的同seed配对差。不能把重复224个目标堆成672个独立样本，不能删掉不佳seed。
缺失指标明确不可用，不填0或只用剩余seed偷偷计算均值。

本轮只提供稳定性证据，不承诺一定成功、不自动晋升主方法、不自动新增实验。
若条件化没有稳定独立收益，优先简单版本，而不是以模块数量作为贡献证明。
分布距离改善不等于物理一致性、自然性、统计显著性或论文新颖性证明。
