"""Isolated distribution-aware residual continuation pilot."""
