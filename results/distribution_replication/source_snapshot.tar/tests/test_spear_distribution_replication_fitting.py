"""Synthetic paired orchestration; all graph I/O and real optimization mocked."""
from copy import deepcopy
from dataclasses import asdict
from contextlib import ExitStack
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np
import torch

from experiments.spear_distribution_replication_v1 import fitting
from experiments.spear_pair_role_generator_v1.training import ResidualTrainingConfig
from tests import test_spear_distribution_training_fitting as old_tests
from tests.test_spear_domain_training_module import classifier


class ReplicationFittingTests(unittest.TestCase):
    smoke_inputs = old_tests.DistributionTrainingFittingTests.smoke_inputs
    training_result = staticmethod(old_tests.DistributionTrainingFittingTests.training_result)

    def setUp(self):
        torch.set_num_threads(1)

    @staticmethod
    def plan(seed=20260622):
        return dict(replicate_seed=seed, replication_seeds=fitting.replication_seeds(seed),
            training_seed=20263621, distribution_config=deepcopy(fitting.DISTRIBUTION_CONFIG),
            parent=dict(seed=20260621, shuffle_seed=20260621, training_seed=20263621),
            arms=list(fitting.ARMS), training_config=asdict(ResidualTrainingConfig()),
            execution=dict(device='cpu', torch_threads=2))

    def test_plan_separates_historical_data_seed_from_actual_seed_and_namespace(self):
        for seed in (20260622, 20260623):
            plan = self.plan(seed)
            before = deepcopy(plan)
            self.assertEqual(fitting.validate_replication_plan(plan), fitting.replication_seeds(seed))
            self.assertEqual(fitting.effective_distribution_config(plan)['seed'], seed + 1000)
            self.assertEqual(plan, before)
            for key in ('seed', 'shuffle_seed', 'training_seed'):
                bad = deepcopy(plan)
                bad['parent'][key] += 1
                with self.subTest(key=key), self.assertRaises(ValueError):
                    fitting.validate_replication_plan(bad)
            bad = deepcopy(plan)
            bad['replication_seeds']['victim'] = 20260621
            with self.assertRaises(ValueError):
                fitting.validate_replication_plan(bad)
        root = fitting.ROOT / 'record/reproduction/spear_distribution_replication_v1'
        self.assertEqual(fitting.output_path(root / 'run/seed20260622/training'), root / 'run/seed20260622/training')
        for path in (root / 'training', root, fitting.ROOT / 'record/reproduction/spear_distribution_training_v1/run/training'):
            with self.assertRaises(ValueError):
                fitting.output_path(path)

    def test_invalid_config_or_seed_fails_before_restore_or_output_creation(self):
        plan = self.plan()
        with patch.object(fitting.baseline.prior, 'restore') as restore:
            for field in ('replicate_seed', 'training_seed'):
                bad = deepcopy(plan)
                bad[field] = 999
                with self.assertRaises(ValueError):
                    fitting.fit_arms('/not/an/output', bad)
            restore.assert_not_called()

    def test_new_distribution_binds_only_clean_outer_and_rng_stays_local(self):
        generator, _, _, _, train, _, _, outer, _, _ = self.smoke_inputs()
        for seed in (20260622, 20260623):
            plan = self.plan(seed)
            hashes = []
            for arm in fitting.ARMS:
                rng = torch.random.get_rng_state().clone()
                reg = fitting.new_distribution(arm, train, outer, generator, plan)
                self.assertTrue(torch.equal(rng, torch.random.get_rng_state()))
                reg.validate_binding(train['x'], outer, generator.selected_coordinates[generator.hard_support])
                self.assertEqual(reg.snapshot()['config']['seed'], seed + 1000)
                self.assertEqual(reg.snapshot()['provenance']['population'], 'original538_outer')
                hashes.append(fitting.state_sha256(reg.discriminator))
            self.assertEqual(len(set(hashes)), 1)

    def test_continuation_rng_seed_contract_is_deterministic_and_nonmutating(self):
        before = torch.random.get_rng_state().clone()
        a = fitting.continuation_rng_digest(20263622)
        self.assertEqual(a, fitting.continuation_rng_digest(20263622))
        self.assertNotEqual(a, fitting.continuation_rng_digest(20263623))
        self.assertTrue(torch.equal(before, torch.random.get_rng_state()))

    def test_two_completed_paired_mock_fits_and_seed_tamper_barrier(self):
        for seed in (20260622, 20260623):
            with self.subTest(seed=seed):
                self.mock_fit(seed)

    def test_third_arm_smoke_failure_precedes_any_optimization(self):
        self.mock_fit(fail_smoke=True)

    def test_wrong_actual_continuation_rng_prevents_victim_and_barrier(self):
        self.mock_fit(wrong_rng=True)

    def mock_fit(self, seed=20260622, fail_smoke=False, wrong_rng=False):
        _, reference, surrogate, proxies, train, context, idx, outer, _, _ = self.smoke_inputs()
        roles = {role: [dict(role=role, split='train', scenario_id=f'{role}{i}', graph_path=f'{role}{i}.npz',
                           graph_sha256=f'hash{role}{i}') for i in range(n)]
                 for role, n in (('train', 512), ('dev', 128), ('audit', 256))}
        parent = dict(roles=roles, victim_epochs=200, training_seed=20263621, seed=20260621, shuffle_seed=20260621,
            victim_initialization_digest='victim-init', victim_fit_rng_digest='victim-rng',
            references=dict(role_plan={}, input_contract={}, proxy1={}, proxy2={}))
        plan = dict(parent=parent, arms=list(fitting.ARMS), hard_support=reference.hard_support.tolist(),
            training_config=asdict(ResidualTrainingConfig()), training_seed=20263621,
            distribution_config=deepcopy(fitting.DISTRIBUTION_CONFIG), execution=dict(device='cpu', torch_threads=2),
            references=dict(surrogate={}), replicate_seed=seed, replication_seeds=fitting.replication_seeds(seed))
        fit_order, events = [], []
        original_plan = deepcopy(plan)

        with tempfile.TemporaryDirectory() as directory, ExitStack() as stack:
            root = Path(directory)
            parent['graph_dir'] = str(root / 'graphs')
            path = root / 'surrogate.pt'
            torch.save(surrogate.state_dict(), path)
            folder = root / 'record/reproduction/spear_distribution_replication_v1/run/seed20260622/training'

            def add_ledger(row, ledger):
                ledger.append(dict(role=row['role'], split='train', scenario_id=row['scenario_id'],
                    path=str((Path(parent['graph_dir']) / row['graph_path']).resolve()),
                    sha256=row['graph_sha256'], status='READ_COMPLETE'))

            def load_train(_plan, _normalizer, ledger):
                for row in roles['train']:
                    add_ledger(row, ledger)
                return [], None, train, idx, context

            def collect_reference(parts, rows, selected, target_seed):
                self.assertEqual(target_seed, 20260621)
                self.assertEqual(rows, roles['train'])
                self.assertFalse(events)
                events.append('reference')
                return dict(train_selected=np.zeros((3, 24), dtype=np.float32),
                    train_conditions=np.zeros((3, 6), dtype=np.float32), train_moving=np.array([0, 1, 0], dtype=bool),
                    reference_rows=[{'scenario_id': str(i)} for i in range(3)], reference_scenes_without_target=[])

            def read_dev(row, _parent, allowed_role, ledger):
                self.assertEqual(events[0], 'reference')
                self.assertEqual(allowed_role, 'dev')
                add_ledger(row, ledger)
                return train

            def mock_train(generator, source, features, ctx, labels, train_idx, attach, fixed_outer,
                           penalty, config, distribution, progress=None):
                self.assertTrue((folder / 'all_arms_preflight.json').exists())
                self.assertFalse((folder / 'optimization_complete.json').exists())
                self.assertEqual(distribution.steps, 0)
                self.assertEqual(distribution.generator_calls, 0)
                self.assertEqual(distribution.snapshot()['config']['seed'], seed + 1000)
                self.assertEqual(torch.initial_seed(), seed + 3000)
                fit_order.append(distribution.arm)
                result = self.training_result(distribution.arm)
                d_hash = fitting.state_sha256(distribution.discriminator)
                result.update(generator=generator, surrogate=deepcopy(source),
                    initial_state_sha256=dict(generator=fitting.state_sha256(generator), surrogate=fitting.state_sha256(source)),
                    distribution_initial_state_sha256=d_hash, distribution_final_state_sha256=d_hash,
                    input_sha256={'mock': 'identical'}, frozen_state_sha256={'mock': 'identical'},
                    initial_cpu_rng_sha256=('wrong' if wrong_rng else fitting._tensor_hash(torch.random.get_rng_state())), history=[])
                with torch.no_grad():
                    injected = generator.inject(features, ctx, attach, detach=True)
                result.update(poisoned_features=injected.features, poisoned_labels=labels.clone(),
                    edge_index=ctx.edge_index, edge_weight=features.new_ones(ctx.edge_index.shape[1]))
                distribution._steps = result['discriminator_steps']
                distribution._generator_calls = 200
                penalty.history.extend([dict(mock=True)] * 200)
                return result

            def mock_victim(_api, _args, _train, _dev, _idx, _result, _parent, arm_dir, _state, *, victim_seed, expected):
                self.assertEqual(victim_seed, seed)
                self.assertEqual(expected['victim_seed'], seed)
                self.assertEqual(_parent['seed'], 20260621)
                model = classifier().eval().requires_grad_(False)
                torch.save(model.state_dict(), arm_dir / 'victim_auc.pt')
                return model, dict(victim=fitting.assets.asset(arm_dir / 'victim_auc.pt'),
                    trace=dict(training_forwards=200, eval_forwards=200),
                    **expected, expected_initialization=expected)

            stack.enter_context(patch.object(fitting, 'ROOT', root))
            stack.enter_context(patch.object(fitting.assets, 'checked_asset',
                side_effect=lambda ref: Path(ref['path']) if ref else path))
            stack.enter_context(patch.object(fitting.baseline.prior, 'validate_roles'))
            stack.enter_context(patch.object(fitting.previous, 'checked_json',
                side_effect=lambda ref: json.loads(Path(ref['path']).read_text()) if ref else {}))
            stack.enter_context(patch.object(fitting.baseline.prior, 'restore', return_value=(
                dict(model_construct=lambda *args: deepcopy(proxies[0])), None,
                SimpleNamespace(shadow_model=surrogate), None, reference.selected_coordinates, None)))
            stack.enter_context(patch.object(fitting.baseline.prior, 'new_generator', return_value=None))
            stack.enter_context(patch.object(fitting.baseline.accepted, 'new_model', return_value=None))
            stack.enter_context(patch.object(fitting, 'restore_projected_reference', return_value=reference))
            stack.enter_context(patch.object(fitting.previous, 'load_train', side_effect=load_train))
            stack.enter_context(patch.object(fitting, 'check_outer', return_value=outer))
            stack.enter_context(patch.object(fitting, 'collect_reference', side_effect=collect_reference))
            stack.enter_context(patch.object(fitting, 'read_role_part', side_effect=read_dev))
            stack.enter_context(patch.object(fitting, 'transform_features', side_effect=lambda x, _: x))
            stack.enter_context(patch.object(fitting.baseline.checkpoint, 'combine', return_value=train))
            stack.enter_context(patch.object(fitting.previous, 'input_digest', return_value='inputs'))
            stack.enter_context(patch.object(fitting.baseline.prior.parent.dual, 'dev_quality',
                return_value=dict(gate='PASS_PROXY_QUALITY')))
            stack.enter_context(patch.object(fitting.baseline, 'validate_poisoned_inputs'))
            stack.enter_context(patch.object(fitting, 'fit_distribution_residual', side_effect=mock_train))
            victim_fit = stack.enter_context(patch.object(fitting, 'fit_victim', side_effect=mock_victim))
            if fail_smoke:
                real_smoke = fitting.gradient_smoke
                def smoke(*args):
                    self.assertFalse(fit_order)
                    events.append(args[-1].arm)
                    if args[-1].arm == 'conditional':
                        raise ValueError('synthetic conditional smoke failure')
                    return real_smoke(*args)
                stack.enter_context(patch.object(fitting, 'gradient_smoke', side_effect=smoke))
            step = stack.enter_context(patch.object(torch.optim.Adam, 'step'))
            if fail_smoke or wrong_rng:
                with self.assertRaisesRegex(ValueError, 'synthetic conditional' if fail_smoke else 'fresh discriminator'):
                    fitting.fit_arms(folder, plan)
                self.assertFalse((folder / 'optimization_complete.json').exists())
                victim_fit.assert_not_called()
                step.assert_not_called()
                if fail_smoke:
                    self.assertEqual(events, ['reference', *fitting.ARMS])
                    self.assertFalse(fit_order)
                return
            fitted = fitting.fit_arms(folder, plan)
            self.assertEqual(plan, dict(original_plan, parent=dict(original_plan['parent'], graph_dir=parent['graph_dir'])))
            self.assertEqual(fitted['barrier']['replication_seeds'], fitting.replication_seeds(seed))
            self.assertEqual(fitted['distribution_reference']['provenance']['target_seed'], 20260621)
            self.assertFalse(fitted['distribution_reference']['train_selected'].flags.writeable)
            self.assertEqual(fit_order, list(fitting.ARMS))
            self.assertEqual(fitting.validate_barrier(folder, plan, fitted)['steps'], fitting.EXPECTED_STEPS)
            for arm in fitting.ARMS:
                metadata = json.loads((folder / arm / 'distribution_record.json').read_text())
                final = torch.load(metadata['final_checkpoint']['path'], weights_only=True)
                self.assertEqual(final['steps'], 0 if arm == 'continuation' else 200)
                self.assertEqual(final['generator_calls'], 200)
                self.assertTrue(any(isinstance(value, torch.Tensor) for value in final['discriminator'].values()))
                self.assertNotIn('discriminator', metadata['final'])
                self.assertNotIn('optimizer', metadata['final'])
                self.assertEqual(metadata['actual_config']['seed'], seed + 1000)
                self.assertEqual(metadata['config']['seed'], 20261621)
            for artifact, key, value in (
                    ('training.json', 'victim_seed', 20260621),
                    ('generator_record.json', 'actual_continuation_seed', 20263621),
                    ('distribution_record.json', 'actual_config', fitting.DISTRIBUTION_CONFIG)):
                path = folder / 'conditional' / artifact
                original = path.read_text()
                item = json.loads(original)
                item[key] = value
                path.write_text(json.dumps(item))
                with self.subTest(tamper=artifact), self.assertRaises(ValueError):
                    fitting.validate_barrier(folder, plan, fitted)
                path.write_text(original)
            fitted['distribution_reference']['train_selected'].setflags(write=True)
            fitted['distribution_reference']['train_selected'][0, 0] = 1.
            with self.assertRaisesRegex(ValueError, 'barrier'):
                fitting.validate_barrier(folder, plan, fitted)
            step.assert_not_called()


if __name__ == '__main__':
    unittest.main()

