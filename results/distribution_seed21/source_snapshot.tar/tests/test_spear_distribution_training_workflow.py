"""Execution/scope boundaries; synthetic failures and metadata-only checks."""
from contextlib import ExitStack
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import Mock, patch

import numpy as np
import torch

from experiments.spear_distribution_training_v1 import workflow as w


class WorkflowTests(unittest.TestCase):
    def test_output_cannot_reuse_old_experiments(self):
        for path in (w.ROOT, w.ROOT / 'record/v6', w.ROOT / 'record/v6_4',
                     w.ROOT / 'record/reproduction/spear_domain_audit_v1/new',
                     w.ROOT / 'record/reproduction/spear_distribution_training_v1'):
            with self.assertRaises(ValueError):
                w.output_path(path)
        path = w.ROOT / 'record/reproduction/spear_distribution_training_v1/new'
        self.assertEqual(w.output_path(path), path)

    def test_prepare_existing_directory_fails_before_loading_metadata(self):
        with TemporaryDirectory() as tmp, patch.object(w, 'output_path', return_value=Path(tmp)), \
                patch.object(w, 'fields', side_effect=AssertionError('Metadata after overwrite')) as fields:
            with self.assertRaises(FileExistsError):
                w.prepare(tmp)
            fields.assert_not_called()

    def test_real_fields_are_metadata_only(self):
        with patch.object(np, 'load', side_effect=AssertionError('Array load during plan')) as arrays, \
                patch.object(torch, 'load', side_effect=AssertionError('Model load during plan')) as models:
            plan = w.fields()
        arrays.assert_not_called(); models.assert_not_called()
        self.assertEqual(plan['arms'], ['continuation', 'unconditional', 'conditional'])
        self.assertEqual(sum(plan['hard_support']), 24)
        self.assertEqual(plan['training_config']['epochs'], 200)
        self.assertFalse(plan['contract']['original_test_arrays_loaded'])
        self.assertFalse(plan['contract']['original_val_arrays_loaded'])
        self.assertIn('reader only', plan['data_contract']['scope']['applies_to'])
        self.assertNotIn('training_started', plan['data_contract']['scope'])

    def test_barrier_rejects_before_reference_or_audit_access(self):
        with patch.object(w.fitting, 'validate_barrier', side_effect=ValueError('Incomplete three-arm fit')) as barrier, \
                patch.object(torch, 'load', side_effect=AssertionError('Premature model load')) as models, \
                patch.object(w.baseline.field, 'read_audit_part', side_effect=AssertionError('Premature audit')) as arrays:
            with self.assertRaisesRegex(ValueError, 'Incomplete three-arm fit'):
                w.evaluate_completed(Path('/synthetic'), {}, {}, lambda **kw: None)
        barrier.assert_called_once()
        models.assert_not_called(); arrays.assert_not_called()

    def test_training_failure_does_not_start_audit_and_preserves_failure(self):
        with TemporaryDirectory() as tmp, ExitStack() as stack:
            output, plan = Path(tmp), dict(synthetic=True)
            stack.enter_context(patch.object(w, 'load_plan', return_value=(output / 'plan.json', plan)))
            stack.enter_context(patch.object(w.assets, 'asset', return_value=dict(path='synthetic', sha256='synthetic')))
            fit = stack.enter_context(patch.object(w.fitting, 'fit_arms', side_effect=ValueError('smoke gradient invalid')))
            evaluate = stack.enter_context(patch.object(w, 'evaluate_completed', side_effect=AssertionError('Premature audit')))
            with self.assertRaisesRegex(ValueError, 'smoke gradient invalid'):
                w.run(output / 'plan.json')
            fit.assert_called_once(); evaluate.assert_not_called()
            self.assertEqual(json.loads((output / 'failure.json').read_text())['error'], 'smoke gradient invalid')
            self.assertEqual(json.loads((output / 'state.json').read_text())['status'], 'STOPPED_DISTRIBUTION_TRAINING_ERROR')
            self.assertFalse((output / 'summary.json').exists())

    def test_existing_run_cannot_be_launched_twice(self):
        with TemporaryDirectory() as tmp, patch.object(w.subprocess, 'Popen', side_effect=AssertionError('Restart')) as popen:
            output = Path(tmp)
            # Use existing directory entry as the started guard; no synthetic file needed.
            (output / 'training').mkdir()
            with patch.object(w, 'load_plan', return_value=(output / 'plan.json', {})):
                with self.assertRaisesRegex(ValueError, 'cannot be restarted'):
                    w.launch(output / 'plan.json')
            popen.assert_not_called()

    def test_audit_reader_rejects_wrong_role_or_identity_before_io(self):
        row = dict(scenario_id='scene', split='train', role='audit')
        parent = dict(roles=dict(audit=[row]))
        reader = w.BoundAuditReader(parent, {}, [], {}, {}, Mock(), 'continuation')
        bad_rows = [dict(row, split='val'), dict(row, split='test'), dict(row, role='train'),
                    dict(row, role='dev'), dict(row, scenario_id='other')]
        with patch.object(w.baseline.field, 'read_audit_part', side_effect=AssertionError('Forbidden read')) as load:
            for bad in bad_rows:
                with self.assertRaisesRegex(ValueError, 'registered original TRAIN audit'):
                    reader(bad)
        load.assert_not_called()

    def test_both_audit_arms_share_cache_and_reject_changed_input(self):
        row = dict(scenario_id='scene', split='train', role='audit')
        parent = dict(roles=dict(audit=[row]))
        part = dict(scenario_id='scene', marker=1)
        cache, hashes, ledger, injector = {}, {}, [], Mock()
        readers = [w.BoundAuditReader(parent, {}, ledger, cache, hashes, injector, arm) for arm in w.ARMS]
        with patch.object(w.baseline.field, 'read_audit_part', return_value=part) as load, \
                patch.object(w.baseline.field, 'part_digest', side_effect=lambda x: str(x['marker'])):
            with self.assertRaisesRegex(ValueError, 'Only the first audit arm'):
                readers[1](row)
            load.assert_not_called()
            self.assertIs(readers[0](row), part)
            self.assertIs(readers[1](row), part)
            load.assert_called_once_with(row, parent, {}, ledger)
            part['marker'] = 2
            with self.assertRaisesRegex(ValueError, 'Audit inputs changed'):
                readers[1](row)
        self.assertEqual(injector.bind.call_count, 2)


if __name__ == '__main__':
    unittest.main()
