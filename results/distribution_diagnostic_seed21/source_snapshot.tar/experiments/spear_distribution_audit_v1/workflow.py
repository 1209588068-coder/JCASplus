"""Post-hoc TRAIN-only feature-distribution audit of three completed models.

Local AV2/self-owned GNN research. No optimization, formal VAL/TEST access,
old-result edits, model selection, automatic promotion or extra training.
The metrics are independent of the training discriminator, not independent
confirmation on previously untouched data.
"""
from __future__ import annotations

import argparse
from contextlib import ExitStack
import csv
import json
from pathlib import Path
import tarfile
import time
from unittest.mock import patch

import numpy as np
import torch

from experiments.spear_distribution_training_v1 import workflow as source
from experiments.spear_semantic_support_review_v1 import read_tables
from experiments.spear_semantic_support_v1.schema import SELECTED_COORDINATES, coordinate_metadata
from . import collection, statistics

ROOT, assets = source.ROOT, source.assets
VERSION = 'spear_distribution_audit_v1'
ARMS = ('continuation', 'unconditional', 'conditional')
SOURCE_PLAN = ROOT / 'record/reproduction/spear_distribution_training_v1/pilot_20261027_seed20260621_v1/plan.json'
SOURCE_PLAN_SHA = '9c25a1382d47e792c83cab04224f989db6c5473979d493d4b535c55e190ec3f7'
SOURCE_COMPLETION_SHA = 'c85cb690487aed220dfc3f3352fc8235a8bd8a5a9656521e504fd16c6dcbf9ff'
REFERENCE_POPULATION = 'train_one_eligible_negative_per_scene_by_original_audit_hash'
CONDITION_COORDINATES = [149, 199, 507, 557, 718, 721]


def fields():
    """Bind metadata before the diagnostic; do not deserialize model or graph arrays."""
    source_ref = dict(path=str(SOURCE_PLAN), sha256=SOURCE_PLAN_SHA)
    assets.checked_asset(source_ref)
    _, training_plan = source.load_plan(SOURCE_PLAN)
    completion_ref = dict(path=str(SOURCE_PLAN.parent / 'summary.json'), sha256=SOURCE_COMPLETION_SHA)
    complete = source.audit_source.previous.checked_json(completion_ref)
    if (complete['status'] != 'DISTRIBUTION_TRAINING_COMPLETE_REVIEW_REQUIRED'
            or complete['plan'] != source_ref
            or complete['original_val_arrays_loaded'] is not False
            or complete['original_test_arrays_loaded'] is not False):
        raise ValueError('Require the completed registered TRAIN-only three-arm experiment')
    barrier = source.audit_source.previous.checked_json(complete['optimization_complete'])
    if barrier['arms'] != list(ARMS) or barrier['steps'] != source.fitting.EXPECTED_STEPS:
        raise ValueError('Incomplete source three-arm optimization barrier')
    targets, budgets, training = {}, {}, {}
    for arm in ARMS:
        report = source.audit_source.previous.checked_json(complete['reports'][arm])
        if (report['training'] != barrier['training'][arm]
                or report['evaluation']['audit_counts'] != training_plan['expected_counts']):
            raise ValueError('Source report training identity or audit population changed')
        targets[arm] = {k: report['evaluation']['raw_targets'][k] for k in ('path', 'sha256')}
        budgets[arm] = report['budgets']
        training[arm] = report['training']
        record = source.audit_source.previous.checked_json(training[arm])
        for ref in (targets[arm], budgets[arm], record['generator']):
            assets.checked_asset(ref)
    assets.checked_asset(complete['review'])
    paths = sorted(Path(__file__).parent.glob('*.py'))
    paths += sorted((ROOT / 'tests').glob('test_spear_distribution_audit*.py'))
    paths.append(ROOT / 'docs/SPEAR_DISTRIBUTION_AUDIT_20261027.md')
    selected = [c for c, flag in zip(SELECTED_COORDINATES, training_plan['hard_support']) if flag]
    if len(selected) != 24 or set(selected).intersection(CONDITION_COORDINATES):
        raise ValueError('Changed selected/condition coordinate contract')
    return dict(version=VERSION, source_plan=source_ref, source_completion=completion_ref,
        source_optimization_complete=complete['optimization_complete'], source_review=complete['review'],
        source_reports=complete['reports'], source_training=training, source_targets=targets,
        source_budgets=budgets,
        source_original_targets={k: training_plan['original_csvs']['raw_targets'][k] for k in ('path', 'sha256')},
        reference_population=REFERENCE_POPULATION, arms=list(ARMS),
        selected_coordinates=selected, condition_coordinates=CONDITION_COORDINATES,
        selected_schema=[coordinate_metadata(c) for c in selected],
        condition_schema=[coordinate_metadata(c) for c in CONDITION_COORDINATES],
        source_catalog={str(p.relative_to(ROOT)): assets.sha256(p) for p in paths},
        execution=dict(device='cpu', torch_threads=2),
        metrics_contract=dict(
            scaling='existing frozen JCAS standardized coordinates; divide10 only; no second z-score',
            selected_embedding='selected24/(10*sqrt24)',
            joint_embedding='concat(selected24/(10*sqrt24),clean_conditions6/(10*sqrt6))',
            kernels='RBF exp(-squared_distance/(2*sigma_squared)); biased MMD squared V-stat includes diagonals',
            bandwidth='selected/joint each use all-clean-train median positive pairwise distance; shared across arms and strata',
            marginal_distance='mean of24 one-dimensional empirical Wasserstein-1 distances in existing standardized units',
            reference_strata='train all/slow/moving matched to original clean audit strata, never regroup triggered outputs',
            anomaly='strict outside per-stratum train .01/.99 linear empirical quantiles; both coordinate and row rates',
            boundary='abs(abs(value)-10)<=1e-6, relative_tolerance0',
            modifications='trigger minus same target clean: L1,L2,Linf in existing standardized units',
            baseline='clean audit versus clean train with exactly the same metrics and bandwidth',
            absent_stratum='explicit unavailable, no borrowing another reference population',
            inference='descriptive distances, no significance tests, no tuned thresholds or bandwidth search'),
        contract=dict(
            phase='posthoc_diagnostic_rules_fixed_after_ASR_seen_before_new_distribution_values',
            reference_selection='same old eligible-negative identity hash, one per original train512 scene',
            evaluation='unchanged224 targets from256 original TRAIN audit scenes; all/slow/moving',
            evaluation_predictor_models_loaded=False, trained_discriminator_loaded=False,
            generator_internal_frozen_shadow_loaded=True,
            expected_generator_forwards=672, optimizer_steps=0, normalizer_refit=False,
            source_budget_replay='exact per-target old scope and L1/Linf record',
            topology_unchanged=True, non_target_features_unchanged=True, support_unchanged=True,
            original_training_role_arrays_loaded=True, internal_audit_arrays_loaded=True,
            internal_dev_arrays_loaded=False, original_val_arrays_loaded=False, original_test_arrays_loaded=False,
            independent_of_training_discriminator=True, independent_confirmation=False,
            joint_distance_is_not_proof_of_conditional_matching=True, physical_validity_claim=False,
            prospective_usability=dict(overall_incremental_asr_min=.80, moving_incremental_asr_min=.80,
                adjacent_incremental_fp_max_exclusive=.05, normal_auc_drop_max=.005,
                normal_positive_recall_drop_max=.05,
                provenance='user revised after source run; separate view, original85pct gates preserved'),
            automatic_training=False, automatic_promotion=False, automatic_followup=False))


def output_path(path):
    path = Path(path).resolve()
    allowed = ROOT / 'record/reproduction' / VERSION
    if path == allowed or not path.is_relative_to(allowed):
        raise ValueError('Require a new child of the distribution-audit namespace')
    return path


def prepare(output):
    output = output_path(output)
    if output.exists():
        raise FileExistsError('Never overwrite an existing audit')
    plan = dict(created_at_utc=source.baseline.now(), **fields())
    output.mkdir(parents=True, exist_ok=False)
    assets.write_json(output / 'plan.json', plan)
    with tarfile.open(output / 'source_snapshot.tar', 'x') as archive:
        for name in plan['source_catalog']:
            archive.add(ROOT / name, arcname=name, recursive=False)
    return output / 'plan.json'


def load_plan(path):
    path = Path(path).resolve()
    output_path(path.parent)
    if path.name != 'plan.json':
        raise ValueError('Require plan.json')
    plan = json.loads(path.read_text())
    if {k: v for k, v in plan.items() if k != 'created_at_utc'} != fields():
        raise ValueError('Diagnostic source, references or metric contract changed')
    return path, plan


def usability_view(old_review):
    """New user criterion is a separate retrospective view, never a gate rewrite."""
    result = {}
    for arm in ARMS:
        m = old_review['metrics'][arm]['victim']
        checks = {k: v for k, v in old_review['gates'][arm]['checks'].items()
                  if k not in ('overall_incremental_asr_at_least_85pct', 'moving_incremental_asr_at_least_85pct')}
        checks.update(overall_incremental_asr_at_least_80pct=m['targets']['all']['incremental_asr'] >= .8,
                      moving_incremental_asr_at_least_80pct=m['targets']['moving']['incremental_asr'] >= .8)
        result[arm] = dict(checks=checks, meets_user_revised_criteria=all(checks.values()),
            original85_gate=old_review['gates'][arm], original_gate_unchanged=True)
    return result


def save_csv(path, rows):
    if not rows:
        raise ValueError('Cannot write an empty identity table')
    with path.open('x', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def compact_report(measured):
    """Report every fixed metric and its direction; no result-driven winner selection."""
    rows, comparisons = [], {}
    for regime, stratum in measured['strata'].items():
        if stratum['status'] != 'AVAILABLE':
            comparisons[regime] = dict(status='NOT_AVAILABLE', reason=stratum['reason'])
            continue
        base = stratum['clean_audit']
        points = dict(clean_audit=base, **stratum['arms'])
        compact = {}
        for arm, point in points.items():
            metrics = dict(
                selected_mmd2=point['versus_train']['rbf_mmd2_biased_selected'],
                joint_mmd2=point['versus_train']['rbf_mmd2_biased_joint'],
                marginal_w1=point['versus_train']['wasserstein_1d_mean'],
                outlier_coordinate_fraction=point['train_quantile_outliers']['coordinate_fraction'],
                outlier_target_fraction=point['train_quantile_outliers']['row_fraction'],
                boundary_coordinate_fraction=point['hard_clamp_boundary']['coordinate_fraction'])
            compact[arm] = metrics
            row = dict(stratum=regime, arm=arm, reference_targets=stratum['reference_count'],
                       audit_targets=stratum['audit_count'], **metrics)
            row.update({key: 0. if arm == 'clean_audit' else point['selected_modification'][key]
                        for key in ('l1_mean', 'l2_mean', 'linf_mean', 'l1_max', 'l2_max', 'linf_max')})
            rows.append(row)
        comparisons[regime] = {}
        for arm in ARMS:
            comparisons[regime][arm] = {}
            for comparator in ('clean_audit', 'continuation', 'unconditional'):
                delta = {key: compact[arm][key] - compact[comparator][key] for key in compact[arm]}
                comparisons[regime][arm]['versus_' + comparator] = dict(
                    deltas=delta, negative_delta_means_lower_discrepancy_or_rate=True,
                    all_three_distance_point_estimates_lower=all(delta[k] < -1e-12
                        for k in ('selected_mmd2', 'joint_mmd2', 'marginal_w1')),
                    statistical_significance_claim=False)
    return rows, comparisons


def run(path):
    path, plan = load_plan(path)
    output = path.parent
    assets.write_json(output / 'started.json', dict(plan=assets.asset(path), at=source.baseline.now()))
    state = source.state_writer(output)
    start = time.monotonic()
    state(stage='read_only_collection')
    try:
        with ExitStack() as stack:
            for optimizer in (torch.optim.Adam, torch.optim.AdamW, torch.optim.SGD):
                stack.enter_context(patch.object(optimizer, 'step', side_effect=RuntimeError('No optimization in diagnostic')))
            with torch.no_grad():
                data = collection.collect(plan, progress=state)
        state(stage='fixed_distribution_statistics')
        reference = statistics.fit_reference(data['train_selected'], data['train_conditions'], data['train_moving'])
        measured = statistics.evaluate(reference, data['audit_clean'], data['audit_conditions'],
                                       data['audit_moving'], data['triggered_by_arm'])
        old_review = source.audit_source.previous.checked_json(plan['source_review'])
        source_plan = source.audit_source.previous.checked_json(plan['source_plan'])
        for arm in ARMS:
            prior = source.audit_source.previous.checked_json(plan['source_reports'][arm])
            read_tables(prior['evaluation'], source_plan['parent']['roles']['audit'])
        arrays = {k: data[k] for k in ('train_selected', 'train_conditions', 'train_moving',
                                     'audit_clean', 'audit_conditions', 'audit_moving')}
        arrays.update({'triggered_' + arm: data['triggered_by_arm'][arm] for arm in ARMS})
        arrays['selected_coordinates'] = np.asarray(plan['selected_coordinates'], dtype=np.int64)
        arrays['condition_coordinates'] = np.asarray(plan['condition_coordinates'], dtype=np.int64)
        with (output / 'collected_features.npz').open('xb') as stream:
            np.savez_compressed(stream, **arrays)
        assets.write_json(output / 'reference.json', reference.to_metadata())
        assets.write_json(output / 'distribution_metrics.json', measured)
        metric_rows, comparisons = compact_report(measured)
        save_csv(output / 'comparison.csv', metric_rows)
        assets.write_json(output / 'comparisons.json', comparisons)
        assets.write_json(output / 'graph_access_ledger.json', data['ledger'])
        assets.write_json(output / 'integrity.json', data['integrity'])
        save_csv(output / 'reference_identity.csv', data['reference_rows'])
        save_csv(output / 'target_identity.csv', data['target_rows'])
        load_plan(path)
        summary = dict(status='DISTRIBUTION_AUDIT_COMPLETE_REVIEW_REQUIRED', at=source.baseline.now(),
            elapsed_seconds=time.monotonic()-start, plan=assets.asset(path),
            metrics=assets.asset(output / 'distribution_metrics.json'),
            comparisons=assets.asset(output / 'comparisons.json'), comparison_csv=assets.asset(output / 'comparison.csv'),
            reference=assets.asset(output / 'reference.json'), arrays=assets.asset(output / 'collected_features.npz'),
            ledger=assets.asset(output / 'graph_access_ledger.json'), integrity=assets.asset(output / 'integrity.json'),
            reference_identity=assets.asset(output / 'reference_identity.csv'),
            target_identity=assets.asset(output / 'target_identity.csv'),
            original_performance_review=plan['source_review'],
            user_revised_usability_view=usability_view(old_review),
            optimizer_steps=0, new_ASR_evaluation=False,
            original_val_arrays_loaded=False, original_test_arrays_loaded=False,
            independent_confirmation=False, physical_validity_claim=False,
            automatic_promotion=False, automatic_training=False)
        assets.write_json(output / 'summary.json', summary)
        state(status=summary['status'], stage='complete')
        return summary
    except Exception as exc:
        if hasattr(exc, 'graph_access_ledger') and not (output / 'graph_access_ledger.json').exists():
            assets.write_json(output / 'graph_access_ledger.json', exc.graph_access_ledger)
        assets.write_json(output / 'failure.json', dict(error=str(exc), at=source.baseline.now(), automatic_retry=False))
        state(status='STOPPED_DISTRIBUTION_AUDIT_ERROR', error=str(exc))
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    command = commands.add_parser('prepare'); command.add_argument('--output-dir', required=True)
    for name in ('check', 'run'):
        command = commands.add_parser(name); command.add_argument('--plan', required=True)
    args = parser.parse_args()
    if args.command == 'prepare':
        print(prepare(args.output_dir))
    elif args.command == 'check':
        load_plan(args.plan); print('DISTRIBUTION_AUDIT_METADATA_PASS; no arrays/models/optimization')
    else:
        result = run(args.plan)
        print(json.dumps({k: result[k] for k in ('status', 'at', 'elapsed_seconds', 'metrics')}, indent=2))


if __name__ == '__main__':
    main()
