"""Diagnostic-only orchestration checks; no real model/graph deserialization."""
from contextlib import ExitStack
from copy import deepcopy
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import Mock, patch

import numpy as np
import torch

from experiments.spear_distribution_audit_v1 import workflow as w
from experiments.spear_distribution_audit_v1 import statistics as stats


def synthetic_data():
    rng = np.random.default_rng(123)
    train = rng.normal(size=(8, 24)).astype(np.float32)
    clean = train[:4].copy()
    return dict(train_selected=train, train_conditions=rng.normal(size=(8, 6)),
        train_moving=np.asarray([False, True] * 4), audit_clean=clean,
        audit_conditions=rng.normal(size=(4, 6)), audit_moving=np.asarray([False, True] * 2),
        triggered_by_arm={a: clean + i * .1 for i, a in enumerate(w.ARMS)},
        reference_rows=[dict(scenario_id=str(i), pair_index=0) for i in range(8)],
        target_rows=[dict(scenario_id=str(i), pair_index=0) for i in range(4)],
        ledger=[], integrity=dict(synthetic=True, optimizer_steps=0))


def old_review():
    return dict(metrics={a: dict(victim=dict(targets=dict(
        all=dict(incremental_asr=.84), moving=dict(incremental_asr=.83)))) for a in w.ARMS},
        gates={a: dict(passed=False, checks=dict(overall_incremental_asr_at_least_85pct=False,
            moving_incremental_asr_at_least_85pct=False, original_auc_drop_at_most_0p005=True,
            adjacent_incremental_fp_strictly_below_5pct=True)) for a in w.ARMS})


class DistributionAuditWorkflowTests(unittest.TestCase):
    def test_new_namespace_only(self):
        for path in (w.ROOT, w.ROOT / 'record/v6', w.ROOT / 'record/v6_4',
                     w.SOURCE_PLAN.parent, w.ROOT / 'record/reproduction/spear_distribution_audit_v1'):
            with self.subTest(path=path), self.assertRaises(ValueError):
                w.output_path(path)
        p = w.ROOT / 'record/reproduction/spear_distribution_audit_v1/new'
        self.assertEqual(w.output_path(p), p)

    def test_existing_output_rejected_before_sources(self):
        with TemporaryDirectory() as tmp, patch.object(w, 'output_path', return_value=Path(tmp)), \
                patch.object(w, 'fields', side_effect=AssertionError('Cannot overwrite')) as fields:
            with self.assertRaises(FileExistsError):
                w.prepare(tmp)
            fields.assert_not_called()

    def test_fields_metadata_only_and_no_gate_rewrite(self):
        with patch.object(np, 'load', side_effect=AssertionError('No graph read')), \
                patch.object(torch, 'load', side_effect=AssertionError('No checkpoint read')):
            plan = w.fields()
        self.assertEqual(plan['arms'], list(w.ARMS))
        self.assertEqual(len(plan['selected_coordinates']), 24)
        self.assertEqual(plan['reference_population'], w.REFERENCE_POPULATION)
        self.assertFalse(set(plan['selected_coordinates']) & set(plan['condition_coordinates']))
        self.assertEqual(plan['contract']['expected_generator_forwards'], 672)
        for key in ('internal_dev_arrays_loaded', 'original_val_arrays_loaded', 'original_test_arrays_loaded',
                    'automatic_training', 'independent_confirmation'):
            self.assertFalse(plan['contract'][key])
        self.assertEqual(plan['contract']['prospective_usability']['overall_incremental_asr_min'], .8)

    def test_eighty_view_preserves_old_gate_and_normal_quality(self):
        original = old_review(); before = deepcopy(original)
        original['gates']['continuation']['checks']['original_auc_drop_at_most_0p005'] = False
        before = deepcopy(original)
        result = w.usability_view(original)
        self.assertEqual(original, before)
        self.assertFalse(result['continuation']['meets_user_revised_criteria'])
        self.assertTrue(result['conditional']['meets_user_revised_criteria'])
        self.assertFalse(result['conditional']['original85_gate']['passed'])
        original['metrics']['conditional']['victim']['targets']['moving']['incremental_asr'] = .79
        self.assertFalse(w.usability_view(original)['conditional']['meets_user_revised_criteria'])

    def test_compact_report_includes_clean_baseline_all_strata_and_directions(self):
        data = synthetic_data()
        reference = stats.fit_reference(data['train_selected'], data['train_conditions'], data['train_moving'])
        result = stats.evaluate(reference, data['audit_clean'], data['audit_conditions'],
                                data['audit_moving'], data['triggered_by_arm'])
        rows, comparisons = w.compact_report(result)
        self.assertEqual(len(rows), 12)
        for row in rows:
            if row['arm'] == 'clean_audit':
                self.assertEqual(row['l1_mean'], 0)
        for regime in ('all', 'slow', 'moving'):
            self.assertTrue(all(x == 0 for x in comparisons[regime]['continuation']['versus_clean_audit']['deltas'].values()))
            self.assertFalse(comparisons[regime]['continuation']['versus_clean_audit']['statistical_significance_claim'])

    def test_collection_failure_preserves_error_no_metrics_or_fit(self):
        with TemporaryDirectory() as tmp, ExitStack() as stack:
            path = Path(tmp) / 'plan.json'
            w.assets.write_json(path, dict(synthetic=True))
            stack.enter_context(patch.object(w, 'load_plan', return_value=(path, {})))
            stack.enter_context(patch.object(w.collection, 'collect', side_effect=ValueError('budget mismatch')))
            fit = stack.enter_context(patch.object(w.statistics, 'fit_reference', side_effect=AssertionError('Premature fit')))
            with self.assertRaisesRegex(ValueError, 'budget mismatch'):
                w.run(path)
            fit.assert_not_called()
            self.assertFalse((path.parent / 'summary.json').exists())
            self.assertEqual(json.loads((path.parent / 'failure.json').read_text())['error'], 'budget mismatch')

    def test_optimizer_step_is_disabled_during_collection(self):
        def bad_collect(*args, **kwargs):
            parameter = torch.nn.Parameter(torch.ones(1))
            torch.optim.Adam([parameter]).step()
        with TemporaryDirectory() as tmp, ExitStack() as stack:
            path = Path(tmp) / 'plan.json'; w.assets.write_json(path, {})
            stack.enter_context(patch.object(w, 'load_plan', return_value=(path, {})))
            stack.enter_context(patch.object(w.collection, 'collect', side_effect=bad_collect))
            with self.assertRaisesRegex(RuntimeError, 'No optimization'):
                w.run(path)

    def test_full_synthetic_no_update_pipeline_serializes_and_retains_results(self):
        with TemporaryDirectory() as tmp, ExitStack() as stack:
            path = Path(tmp) / 'plan.json'
            plan = dict(source_review={'name': 'review'}, source_plan={'name': 'plan'},
                        source_reports={a: {'name': a} for a in w.ARMS},
                        selected_coordinates=list(range(24)), condition_coordinates=list(range(30, 36)))
            w.assets.write_json(path, plan)
            data = synthetic_data(); review = old_review()
            def checked(ref):
                if ref['name'] == 'review': return review
                if ref['name'] == 'plan': return dict(parent=dict(roles=dict(audit=[])))
                return dict(evaluation=dict(synthetic=True))
            stack.enter_context(patch.object(w, 'load_plan', return_value=(path, plan)))
            stack.enter_context(patch.object(w.collection, 'collect', return_value=data))
            stack.enter_context(patch.object(w.source.audit_source.previous, 'checked_json', side_effect=checked))
            recompute = stack.enter_context(patch.object(w, 'read_tables'))
            result = w.run(path)
            self.assertEqual(result['status'], 'DISTRIBUTION_AUDIT_COMPLETE_REVIEW_REQUIRED')
            self.assertEqual(result['optimizer_steps'], 0)
            self.assertFalse(result['new_ASR_evaluation'])
            self.assertEqual(recompute.call_count, 3)
            for name in ('reference.json', 'distribution_metrics.json', 'collected_features.npz',
                         'comparison.csv', 'comparisons.json', 'summary.json'):
                self.assertTrue((path.parent / name).exists(), name)
            self.assertFalse((path.parent / 'failure.json').exists())


if __name__ == '__main__':
    unittest.main()
