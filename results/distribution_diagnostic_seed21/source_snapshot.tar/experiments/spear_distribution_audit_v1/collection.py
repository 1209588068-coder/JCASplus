"""Read-only distribution replay on the registered original TRAIN roles.

The clean reference uses one eligible negative per training-role scene, selected
with the original audit identity hash. Frozen generators are used only on the
unchanged audit targets. No classifier evaluation, fitting, or file writes live
here; the caller owns the new output namespace and reporting.
"""
from __future__ import annotations

from copy import deepcopy
import csv
import hashlib
from pathlib import Path

import numpy as np
import torch

from experiments.spear_content_attention_v1.workflow import SceneInjector
from experiments.spear_distribution_training_v1 import fitting as source_fitting
from experiments.spear_distribution_training_v1.distribution import CONDITION_COORDINATES
from experiments.spear_domain_training_v1.module import DomainConstrainedGenerator
from experiments.spear_pair_role_generator_v1.training import _state_hash, _tensor_hash
from experiments.spear_semantic_support_v1.module import modification_statistics
from experiments.spear_semantic_support_v1.schema import SELECTED_COORDINATES
from experiments.spear_semantic_support_v1.training import state_sha256
from experiments.spear_supplied_v1.evaluation import _component


ROOT, assets, baseline, previous = (source_fitting.ROOT, source_fitting.assets,
                                   source_fitting.baseline, source_fitting.previous)
ARMS = source_fitting.ARMS
REFERENCE_POPULATION = 'train_one_eligible_negative_per_scene_by_original_audit_hash'
IDENTITY_FIELDS = ('scenario_id', 'split_group_id', 'pair_index', 'src_track_id',
                   'dst_track_id', 'true_label', 'motion_regime')


def _same_asset(left, right):
    return (Path(left['path']).resolve() == Path(right['path']).resolve()
            and left['sha256'] == right['sha256'])


def _normalizer_hashes(normalizer):
    """Hash numeric arrays and the frozen NPZ string metadata without coercion."""
    result = {}
    for key, value in normalizer.items():
        array = np.asarray(value)
        if array.dtype.hasobject:
            raise ValueError('Normalizer metadata must not contain object/pickle arrays')
        digest = hashlib.sha256()
        digest.update(str((str(array.dtype), array.shape)).encode())
        digest.update(array.tobytes(order='C'))
        result[key] = digest.hexdigest()
    return result


def _identity(record):
    try:
        result = {key: str(record[key]) for key in IDENTITY_FIELDS}
        result['pair_index'] = int(record['pair_index'])
        result['true_label'] = int(record['true_label'])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError('Malformed registered target identity') from exc
    if (result['pair_index'] < 0 or result['true_label'] != 0
            or result['motion_regime'] not in ('slow', 'moving')
            or any(not result[key] for key in ('scenario_id', 'split_group_id', 'src_track_id', 'dst_track_id'))):
        raise ValueError('Invalid eligible-negative target identity or motion stratum')
    return result


def read_target_rows(reference):
    """Read identity columns only; prediction values never affect collection."""
    with assets.checked_asset({key: reference[key] for key in ('path', 'sha256')}).open(newline='') as stream:
        rows = [_identity(row) for row in csv.DictReader(stream)]
    scenes = [row['scenario_id'] for row in rows]
    if (len(rows) != 224 or len(set(scenes)) != len(rows)
            or sum(row['motion_regime'] == 'moving' for row in rows) != 60):
        raise ValueError('Require the original ordered 224 audit targets, including 60 moving')
    return rows


def select_target(part, row, seed):
    """Exact original hash selection before any generator/model is queried."""
    if part.get('scenario_id') != row['scenario_id'] or part.get('split') != 'train':
        raise ValueError('Observed scene identity or original TRAIN split changed')
    features, edges, truth, eligible, ids, motion = _component(part)
    candidates = np.flatnonzero(eligible & (truth == 0))
    target = min(candidates, key=lambda index: hashlib.sha256(
        f"{seed}:spear-audit-target:{row['scenario_id']}:{':'.join(ids[index])}".encode()
    ).hexdigest()) if len(candidates) else None
    identity = None if target is None else dict(scenario_id=row['scenario_id'],
        split_group_id=row['split_group_id'], pair_index=int(target), src_track_id=str(ids[target, 0]),
        dst_track_id=str(ids[target, 1]), true_label=0, motion_regime='moving' if motion[target] else 'slow')
    return features, edges, target, identity


def collect_reference(parts, rows, selected, seed):
    """One clean negative per scene, without replacement or trigger generation."""
    if len(parts) != len(rows):
        raise ValueError('Training reference parts and registered rows do not align')
    values, conditions, identities, empty = [], [], [], []
    for part, row in zip(parts, rows):
        if row.get('role') != 'train' or row.get('split') != 'train':
            raise ValueError('Reference only accepts registered original TRAIN training-role rows')
        before = baseline.field.part_digest(part)
        features, _, target, identity = select_target(part, row, seed)
        if target is None:
            empty.append(row['scenario_id'])
        else:
            values.append(features[target, selected].numpy().copy())
            conditions.append(features[target, list(CONDITION_COORDINATES)].numpy().copy())
            identities.append(identity)
        if baseline.field.part_digest(part) != before:
            raise ValueError('Reference extraction changed original clean scene inputs')
    if not identities:
        raise ValueError('Clean training reference has no eligible negative targets')
    return dict(train_selected=np.stack(values), train_conditions=np.stack(conditions),
        train_moving=np.array([row['motion_regime'] == 'moving' for row in identities], dtype=bool),
        reference_rows=identities, reference_scenes_without_target=empty)


def _assert_frozen(generator, support):
    if (not isinstance(generator, DomainConstrainedGenerator)
            or generator.output_mode != 'domain_projection'
            or generator.hard_support.tolist() != support
            or tuple(generator.selected_coordinates.tolist()) != SELECTED_COORDINATES):
        raise ValueError('Frozen projected generator/support contract changed')
    generator.assert_contract()
    if (any(module.training for module in generator.modules())
            or any(parameter.requires_grad or parameter.grad is not None for parameter in generator.parameters())):
        raise ValueError('Distribution audit requires frozen/eval/gradient-free generators')


def restore_generators(source, reports, training, barrier):
    """Restore original SAGE bases, completed projected anchor, then each arm.

    Only the generator-internal frozen shadow is needed. No victim, optimized
    surrogate, discriminator or evaluation clean-reference checkpoint is loaded.
    """
    role = previous.checked_json(source['parent']['references']['role_plan'])
    with torch.random.fork_rng(devices=[]):
        _, _, legacy, models, coordinates, normalizer = baseline.prior.restore(role, evaluation_models=False)
        if models:
            raise ValueError('Read-only generator restore unexpectedly loaded evaluation models')
        anchor = baseline.accepted.new_model(baseline.prior.new_generator(legacy, coordinates, 'untyped'), 'uniform')
        support = torch.tensor(source['hard_support'], dtype=torch.bool)
        projected = source_fitting.restore_projected_reference(anchor, support, source['references'])
        generators = {}
        for arm in ARMS:
            generator = deepcopy(projected)
            generator.load_state_dict(torch.load(assets.checked_asset(training[arm]['generator']),
                                                 map_location='cpu', weights_only=True), strict=True)
            generator.zero_grad(set_to_none=True)
            generator.eval().requires_grad_(False)
            _assert_frozen(generator, source['hard_support'])
            if (state_sha256(generator) != reports[arm]['unchanged_model_hashes']['generator']
                    or _state_hash(generator) != barrier['final_model_hashes'][arm]['generator']):
                raise ValueError('Restored generator differs from completed training/audit checkpoint hashes')
            generators[arm] = generator
    return generators, normalizer, coordinates, role


def replay_target(part, row, target, identity, generators, selected, selection_seed, context_seed):
    """Replay one target from clean inputs independently for every frozen arm."""
    features, edges, actual_target, actual_identity = select_target(part, row, selection_seed)
    if actual_target != target or actual_identity != identity:
        raise ValueError('Replay target differs from the independently selected clean identity')
    before = baseline.field.part_digest(part)
    x_hash, edges_hash = _tensor_hash(features), _tensor_hash(edges)
    weights = torch.ones(edges.shape[1], dtype=features.dtype)
    targets = torch.tensor([target], dtype=torch.long)
    outputs, budgets = {}, {}
    for arm in ARMS:
        generator = generators[arm]
        _assert_frozen(generator, generator.hard_support.tolist())
        model_before = state_sha256(generator)
        injector = SceneInjector(generator, context_seed)
        injector.bind(dict(part, x=part['x'].copy()))
        with torch.no_grad():
            changed, changed_edges, changed_weights = injector.inject_trigger(
                targets, features.clone(), edges.clone(), weights.clone(), torch.device('cpu'))
        if (not torch.equal(changed_edges, edges) or not torch.equal(changed_weights, weights)
                or changed.requires_grad):
            raise ValueError('Read-only replay changed topology/weights or retained a gradient graph')
        source_fitting.assert_output_scope(features, changed, targets, generator)
        budget = modification_statistics(features, changed, targets, generator.hard_support)
        selected_values = changed[target, selected]
        outside = int((selected_values.abs() > 10).sum())
        budgets[arm] = dict(scenario_id=row['scenario_id'], pair_index=int(target),
            motion_regime=identity['motion_regime'], coordinates_outside_domain=outside, **budget)
        if not torch.equal(changed[:, list(CONDITION_COORDINATES)], features[:, list(CONDITION_COORDINATES)]):
            raise ValueError('Frozen original observed conditions changed during replay')
        outputs[arm] = selected_values.numpy().copy()
        _assert_frozen(generator, generator.hard_support.tolist())
        if (model_before != state_sha256(generator) or baseline.field.part_digest(part) != before
                or x_hash != _tensor_hash(features) or edges_hash != _tensor_hash(edges)):
            raise ValueError('Replay mutated its frozen model or original inputs')
    return outputs, budgets


def _source_evidence(plan):
    """Validate completed metadata and identity evidence before graph access."""
    if (plan['reference_population'] != REFERENCE_POPULATION
            or plan['execution']['device'] != 'cpu' or plan['execution']['torch_threads'] != 2):
        raise ValueError('Wrong clean reference population or CPU resource contract')
    source = previous.checked_json(plan['source_plan'])
    complete = previous.checked_json(plan['source_completion'])
    barrier = previous.checked_json(plan['source_optimization_complete'])
    if (tuple(source['arms']) != ARMS or complete['status'] != 'DISTRIBUTION_TRAINING_COMPLETE_REVIEW_REQUIRED'
            or not _same_asset(complete['plan'], plan['source_plan'])
            or not _same_asset(complete['optimization_complete'], plan['source_optimization_complete'])
            or barrier['arms'] != list(ARMS) or barrier['steps'] != source_fitting.EXPECTED_STEPS
            or barrier['plan_sha256'] != source_fitting.canonical_hash(source)
            or barrier['hard_support'] != source['hard_support']
            or not _same_asset(plan['source_original_targets'], source['original_csvs']['raw_targets'])):
        raise ValueError('Source experiment completion, optimization evidence or support changed')
    parent = source['parent']
    baseline.prior.validate_roles(parent['roles'])
    if ({name: len(rows) for name, rows in parent['roles'].items()} != dict(train=512, dev=128, audit=256)
            or source['data_contract']['rows'] != parent['roles']['train']
            or source['distribution_config']['condition_coordinates'] != list(CONDITION_COORDINATES)):
        raise ValueError('Original TRAIN roles or condition provenance changed')
    reports, training, budgets = {}, {}, {}
    original = read_target_rows(plan['source_original_targets'])
    references = [plan[key] for key in ('source_plan', 'source_completion', 'source_optimization_complete', 'source_original_targets')]
    for arm in ARMS:
        reports[arm] = previous.checked_json(plan['source_reports'][arm])
        report = reports[arm]
        if (not _same_asset(complete['reports'][arm], plan['source_reports'][arm])
                or not _same_asset(report['training'], plan['source_training'][arm])
                or not _same_asset(barrier['training'][arm], plan['source_training'][arm])
                or not _same_asset(report['evaluation']['raw_targets'], plan['source_targets'][arm])
                or not _same_asset(report['budgets'], plan['source_budgets'][arm])):
            raise ValueError('Arm evidence differs from the completed source reports')
        training[arm] = previous.checked_json(plan['source_training'][arm])
        if training[arm]['arm'] != arm or read_target_rows(plan['source_targets'][arm]) != original:
            raise ValueError('Completed arm or ordered audit target identities differ')
        budgets[arm] = previous.checked_json(plan['source_budgets'][arm])
        if len(budgets[arm]) != len(original):
            raise ValueError('Completed arm budget evidence is incomplete')
        for identity, budget in zip(original, budgets[arm]):
            if any(budget[key] != identity[key] for key in ('scenario_id', 'pair_index', 'motion_regime')):
                raise ValueError('Completed budget evidence has different target order/identity')
        references.extend(plan[key][arm] for key in ('source_reports', 'source_training', 'source_targets', 'source_budgets'))
        references.append(training[arm]['generator'])
    return source, barrier, reports, training, original, budgets, references


def _check_ledger(ledger, parent):
    rows = [*parent['roles']['train'], *parent['roles']['audit']]
    if len(ledger) != 768:
        raise ValueError('Incomplete train512 plus audit256 graph access ledger')
    for item, row in zip(ledger, rows):
        if (row['role'] not in ('train', 'audit') or row['split'] != 'train'
                or item['role'] != row['role'] or item['split'] != 'train'
                or item['scenario_id'] != row['scenario_id'] or item['status'] != 'READ_COMPLETE'
                or item['sha256'] != row['graph_sha256']
                or Path(item['path']) != (Path(parent['graph_dir']) / row['graph_path']).resolve()):
            raise ValueError('Graph access escaped the exact original TRAIN reference/audit roles')


def _collect(plan, progress, ledger, forward_counts, handles):
    source, barrier, reports, training, expected, source_budgets, references = _source_evidence(plan)
    parent = source['parent']
    state = progress if progress is not None else lambda **_: None
    if not callable(state):
        raise ValueError('progress must be callable or None')
    torch.set_num_threads(2)
    rng = torch.random.get_rng_state().clone()
    state(stage='restore_frozen_generators')
    generators, normalizer, coordinates, role = restore_generators(source, reports, training, barrier)

    def counted_forward(arm):
        def observe(model, _inputs):
            _assert_frozen(model, source['hard_support'])
            forward_counts[arm] += 1
        return observe

    for arm, generator in generators.items():
        handles.append(generator.register_forward_pre_hook(counted_forward(arm)))
    selected = generators[ARMS[0]].selected_coordinates[generators[ARMS[0]].hard_support]
    if len(selected) != 24 or bool(torch.isin(selected, selected.new_tensor(CONDITION_COORDINATES)).any()):
        raise ValueError('Require the unchanged editable24 and six disjoint observed conditions')
    hashes = {arm: state_sha256(generator) for arm, generator in generators.items()}
    normalizer_hashes = _normalizer_hashes(normalizer)
    references.extend(source['references'][key] for key in ('sage_generator', 'generator'))
    references.append(parent['references']['role_plan'])
    references.extend(role['references'][key] for key in ('generator', 'shadow', 'feature_importance', 'normalizer'))
    state(stage='load_clean_training_reference', scenes=512)
    parts, _, train, idx, context = previous.load_train(source, normalizer, ledger)
    original_contract = previous.checked_json(parent['references']['input_contract'])
    outer = source_fitting.check_outer(train, idx, original_contract, coordinates, parent['seed'])
    train_digest = previous.input_digest(parts, train, context, outer)
    reference = collect_reference(parts, parent['roles']['train'], selected, parent['seed'])
    if any(forward_counts.values()):
        raise ValueError('Clean training reference collection unexpectedly invoked a generator')
    state(stage='clean_training_reference_complete', targets=len(reference['reference_rows']),
          moving=int(reference['train_moving'].sum()), audit_arrays_loaded=False)
    audit_clean, audit_conditions, target_rows = [], [], []
    triggered, replayed_budgets = {arm: [] for arm in ARMS}, {arm: [] for arm in ARMS}
    audit_digests, no_target_scenes = {}, []
    for number, row in enumerate(parent['roles']['audit'], 1):
        part = baseline.field.read_audit_part(row, parent, normalizer, ledger)
        digest = baseline.field.part_digest(part)
        audit_digests[row['scenario_id']] = digest
        features, _, target, identity = select_target(part, row, parent['seed'])
        if target is None:
            no_target_scenes.append(row['scenario_id'])
        else:
            position = len(target_rows)
            if position >= len(expected) or identity != expected[position]:
                raise ValueError('Clean hash-selected audit target differs from the original ordered CSV')
            outputs, budgets = replay_target(part, row, target, identity, generators, selected,
                                             parent['seed'], parent['shuffle_seed'])
            for arm in ARMS:
                if budgets[arm] != source_budgets[arm][position]:
                    raise ValueError('Frozen output modification budget does not exactly replay source: ' + arm)
                triggered[arm].append(outputs[arm])
                replayed_budgets[arm].append(budgets[arm])
            audit_clean.append(features[target, selected].numpy().copy())
            audit_conditions.append(features[target, list(CONDITION_COORDINATES)].numpy().copy())
            target_rows.append(identity)
        if baseline.field.part_digest(part) != digest:
            raise ValueError('Audit collection changed the original clean scene')
        if number % 32 == 0 or number == 256:
            state(stage='replay_frozen_audit_targets', completed=number, total=256,
                  targets=len(target_rows), generator_forwards=len(target_rows) * len(ARMS))
    if target_rows != expected or len(no_target_scenes) != 32:
        raise ValueError('Incomplete original audit target/empty-scene replay')
    if forward_counts != {arm: 224 for arm in ARMS}:
        raise ValueError('Runtime generator-forward counts differ from the fixed three-arm audit replay')
    if train_digest != previous.input_digest(parts, train, context, outer):
        raise ValueError('Original training reference input bytes changed during collection')
    if normalizer_hashes != _normalizer_hashes(normalizer):
        raise ValueError('Frozen original normalizer changed during collection')
    for arm in ARMS:
        _assert_frozen(generators[arm], source['hard_support'])
        if state_sha256(generators[arm]) != hashes[arm]:
            raise ValueError('Frozen generator changed during collection')
    if not torch.equal(rng, torch.random.get_rng_state()):
        raise ValueError('Read-only collection consumed the caller CPU RNG stream')
    _check_ledger(ledger, parent)
    for ref in references:
        assets.checked_asset({key: ref[key] for key in ('path', 'sha256')})
    result = dict(reference, audit_clean=np.stack(audit_clean), audit_conditions=np.stack(audit_conditions),
        audit_moving=np.array([row['motion_regime'] == 'moving' for row in target_rows], dtype=bool),
        target_rows=target_rows, triggered_by_arm={arm: np.stack(values) for arm, values in triggered.items()},
        ledger=ledger, integrity=dict(status='READ_ONLY_COLLECTION_PASS', optimizer_steps=0, victim_forwards=0,
            training_forwards=0, train_reference_generator_forwards=0,
            generator_forwards=sum(forward_counts.values()), generator_forwards_per_arm=dict(forward_counts),
            call_count_method='generator_top_level_forward_pre_hook; every call checked frozen/eval',
            source_target_order_exact=True, source_budget_replay_exact=True, source_model_hashes=hashes,
            unchanged_model_hashes=hashes, unchanged_train_input_digest=train_digest,
            unchanged_audit_input_digests=audit_digests, unchanged_normalizer_hashes=normalizer_hashes,
            unchanged_cpu_rng=True, selected_coordinates=selected.tolist(), condition_coordinates=list(CONDITION_COORDINATES),
            reference_population=REFERENCE_POPULATION, reference_targets=len(reference['reference_rows']),
            reference_moving=int(reference['train_moving'].sum()), audit_targets=224, audit_moving=60, audit_slow=164,
            audit_scenes_without_target=no_target_scenes, budget_replay_counts={arm: len(rows) for arm, rows in replayed_budgets.items()},
            original_source_split='train', train_scenes_loaded=512, audit_scenes_loaded=256,
            internal_dev_arrays_loaded=False, original_val_arrays_loaded=False, original_test_arrays_loaded=False,
            real_reference_uses_predictions=False, train_reference_triggers_generated=False,
            condition_source='original_clean_observed_standardized_features',
            future_members_used_only_for_unchanged_labels=True))
    for key in ('train_selected', 'train_conditions', 'train_moving', 'audit_clean', 'audit_conditions', 'audit_moving'):
        result[key].setflags(write=False)
    for value in result['triggered_by_arm'].values():
        value.setflags(write=False)
    return result


def collect(plan, progress=None):
    """Return collected values without writes; failures carry the access ledger."""
    ledger, handles = [], []
    forward_counts = {arm: 0 for arm in ARMS}
    try:
        return _collect(plan, progress, ledger, forward_counts, handles)
    except Exception as exc:
        exc.graph_access_ledger = deepcopy(ledger)
        raise
    finally:
        for handle in handles:
            handle.remove()
