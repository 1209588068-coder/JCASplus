"""Frozen-checkpoint feature-distribution diagnostics; no optimization."""
