# 训练侧等平均 L1 的简单幅度对照

## 范围与问题

仅本地 AV2 / 自有 GNN 离线研究。本轮是对当前 unconditional 候选的开发对照，
不是新攻击模块或独立盲测。保留全部旧代码、结果、图资产、grouped-v5、v6.0 和
v6.4-S；不读取原 validation/test 数组。

问题：已有分布约束的收益，能否由无分布约束生成器的一次简单统一缩幅替代？
这个实验检验简单替代解释，不宣称仅凭一次对照证明新颖性或完整因果机制。

## 唯一变化

对固定三个 seed 20260621/22/23，恢复同 seed 已完成的 continuation (C) 和
unconditional (U) 生成器，均不更新。仅在原 TRAIN 的26个实际投毒 pair 上，
用原干净输入和原图上下文重算24维修改量：

```
s = mean_attachment_L1(U(x) - x) / mean_attachment_L1(C(x) - x)
scaled(x) = x + s * (C(x) - x)
```

每 seed 只有一个 s，直接由此公式确定，不搜索、不看 dev/audit 预测选比例。
仅接受有限 0<s<=1；若无法通过缩小匹配则停止，不截断成有效值。
float64 计算后恢复输入 dtype；匹配容限 abs=1e-5、rel=1e-5。
因为原 clean 和 C 已在[-10,10]，凸组合自动留域，不额外裁剪。
其余760维、非目标行、节点、边、边权及原始轨迹均保持不变。

U 参与训练幅度标定，因此 scaled 是以 U 为参考的诊断对照，不是从未借助 U 的
独立廉价训练算法。也不是在 U 的学习方向上继续微调。
只匹配26个训练 attachments 的平均 L1：不匹配逐目标、outer538、audit224、
Slow/Moving、L2、Linf 或分布距离。全部实际修改统计另行报告。

## 相同条件与新增预算

- 复用已完成 C/U 的生成器训练结果；不重新训练生成器、surrogate、D 或干净代理。
- 同一24维支持、26个投毒身份、1902个监督训练行、normalizer 和 labels。
- 每 seed 新初始化一个 GraphSAGE，用缩幅后的26行训练200 epochs。
- 初始权重和 fit dropout RNG 必须逐项匹配同 seed 旧 C/U 记录。
- 检查点仍取正常 internal-dev AUC 最优，精确并列时取最早；不按 ASR 选点。
- 三 seed 新增总计600 victim epochs；CPU2线程顺序运行，CUDA隐藏。
- 先完成全部三组标定和训练，核验完成屏障，才读取原 TRAIN 内 audit256。
- 固定原 TRAIN 的 train512/dev128/audit256；评估公共目标224个，其中Moving60。
- 旧 C/U 模型、预测与分布数组经 SHA/身份核验后复用，不追加其训练。

这三个 C checkpoint 实际字节相同。三个结果仅反映固定 C 起点、不同 U 标定值与
victim 随机性，不是三个独立完整方法复现。旧 C/U 结果已曝光；新增对照事先固定，
但整个比较依然是事后提出的开发分析。

## 评价与停止

沿用整体/Moving Incremental ASR>=80%、Adjacent incremental FP<5%、正常AUC
下降<=0.005、正类召回下降<=0.05、不得全负塌缩。正常质量同时对照原SAGE24和
同seed C。门槛是是否保留候选的参考，不是机制显著性或新颖性门槛。

输出全部结果、样本SD与同seed配对差；不能删除失败seed或合并重复224目标作为
672个独立样本。报告原 clean reference 的触发响应；它已用于开发，不是盲模型。
分布统计复用原447个训练参考、原尺度、原带宽和分位数，按all/slow/moving报告
W1、MMD²、分位外率、边界率及L1/L2/Linf。不能把分布距离改善称为物理有效。

数值、范围、输入对齐、源码/资产哈希、初始化、训练计数或结果完整性错误立即停止，
保留错误记录，不自动重跑。性能不佳仍完成并报告三个事先注册seed，不自动扫参、
新增模块、替换主方法或访问正式holdout。

代码：`experiments/spear_amplitude_control_v1/`。
输出：`record/reproduction/spear_amplitude_control_v1/` 的全新子目录。
本说明是运行前合同；是否已启动/完成以对应 `launcher.json/state.json/summary.json`
为准，文档存在不表示实验已经完成。
