"""Paired two-seed continuation; historical plans/checkpoints remain immutable.

This deliberately isolates orchestration from the completed single-seed runner.
Its low-level objectives, fixed graph populations and optimization budgets are
reused unchanged. No audit access is allowed before the three-arm barrier.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch

from experiments.spear_distribution_training_v1 import fitting as source
from experiments.spear_distribution_training_v1.training import fit_distribution_residual
from experiments.spear_distribution_audit_v1.collection import collect_reference, REFERENCE_POPULATION
from experiments.spear_pair_role_generator_v1.training import ResidualTrainingConfig, _tensor_hash
from experiments.spear_semantic_support_v1.module import modification_statistics
from experiments.spear_dual_clean_proxy_v1.module import FrozenMeanCleanResponsePenalty
from experiments.spear_supplied_v1.data import transform_features
from experiments.spear_vehicle_consistency_v1.runner import read_part as read_role_part
from .seeded import (SeededDistributionRegularizer, replication_seeds, fit_victim,
                     victim_initialization_contract)

ROOT, assets, baseline, previous = source.ROOT, source.assets, source.baseline, source.previous
ARMS, EXPECTED_STEPS, DISTRIBUTION_CONFIG = source.ARMS, source.EXPECTED_STEPS, source.DISTRIBUTION_CONFIG
canonical_hash, state_sha256 = source.canonical_hash, source.state_sha256
check_outer, assert_output_scope = source.check_outer, source.assert_output_scope
restore_projected_reference, new_generator = source.restore_projected_reference, source.new_generator
gradient_smoke, _check_training_result = source.gradient_smoke, source._check_training_result


def output_path(path):
    path = Path(path).resolve()
    root = ROOT / 'record/reproduction/spear_distribution_replication_v1'
    if path.name != 'training' or path.parent == root or not path.is_relative_to(root):
        raise ValueError('Require a new replication run child / training directory')
    return path


def validate_replication_plan(plan):
    seeds = replication_seeds(plan['replicate_seed'])
    if (plan['replication_seeds'] != seeds or plan['training_seed'] != 20263621
            or plan['distribution_config'] != DISTRIBUTION_CONFIG
            or plan['parent']['seed'] != 20260621 or plan['parent']['shuffle_seed'] != 20260621
            or plan['parent']['training_seed'] != 20263621):
        raise ValueError('Historical target/data seeds or explicit replication seeds changed')
    return seeds


def effective_distribution_config(plan):
    return dict(plan['distribution_config'], seed=replication_seeds(plan['replicate_seed'])['discriminator'])


def continuation_rng_digest(seed):
    with torch.random.fork_rng(devices=[]):
        torch.random.default_generator.manual_seed(seed)
        return _tensor_hash(torch.random.get_rng_state())


def distribution_reference_signature(reference):
    result = {key: _tensor_hash(torch.from_numpy(reference[key].copy()))
              for key in ('train_selected', 'train_conditions', 'train_moving')}
    result.update(reference_rows=canonical_hash(reference['reference_rows']),
                  reference_scenes_without_target=canonical_hash(reference['reference_scenes_without_target']))
    return result


def new_distribution(arm, train, outer, generator, plan):
    seeds = validate_replication_plan(plan)
    config = effective_distribution_config(plan)
    coordinates = generator.selected_coordinates[generator.hard_support]
    if bool(torch.isin(coordinates, coordinates.new_tensor(config['condition_coordinates'])).any()):
        raise ValueError('Condition coordinates overlap the fixed modifiable support')
    return SeededDistributionRegularizer(arm, train['x'], target_indices=outer,
        selected_coordinates=coordinates, **{key: config[key] for key in ('lr', 'weight_decay', 'weight', 'seed')},
        provenance=dict(split='train', role='train', scene_count=512,
            purpose='distribution_regularizer', population='original538_outer',
            clean_features='original_observed_standardized_clean_features',
            real_reference='same_outer_target_rows', plan_sha256=canonical_hash(plan),
            replicate_seed=plan['replicate_seed'], replication_seeds=seeds,
            internal_dev_arrays_used=False, internal_audit_arrays_used=False))


def fit_arms(output_dir, plan, progress=None):
    """Fit all registered arms and seal a barrier before any audit access."""
    if (tuple(plan['arms']) != ARMS or plan['training_config'] != asdict(ResidualTrainingConfig())
            or plan['distribution_config'] != DISTRIBUTION_CONFIG
            or plan['execution']['device'] != 'cpu' or plan['execution']['torch_threads'] != 2):
        raise ValueError('Wrong arms, fixed optimization budgets or CPU resource contract')
    seeds = validate_replication_plan(plan)
    parent = plan['parent']
    baseline.prior.validate_roles(parent['roles'])
    if ({name: len(rows) for name, rows in parent['roles'].items()} != dict(train=512, dev=128, audit=256)
            or parent['victim_epochs'] != 200 or plan['training_seed'] != parent['training_seed']):
        raise ValueError('Original roles, victim budget or training seed changed')
    folder = output_path(output_dir)
    folder.mkdir(parents=True, exist_ok=False)
    ledger, trained, discriminators, training_refs, final_hashes = [], {}, {}, {}, {}
    state = progress if progress is not None else lambda **_: None
    torch.set_num_threads(2)
    expected_continuation_rng = continuation_rng_digest(seeds['continuation'])
    try:
        state(stage='loading_registered_train_dev')
        role = previous.checked_json(parent['references']['role_plan'])
        api, args, legacy, _, coordinates, normalizer = baseline.prior.restore(role, evaluation_models=False)
        anchor = baseline.accepted.new_model(baseline.prior.new_generator(legacy, coordinates, 'untyped'), 'uniform')
        support = torch.tensor(plan['hard_support'], dtype=torch.bool)
        reference = restore_projected_reference(anchor, support, plan['references'])
        surrogate = deepcopy(legacy.shadow_model)
        surrogate.load_state_dict(torch.load(assets.checked_asset(plan['references']['surrogate']),
                                            map_location='cpu', weights_only=True), strict=True)
        surrogate.eval().requires_grad_(False)
        frozen_sources = dict(reference=state_sha256(reference), surrogate=state_sha256(surrogate))
        parts, _, train, idx, context = previous.load_train(plan, normalizer, ledger)
        expected = previous.checked_json(parent['references']['input_contract'])
        outer = check_outer(train, idx, expected, coordinates, parent['seed'])
        # Freeze the clean TRAIN-only diagnostic reference before dev reads or
        # any no-update smoke/training. Selection is independent of replicate RNG.
        distribution_reference = collect_reference(parts, parent['roles']['train'],
            reference.selected_coordinates[support].tolist(), parent['seed'])
        reference_signature = distribution_reference_signature(distribution_reference)
        distribution_reference['provenance'] = dict(
            population=REFERENCE_POPULATION, target_seed=parent['seed'], scene_count=512,
            selected_coordinates=reference.selected_coordinates[support].tolist(),
            condition_coordinates=plan['distribution_config']['condition_coordinates'],
            array_and_identity_hashes=reference_signature, fixed_before_optimization=True,
            internal_audit_arrays_used=False)
        for key in ('train_selected', 'train_conditions', 'train_moving'):
            distribution_reference[key].setflags(write=False)
        dev_parts = []
        for number, row in enumerate(parent['roles']['dev'], 1):
            part = read_role_part(row, parent, allowed_role='dev', ledger=ledger)
            part['x'] = transform_features(part['x'], normalizer)
            dev_parts.append(part)
            if number % 32 == 0:
                state(stage='loading_registered_dev', completed=number, total=128)
        dev = baseline.checkpoint.combine(dev_parts)
        dev_inputs = {key: _tensor_hash(value) for key, value in dev.items() if isinstance(value, torch.Tensor)}
        train_before = previous.input_digest(parts, train, context, outer)
        victim_initial = victim_initialization_contract(api, args, train, dev, seeds['victim'])
        stub, proxies = SimpleNamespace(x=train['x'], y=train['y']), []
        for key in ('proxy1', 'proxy2'):
            proxy = api['model_construct'](args, 'GraphSage', stub, torch.device('cpu'))
            proxy.load_state_dict(torch.load(assets.checked_asset(parent['references'][key]),
                                            map_location='cpu', weights_only=True), strict=True)
            proxy.eval().requires_grad_(False)
            quality = baseline.prior.parent.dual.dev_quality(proxy, dev, folder / (key + '_dev_scores.csv'))
            if quality['gate'] != 'PASS_PROXY_QUALITY':
                raise ValueError('Frozen original proxy failed its existing minimum quality check')
            proxies.append(proxy)
        config = ResidualTrainingConfig(**plan['training_config'])
        fairness_common = discriminator_initial = replay_common = None
        initial_common = state_sha256(reference)
        totals = {key: 0 for key in EXPECTED_STEPS}
        initialized = {}
        for arm in ARMS:
            arm_dir = folder / arm
            arm_dir.mkdir(exist_ok=False)
            generator = new_generator(reference)
            np.random.seed(seeds['continuation'])
            torch.manual_seed(seeds['continuation'])
            smoke_distribution = new_distribution(arm, train, outer, generator, plan)
            d_initial = state_sha256(smoke_distribution.discriminator)
            if discriminator_initial is None:
                discriminator_initial = d_initial
            elif discriminator_initial != d_initial:
                raise ValueError('Arms differ in initial discriminator weights')
            state(stage='no_update_gradient_smoke', arm=arm, optimization_started=False)
            smoke = gradient_smoke(generator, reference, surrogate, proxies, train, context, idx,
                                   outer, config, smoke_distribution)
            if replay_common is None:
                replay_common = smoke['projected_outer_output_sha256']
            elif replay_common != smoke['projected_outer_output_sha256']:
                raise ValueError('Arms differ in no-update projected output replay')
            assets.write_json(arm_dir / 'smoke.json', smoke)
            initialized[arm] = generator
        preflight = dict(status='ALL_ARMS_NO_UPDATE_SMOKE_PASS', arms=list(ARMS), optimizer_steps=0,
            initial_generator_sha256=initial_common, initial_surrogate_sha256=frozen_sources['surrogate'],
            initial_discriminator_sha256=discriminator_initial, projected_outer_output_sha256=replay_common,
            smoke={arm: assets.asset(folder / arm / 'smoke.json') for arm in ARMS},
            replicate_seed=plan['replicate_seed'], replication_seeds=seeds,
            shared_victim_initialization=victim_initial, expected_continuation_rng=expected_continuation_rng,
            distribution_reference=reference_signature)
        assets.write_json(folder / 'all_arms_preflight.json', preflight)
        for arm in ARMS:
            arm_dir, generator = folder / arm, initialized[arm]
            if state_sha256(generator) != initial_common:
                raise ValueError('Arm initialization changed after no-update preflight')
            weights = train['x'].new_ones(context.edge_index.shape[1])
            penalty = FrozenMeanCleanResponsePenalty(proxies, train['x'], context.edge_index, weights, weight=1.)
            distribution = new_distribution(arm, train, outer, generator, plan)
            if (distribution.steps != 0 or distribution.generator_calls != 0
                    or state_sha256(distribution.discriminator) != discriminator_initial):
                raise ValueError('Formal discriminator is not a fresh matched initialization')
            distribution_initial_snapshot = distribution.snapshot()
            np.random.seed(seeds['continuation'])
            torch.manual_seed(seeds['continuation'])

            def callback(record):
                generator.assert_contract()
                distribution.assert_contract()
                state(stage='fit_distribution_residual', arm=arm, arms_completed=len(trained), arms_total=3, **record)
                if record['epoch'] % 20 == 0 or record['epoch'] == 199:
                    print(f'[distribution-replication] {arm}: residual/surrogate {record["epoch"] + 1}/200', flush=True)
                generator.assert_contract()
                distribution.assert_contract()

            result = fit_distribution_residual(generator, surrogate, train['x'], context, train['y'],
                idx['idx_train'], idx['idx_attach'], outer, penalty, config, distribution, progress=callback)
            _check_training_result(result, arm, plan['training_config'], distribution)
            if penalty.calls != 200:
                raise ValueError('Actual dual-clean constraint exposure changed')
            signature = dict(input_sha256=result['input_sha256'], frozen=result['frozen_state_sha256'],
                initial_generator=result['initial_state_sha256']['generator'],
                initial_surrogate=result['initial_state_sha256']['surrogate'],
                initial_discriminator=result['distribution_initial_state_sha256'],
                rng=result['initial_cpu_rng_sha256'], config=result['config'])
            if (signature['initial_generator'] != initial_common
                    or signature['initial_surrogate'] != frozen_sources['surrogate']
                    or signature['initial_discriminator'] != discriminator_initial
                    or signature['rng'] != expected_continuation_rng):
                raise ValueError('Training did not begin from the completed projected sources and fresh discriminator')
            if fairness_common is None:
                fairness_common = signature
            elif fairness_common != signature:
                raise ValueError('Arms differ in inputs, proxies, model initialization or training RNG')
            px, py, pe, pw = (result[key] for key in ('poisoned_features', 'poisoned_labels', 'edge_index', 'edge_weight'))
            baseline.validate_poisoned_inputs(train, idx, coordinates.numpy(), px, pe, pw, py)
            assert_output_scope(train['x'], px, idx['idx_attach'], generator)
            budget = modification_statistics(train['x'], px, idx['idx_attach'], generator.hard_support)
            torch.save(generator.state_dict(), arm_dir / 'generator.pt')
            torch.save(result['surrogate'].state_dict(), arm_dir / 'surrogate.pt')
            torch.save(distribution.discriminator.state_dict(), arm_dir / 'discriminator.pt')
            distribution_final_snapshot = distribution.snapshot()
            torch.save(distribution_initial_snapshot, arm_dir / 'distribution_initial.pt')
            torch.save(distribution_final_snapshot, arm_dir / 'distribution_final.pt')
            distribution_record = dict(
                initial={key: value for key, value in distribution_initial_snapshot.items()
                         if key not in ('discriminator', 'optimizer')},
                final={key: value for key, value in distribution_final_snapshot.items()
                       if key not in ('discriminator', 'optimizer')},
                initial_checkpoint=assets.asset(arm_dir / 'distribution_initial.pt'),
                final_checkpoint=assets.asset(arm_dir / 'distribution_final.pt'),
                discriminator_steps=distribution.steps, generator_calls=distribution.generator_calls,
                initial_discriminator_sha256=discriminator_initial,
                final_discriminator_sha256=state_sha256(distribution.discriminator),
                config=plan['distribution_config'], actual_config=effective_distribution_config(plan),
                replicate_seed=plan['replicate_seed'], replication_seeds=seeds, arm=arm)
            assets.write_json(arm_dir / 'distribution_record.json', distribution_record)
            record = {key: value for key, value in result.items() if key not in (
                'generator', 'surrogate', 'poisoned_features', 'poisoned_labels', 'edge_index',
                'edge_weight', 'idx_train', 'idx_attach', 'fixed_outer')}
            record.update(dual_clean_history=penalty.history, initial_generator_sha256=initial_common,
                fixed_support=support.tolist(), output_mode='domain_projection', training_budget=budget,
                smoke=assets.asset(arm_dir / 'smoke.json'), distribution_record=assets.asset(arm_dir / 'distribution_record.json'),
                replicate_seed=plan['replicate_seed'], replication_seeds=seeds,
                actual_continuation_seed=seeds['continuation'])
            assets.write_json(arm_dir / 'generator_record.json', record)
            print(f'[distribution-replication] {arm}: fitting fresh victim for 200 epochs', flush=True)
            victim, victim_record = fit_victim(api, args, train, dev, idx, result, parent, arm_dir, state,
                victim_seed=seeds['victim'], expected=victim_initial)
            if (victim_record['trace']['training_forwards'] != 200 or victim_record['trace']['eval_forwards'] != 200):
                raise ValueError('Fresh victim did not complete 200 training/evaluation epochs')
            generator.zero_grad(set_to_none=True)
            generator.eval().requires_grad_(False)
            victim.zero_grad(set_to_none=True)
            distribution.assert_contract()
            victim_record.update(arm=arm, replicate_seed=plan['replicate_seed'], replication_seeds=seeds,
                generator=assets.asset(arm_dir / 'generator.pt'),
                surrogate=assets.asset(arm_dir / 'surrogate.pt'), discriminator=assets.asset(arm_dir / 'discriminator.pt'),
                distribution_record=assets.asset(arm_dir / 'distribution_record.json'),
                generator_record=assets.asset(arm_dir / 'generator_record.json'), smoke=assets.asset(arm_dir / 'smoke.json'))
            assets.write_json(arm_dir / 'training.json', victim_record)
            trained[arm], discriminators[arm] = (generator, victim), distribution.discriminator
            training_refs[arm] = assets.asset(arm_dir / 'training.json')
            final_hashes[arm] = dict(generator=state_sha256(generator), victim=state_sha256(victim),
                                     discriminator=state_sha256(distribution.discriminator))
            for key in ('residual', 'surrogate', 'victim_epochs'):
                totals[key] += 200
            totals['discriminator'] += distribution.steps
            if (reference_signature != distribution_reference_signature(distribution_reference)
                    or frozen_sources != dict(reference=state_sha256(reference), surrogate=state_sha256(surrogate))
                    or train_before != previous.input_digest(parts, train, context, outer)
                    or dev_inputs != {key: _tensor_hash(value) for key, value in dev.items() if isinstance(value, torch.Tensor)}):
                raise ValueError('Frozen caller checkpoints or training/development input bytes changed')
        if totals != EXPECTED_STEPS or tuple(trained) != ARMS:
            raise ValueError('Incomplete three-arm optimization matrix')
        if (len(ledger) != 640 or sum(row['role'] == 'train' for row in ledger) != 512
                or sum(row['role'] == 'dev' for row in ledger) != 128
                or any(row['split'] != 'train' or row['status'] != 'READ_COMPLETE' for row in ledger)):
            raise ValueError('Unexpected training/dev graph access ledger')
        assets.write_json(folder / 'train_dev_graph_access_ledger.json', ledger)
        barrier = dict(arms=list(ARMS), steps=totals, training=training_refs, final_model_hashes=final_hashes,
            hard_support=support.tolist(), shared_initial_state=initial_common, shared_fairness=fairness_common,
            shared_initial_discriminator=discriminator_initial, all_arms_preflight=assets.asset(folder / 'all_arms_preflight.json'),
            frozen_source_models=frozen_sources, plan_sha256=canonical_hash(plan), parent_sha256=canonical_hash(parent),
            train_dev_ledger=assets.asset(folder / 'train_dev_graph_access_ledger.json'),
            internal_audit_arrays_loaded=False, original_val_arrays_loaded=False, original_test_arrays_loaded=False,
            replicate_seed=plan['replicate_seed'], replication_seeds=seeds,
            shared_victim_initialization=victim_initial, expected_continuation_rng=expected_continuation_rng,
            distribution_reference=reference_signature, at=baseline.now())
        assets.write_json(folder / 'optimization_complete.json', barrier)
        return dict(trained=trained, trained_discriminators=discriminators, normalizer=normalizer,
            api=api, args=args, barrier=barrier, optimization_complete=assets.asset(folder / 'optimization_complete.json'),
            output_dir=str(folder), plan_sha256=canonical_hash(plan),
            train_dev_ledger_ref=assets.asset(folder / 'train_dev_graph_access_ledger.json'),
            distribution_reference=distribution_reference)
    except Exception:
        if not (folder / 'train_dev_graph_access_ledger.json').exists():
            assets.write_json(folder / 'train_dev_graph_access_ledger.json', ledger)
        raise


def validate_barrier(output_dir, plan, fitted):
    """Read-only gate before loading evaluation models or audit graph arrays."""
    seeds = validate_replication_plan(plan)
    folder = output_path(output_dir)
    if (fitted.get('output_dir') != str(folder) or fitted.get('plan_sha256') != canonical_hash(plan)
            or tuple(fitted.get('trained', {})) != ARMS or tuple(fitted.get('trained_discriminators', {})) != ARMS):
        raise ValueError('Fit bundle belongs to another plan or lacks a completed arm')
    path = assets.checked_asset(fitted['optimization_complete'])
    if path != folder / 'optimization_complete.json':
        raise ValueError('Wrong optimization barrier location')
    barrier = json.loads(path.read_text())
    if (barrier != fitted['barrier'] or barrier['arms'] != list(ARMS)
            or barrier['steps'] != EXPECTED_STEPS or barrier['plan_sha256'] != canonical_hash(plan)
            or barrier['parent_sha256'] != canonical_hash(plan['parent'])
            or barrier['hard_support'] != plan['hard_support']
            or barrier['replicate_seed'] != plan['replicate_seed'] or barrier['replication_seeds'] != seeds
            or barrier['expected_continuation_rng'] != continuation_rng_digest(seeds['continuation'])
            or barrier['shared_fairness']['rng'] != barrier['expected_continuation_rng']
            or barrier['shared_victim_initialization']['victim_seed'] != seeds['victim']
            or barrier['shared_victim_initialization']['initial_torch_seed'] != seeds['victim']
            or barrier['distribution_reference'] != distribution_reference_signature(fitted['distribution_reference'])
            or any(barrier[key] is not False for key in (
                'internal_audit_arrays_loaded', 'original_val_arrays_loaded', 'original_test_arrays_loaded'))):
        raise ValueError('Incomplete or changed optimization barrier')
    preflight_path = assets.checked_asset(barrier['all_arms_preflight'])
    preflight = json.loads(preflight_path.read_text())
    if (preflight_path != folder / 'all_arms_preflight.json' or preflight['arms'] != list(ARMS)
            or preflight['status'] != 'ALL_ARMS_NO_UPDATE_SMOKE_PASS' or preflight['optimizer_steps'] != 0
            or preflight['initial_generator_sha256'] != barrier['shared_initial_state']
            or preflight['initial_discriminator_sha256'] != barrier['shared_initial_discriminator']
            or any(preflight[key] != barrier[key] for key in ('replicate_seed', 'replication_seeds',
                'shared_victim_initialization', 'expected_continuation_rng', 'distribution_reference'))):
        raise ValueError('Incomplete all-arm no-update preflight evidence')
    ledger_path = assets.checked_asset(barrier['train_dev_ledger'])
    if (ledger_path != folder / 'train_dev_graph_access_ledger.json'
            or barrier['train_dev_ledger'] != fitted['train_dev_ledger_ref']):
        raise ValueError('Wrong training/development access evidence')
    ledger = json.loads(ledger_path.read_text())
    rows = [*plan['parent']['roles']['train'], *plan['parent']['roles']['dev']]
    if len(ledger) != 640 or len(rows) != len(ledger):
        raise ValueError('Incomplete training/development access ledger')
    for record, row in zip(ledger, rows):
        expected_path = (Path(plan['parent']['graph_dir']) / row['graph_path']).resolve()
        if (record['scenario_id'] != row['scenario_id'] or record['role'] != row['role']
                or record['split'] != 'train' or record['status'] != 'READ_COMPLETE'
                or record['sha256'] != row['graph_sha256'] or Path(record['path']) != expected_path):
            raise ValueError('Training/development access identity differs from registered role')
    for arm, (generator, victim) in fitted['trained'].items():
        discriminator = fitted['trained_discriminators'][arm]
        record_path = assets.checked_asset(barrier['training'][arm])
        if record_path != folder / arm / 'training.json':
            raise ValueError('Arm training evidence escaped its output directory')
        record = json.loads(record_path.read_text())
        if (record['arm'] != arm or record['replicate_seed'] != plan['replicate_seed']
                or record['replication_seeds'] != seeds
                or record['expected_initialization'] != barrier['shared_victim_initialization']
                or any(record[key] != value for key, value in barrier['shared_victim_initialization'].items())
                or record['trace']['training_forwards'] != 200 or record['trace']['eval_forwards'] != 200):
            raise ValueError('Matched fresh-victim training contract changed')
        for key in ('generator', 'surrogate', 'victim', 'discriminator', 'distribution_record', 'generator_record', 'smoke'):
            if assets.checked_asset(record[key]).parent != folder / arm:
                raise ValueError('Arm artifact escaped its output directory')
        result = previous.checked_json(record['generator_record'])
        _check_training_result(result, arm, plan['training_config'])
        if (result['actual_continuation_seed'] != seeds['continuation']
                or result['replicate_seed'] != plan['replicate_seed'] or result['replication_seeds'] != seeds
                or result['initial_cpu_rng_sha256'] != barrier['expected_continuation_rng']):
            raise ValueError('Actual continuation seed/RNG differs from the replication contract')
        dist = previous.checked_json(record['distribution_record'])
        for key in ('initial_checkpoint', 'final_checkpoint'):
            if assets.checked_asset(dist[key]).parent != folder / arm:
                raise ValueError('Distribution snapshot escaped its output directory')
        if (dist['arm'] != arm or dist['config'] != plan['distribution_config']
                or dist['actual_config'] != effective_distribution_config(plan)
                or dist['replicate_seed'] != plan['replicate_seed'] or dist['replication_seeds'] != seeds
                or dist['initial']['config']['seed'] != seeds['discriminator']
                or dist['final']['config']['seed'] != seeds['discriminator']
                or dist['discriminator_steps'] != result['discriminator_steps'] or dist['generator_calls'] != 200
                or dist['initial_discriminator_sha256'] != barrier['shared_initial_discriminator']
                or dist['initial_discriminator_sha256'] != result['distribution_initial_state_sha256']
                or dist['final_discriminator_sha256'] != result['distribution_final_state_sha256']
                or dist['final_discriminator_sha256'] != state_sha256(discriminator)):
            raise ValueError('Discriminator checkpoint, initialization or runtime budget changed')
        smoke = previous.checked_json(record['smoke'])
        if (record['smoke'] != preflight['smoke'][arm] or smoke['status'] != 'NO_UPDATE_GRADIENT_SMOKE_PASS'
                or smoke['optimizer_steps'] != 0 or smoke['discriminator_steps'] != 0
                or smoke['initial_projected_outer_identity_exact'] is not True
                or smoke['projected_reference_sha256'] != barrier['shared_initial_state']
                or smoke['initial_discriminator_sha256'] != barrier['shared_initial_discriminator']
                or smoke['projected_outer_output_sha256'] != preflight['projected_outer_output_sha256']):
            raise ValueError('Arm no-update preflight differs from the common projected initialization')
        if (generator.output_mode != 'domain_projection' or generator.hard_support.tolist() != plan['hard_support']
                or barrier['final_model_hashes'][arm] != dict(generator=state_sha256(generator),
                    victim=state_sha256(victim), discriminator=state_sha256(discriminator))):
            raise ValueError('Live fitted model or registered output mapping changed')
        for model in (generator, victim, discriminator):
            if (any(child.training for child in model.modules())
                    or any(p.requires_grad or p.grad is not None for p in model.parameters())):
                raise ValueError('Audit barrier models are not entirely frozen/eval/gradient-free')
    return barrier
