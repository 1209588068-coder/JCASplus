"""Two prospective matched repetitions, plus the already observed first seed.

Offline AV2/self-owned GNN research. Preserve all old code/assets/results.
This varies downstream RNGs, NOT the source generator, data or target pool.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import gc
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
from types import SimpleNamespace

import numpy as np
import torch

from experiments.spear_distribution_training_v1 import workflow as source
from experiments.spear_distribution_audit_v1 import workflow as diagnostic
from experiments.spear_distribution_audit_v1 import statistics
from experiments.spear_semantic_support_v1.training import state_sha256
from experiments.spear_sage_pilot_v1.fitting import enrich_train_provenance
from experiments.spear_semantic_support_review_v1 import read_tables
from experiments.spear_seed_stability_v1.workflow import verify_target_identity
from experiments.spear_dual_clean_proxy_v1.workflow import verify_normal_clean
from . import fitting, reporting

ROOT, assets, baseline = source.ROOT, source.assets, source.baseline
VERSION = 'spear_distribution_replication_v1'
ARMS = source.ARMS
SEEDS = (20260621, 20260622, 20260623)
AUDIT_PLAN = ROOT / 'record/reproduction/spear_distribution_audit_v1/audit_20261027_seed20260621_v1/plan.json'
AUDIT_PLAN_SHA = '748f8b1ccb4fa88b8c7643ec3b16c3394f295fa1977c2da965d005fa2cb7fd4a'
AUDIT_SUMMARY_SHA = 'bd464d622d26ff7b2cc8f4abe28bd08169f2d789de6afe4d173bde70c97fb942'
checked_json = source.audit_source.previous.checked_json


def fields():
    """Metadata-only pre-registration; all previous plans remain byte-identical."""
    audit_ref = dict(path=str(AUDIT_PLAN), sha256=AUDIT_PLAN_SHA)
    assets.checked_asset(audit_ref)
    _, old_audit = diagnostic.load_plan(AUDIT_PLAN)
    summary_ref = dict(path=str(AUDIT_PLAN.parent / 'summary.json'), sha256=AUDIT_SUMMARY_SHA)
    complete = checked_json(summary_ref)
    if (complete['status'] != 'DISTRIBUTION_AUDIT_COMPLETE_REVIEW_REQUIRED'
            or complete['plan'] != audit_ref or complete['optimizer_steps'] != 0):
        raise ValueError('Require the completed frozen-checkpoint distribution diagnostic')
    template = checked_json(old_audit['source_plan'])
    for key in ('metrics', 'reference', 'arrays', 'integrity', 'original_performance_review'):
        assets.checked_asset(complete[key])
    paths = sorted(Path(__file__).parent.glob('*.py'))
    paths += sorted((ROOT / 'tests').glob('test_spear_distribution_replication*.py'))
    paths.append(ROOT / 'docs/SPEAR_DISTRIBUTION_REPLICATION_20261027.md')
    return dict(version=VERSION, seeds=list(SEEDS), reused_seed=SEEDS[0], new_seeds=list(SEEDS[1:]),
        source_diagnostic_plan=audit_ref, source_diagnostic_summary=summary_ref,
        source_training_plan=old_audit['source_plan'], source_template=template,
        source_review=complete['original_performance_review'], source_distribution=complete['metrics'],
        source_reference=complete['reference'], arms=list(ARMS),
        execution=dict(device='cpu', torch_threads=2, sequential=True, automatic_retries=False),
        source_catalog={str(p.relative_to(ROOT)): assets.sha256(p) for p in paths},
        contract=dict(
            study='fixed-data and fixed-pretrained-start downstream training-seed stability',
            historical='seed20260621 already observed; only20260622/23 prospectively registered here',
            unchanged='source generator/surrogate, both clean proxies, clean reference, support24,26 attachments,538 outer,normalizer,all role IDs',
            data_roles='original TRAIN train512/internal dev128/reused audit256; no original VAL/TEST',
            target_selection_seed=20260621, context_seed=20260621,
            continuation_rng='replicate_seed+3000; G/surrogate restored, not reinitialized',
            discriminator_rng='replicate_seed+1000; private RNG; matched initial weights within seed',
            victim_rng='replicate_seed; fresh GraphSAGE initialization and dropout; matched within seed',
            training='each new seed:3 arms x200 residual/surrogate steps x200 victim epochs; D0/200/200',
            total_new_updates=dict(residual=1200,surrogate=1200,victim_epochs=1200,discriminator=800),
            checkpoint='unchanged final G epoch199; victim best internal-dev AUC with earliest tie',
            audit_barrier='all three arms of a seed complete before that seed audit; no performance-driven early stopping',
            acceptance=dict(overall_incremental_asr_min=.80,moving_incremental_asr_min=.80,
                adjacent_incremental_fp_max_exclusive=.05,normal_auc_drop_max=.005,normal_recall_drop_max=.05),
            quality_comparators='preserve historical SAGE24 check; main module contrast is same-seed continuation',
            statistics='per-seed mean/sampleSD ddof1 and within-seed paired differences; never pool repeated224 targets',
            distribution='same fixed diagnostic code/reference/coordinates/bandwidth/quantiles; captured during normal audit, no extra fitting',
            stop='integrity/nonfinite/runtime errors only; retain failed-quality seeds; no retries or replacement seeds',
            original_val_arrays_loaded=False,original_test_arrays_loaded=False,
            full_pipeline_replication=False,independent_confirmation=False,physical_validity_claim=False,
            automatic_promotion=False,automatic_extra_seeds=False))


def output_path(path):
    path = Path(path).resolve()
    namespace = ROOT / 'record/reproduction' / VERSION
    if path == namespace or not path.is_relative_to(namespace):
        raise ValueError('Require a new child of the replication namespace')
    return path


def child_plan(master, seed, master_reference):
    if seed not in SEEDS[1:]:
        raise ValueError('Only the two prospectively registered seeds may run')
    plan = deepcopy(master['source_template'])
    plan['historical_source_contract'] = deepcopy(plan.get('contract', {}))
    plan.update(version=VERSION, created_at_utc=master['created_at_utc'],
        replication_master=deepcopy(master_reference), replicate_seed=seed,
        replication_seeds=dict(continuation=seed+3000, discriminator=seed+1000, victim=seed),
        source_catalog=deepcopy(master['source_catalog']),
        contract=deepcopy(master['contract']), replication_contract=deepcopy(master['contract']))
    # The old parent/data-selection seeds and source fields intentionally stay unchanged.
    return plan


def prepare(output):
    output = output_path(output)
    if output.exists():
        raise FileExistsError('Never overwrite an existing replication')
    plan = dict(created_at_utc=baseline.now(), **fields())
    output.mkdir(parents=True, exist_ok=False)
    path = output / 'plan.json'
    assets.write_json(path, plan)
    with tarfile.open(output / 'source_snapshot.tar', 'x') as archive:
        for name in plan['source_catalog']:
            archive.add(ROOT / name, arcname=name, recursive=False)
    for seed in SEEDS[1:]:
        folder = output / f'seed{seed}'
        folder.mkdir(exist_ok=False)
        assets.write_json(folder / 'plan.json', child_plan(plan, seed, assets.asset(path)))
    return path


def load_plan(path):
    path = Path(path).resolve()
    output_path(path.parent)
    if path.name != 'plan.json':
        raise ValueError('Require master plan.json')
    plan = json.loads(path.read_text())
    if {key:value for key,value in plan.items() if key != 'created_at_utc'} != fields():
        raise ValueError('Bound replication source or protocol changed')
    for seed in SEEDS[1:]:
        child = json.loads((path.parent / f'seed{seed}/plan.json').read_text())
        if child != child_plan(plan, seed, assets.asset(path)):
            raise ValueError('Registered child seed plan changed')
    return path, plan


class CapturingInjector(source.AuditedInjector):
    """Collect identical fixed24 observations during the existing single replay."""
    def __init__(self, generator, seed):
        super().__init__(generator, seed)
        self.clean, self.changed, self.conditions, self.moving = [], [], [], []

    def inject_trigger(self, indices, x, edges, weights, device):
        if indices.numel() != 1:
            raise ValueError('Require one fixed audit target per scene')
        output, new_edges, new_weights = super().inject_trigger(indices, x, edges, weights, device)
        target = int(indices[0])
        selected = self.generator.selected_coordinates[self.generator.hard_support]
        conditions = list(statistics_condition_coordinates())
        if not torch.equal(x[:, conditions], output[:, conditions]):
            raise ValueError('Original observed conditions were modified')
        self.clean.append(x[target, selected].detach().cpu().numpy().copy())
        self.changed.append(output[target, selected].detach().cpu().numpy().copy())
        self.conditions.append(x[target, conditions].detach().cpu().numpy().copy())
        self.moving.append(bool(self.part['motion_regime'][target]))
        return output, new_edges, new_weights


def statistics_condition_coordinates():
    return diagnostic.CONDITION_COORDINATES


def save_distribution(output, train_reference, captured, master):
    reference = statistics.fit_reference(train_reference['train_selected'], train_reference['train_conditions'],
                                         train_reference['train_moving'])
    if reference.to_metadata() != checked_json(master['source_reference']):
        raise ValueError('Fixed clean reference/bandwidth/quantiles differ from the original diagnostic')
    first = captured[ARMS[0]]
    clean, conditions, moving = np.stack(first.clean), np.stack(first.conditions), np.asarray(first.moving, dtype=bool)
    if len(clean) != 224 or int(moving.sum()) != 60:
        raise ValueError('Fixed distribution target population changed')
    changed = {}
    for arm in ARMS:
        current = captured[arm]
        if (not np.array_equal(np.stack(current.clean), clean)
                or not np.array_equal(np.stack(current.conditions), conditions)
                or not np.array_equal(np.asarray(current.moving, dtype=bool), moving)):
            raise ValueError('Distribution arms do not share clean targets/conditions/strata')
        changed[arm] = np.stack(current.changed)
    measured = statistics.evaluate(reference, clean, conditions, moving, changed)
    assets.write_json(output / 'distribution_metrics.json', measured)
    rows, comparisons = diagnostic.compact_report(measured)
    diagnostic.save_csv(output / 'distribution_comparison.csv', rows)
    assets.write_json(output / 'distribution_comparisons.json', comparisons)
    assets.write_json(output / 'distribution_reference.json', reference.to_metadata())
    diagnostic.save_csv(output / 'distribution_reference_identity.csv', train_reference['reference_rows'])
    arrays = {key:train_reference[key] for key in ('train_selected','train_conditions','train_moving')}
    arrays.update(audit_clean=clean, audit_conditions=conditions, audit_moving=moving)
    arrays.update({'triggered_'+arm:value for arm,value in changed.items()})
    with (output / 'distribution_features.npz').open('xb') as stream:
        np.savez_compressed(stream, **arrays)
    return assets.asset(output / 'distribution_metrics.json')


def evaluate_completed(output, plan, fitted, progress, master):
    fitting.validate_barrier(output / 'training', plan, fitted)
    stub = SimpleNamespace(x=torch.empty((0,784)),y=torch.tensor([0,1]))
    reference = fitted['api']['model_construct'](fitted['args'], 'GraphSage', stub, torch.device('cpu'))
    reference.load_state_dict(torch.load(assets.checked_asset(plan['parent']['references']['clean_reference']),
                                        map_location='cpu', weights_only=True), strict=True)
    reference.eval().requires_grad_(False)
    reports, refs, ledger, parts, hashes, captured = {}, {}, [], {}, {}, {}
    try:
        for arm in ARMS:
            generator, victim = fitted['trained'][arm]
            for model in (generator, victim):
                model.zero_grad(set_to_none=True)
                model.eval().requires_grad_(False)
            models = dict(clean_reference=reference, victim=victim)
            all_models = dict(generator=generator, **models)
            before = {key:state_sha256(model) for key,model in all_models.items()}
            injector = CapturingInjector(generator, plan['parent']['shuffle_seed'])
            reader = source.BoundAuditReader(plan['parent'], fitted['normalizer'], ledger, parts, hashes, injector, arm)
            with torch.no_grad():
                result = baseline.evaluate(plan['parent'], output / 'audit' / arm, models, injector, reader,
                                           lambda **record: progress(arm=arm, **record))
            result = enrich_train_provenance(plan['parent'], ledger, result)
            if result['audit_counts'] != plan['expected_counts'] or len(injector.budgets) != 224:
                raise ValueError('Audit counts changed')
            read_tables(result, plan['parent']['roles']['audit'])
            directory = output / 'audit' / arm
            identity = verify_target_identity(directory / 'targets.csv', plan['original_csvs']['raw_targets']['path'])
            replay = verify_normal_clean(directory / 'clean_pair_scores.csv', plan['original_csvs']['raw_clean_scores']['path'])
            if (before != {key:state_sha256(model) for key,model in all_models.items()}
                    or hashes != {key:baseline.field.part_digest(part) for key,part in parts.items()}):
                raise ValueError('Evaluation changed frozen models or clean inputs')
            assets.write_json(directory / 'budgets.json', injector.budgets)
            info = dict(evaluation=result, unchanged_model_hashes=before,
                targets_identity_verified=identity, clean_reference_replay=replay,
                budgets=assets.asset(directory / 'budgets.json'), training=fitted['barrier']['training'][arm])
            assets.write_json(directory / 'summary.json', info)
            reports[arm], refs[arm], captured[arm] = result, assets.asset(directory / 'summary.json'), injector
        if len(parts) != 256 or len(ledger) != 256:
            raise ValueError('Incomplete audit access ledger')
        decision = reporting.review_evaluations(reports, checked_json(plan['original_report'])['evaluation'],
                                               checked_json(plan['source_report'])['evaluation'])
        assets.write_json(output / 'review.json', decision)
        distribution_ref = save_distribution(output, fitted['distribution_reference'], captured, master)
        return dict(reports=refs, review=assets.asset(output / 'review.json'), distribution=distribution_ref)
    finally:
        assets.write_json(output / 'audit_graph_access_ledger.json', ledger)


def run_seed(folder, plan, progress, master):
    assets.write_json(folder / 'started.json', dict(pid=os.getpid(), at=baseline.now(), plan=assets.asset(folder / 'plan.json')))
    fitted = fitting.fit_arms(folder / 'training', plan, progress=progress)
    # Recheck source bytes before opening the reused audit, as in the old runner.
    load_plan(plan['replication_master']['path'])
    evidence = evaluate_completed(folder, plan, fitted, progress, master)
    load_plan(plan['replication_master']['path'])
    result = dict(status='DISTRIBUTION_REPLICATION_SEED_COMPLETE', seed=plan['replicate_seed'],
        at=baseline.now(), plan=assets.asset(folder / 'plan.json'), **evidence,
        optimization_complete=fitted['optimization_complete'], train_dev_ledger=fitted['train_dev_ledger_ref'],
        audit_ledger=assets.asset(folder / 'audit_graph_access_ledger.json'),
        original_val_arrays_loaded=False, original_test_arrays_loaded=False)
    assets.write_json(folder / 'summary.json', result)
    return result


def run(path):
    path, plan = load_plan(path)
    output = path.parent
    assets.write_json(output / 'started.json', dict(pid=os.getpid(), at=baseline.now(), plan=assets.asset(path)))
    state = source.state_writer(output)
    completed = {}
    try:
        replicates = [dict(seed=SEEDS[0], review=checked_json(plan['source_review']),
                           distribution=checked_json(plan['source_distribution']))]
        for seed in SEEDS[1:]:
            load_plan(path)
            child = child_plan(plan, seed, assets.asset(path))
            folder = output / f'seed{seed}'
            def progress(**record):
                state(seed=seed, seeds_completed=len(completed), new_seeds_total=2, **record)
            progress(stage='starting_registered_seed')
            result = run_seed(folder, child, progress, plan)
            completed[str(seed)] = assets.asset(folder / 'summary.json')
            replicates.append(dict(seed=seed, review=checked_json(result['review']),
                                   distribution=checked_json(result['distribution'])))
            gc.collect()
        aggregate = reporting.aggregate(replicates)
        load_plan(path)
        assets.write_json(output / 'aggregate.json', aggregate)
        result = dict(status='DISTRIBUTION_REPLICATION_COMPLETE_REVIEW_REQUIRED', at=baseline.now(),
            plan=assets.asset(path), new_seed_reports=completed, reused_seed=SEEDS[0],
            aggregate=assets.asset(output / 'aggregate.json'),
            original_val_arrays_loaded=False, original_test_arrays_loaded=False,
            full_pipeline_replication=False, independent_confirmation=False,
            automatic_promotion=False, automatic_followup=False)
        assets.write_json(output / 'summary.json', result)
        state(status=result['status'], stage='complete', new_seeds_completed=2)
        return result
    except Exception as exc:
        assets.write_json(output / 'failure.json', dict(error=str(exc), at=baseline.now(), completed=completed,
                                                       automatic_retry=False))
        state(status='STOPPED_REPLICATION_ERROR', error=str(exc), completed=completed)
        raise


def launch(path):
    path, _ = load_plan(path)
    if any((path.parent / name).exists() for name in ('started.json','launcher.json','launch_claim.json',
                                                     'failure.json','summary.json','console.log')):
        raise ValueError('An existing run cannot be restarted')
    for seed in SEEDS[1:]:
        if any((path.parent / f'seed{seed}' / name).exists() for name in ('started.json','training','summary.json')):
            raise ValueError('A child seed has already started')
    # Exclusive creation prevents simultaneous launchers; no automatic retry on launch failure.
    assets.write_json(path.parent / 'launch_claim.json', dict(at=baseline.now(), plan=assets.asset(path)))
    command = [sys.executable, '-B', '-u', '-m', 'experiments.spear_distribution_replication_v1.workflow',
               'run', '--plan', str(path)]
    environment = dict(os.environ, CUDA_VISIBLE_DEVICES='', PYTHONDONTWRITEBYTECODE='1',
                       OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
    with (path.parent / 'console.log').open('xb') as stream:
        process = subprocess.Popen(command, cwd=ROOT, env=environment, stdout=stream,
                                   stderr=subprocess.STDOUT, start_new_session=True)
    result = dict(pid=process.pid, command=command, at=baseline.now(), plan=assets.asset(path), automatic_retry=False)
    assets.write_json(path.parent / 'launcher.json', result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    p = commands.add_parser('prepare'); p.add_argument('--output-dir', required=True)
    for name in ('check','run','launch'):
        p = commands.add_parser(name); p.add_argument('--plan', required=True)
    args = parser.parse_args()
    if args.command == 'prepare':
        print(prepare(args.output_dir))
    elif args.command == 'check':
        load_plan(args.plan); print('REPLICATION_METADATA_PASS; no graph/model loads or training')
    elif args.command == 'launch':
        print(json.dumps(launch(args.plan), indent=2))
    else:
        print(json.dumps(run(args.plan), indent=2))


if __name__ == '__main__':
    main()
